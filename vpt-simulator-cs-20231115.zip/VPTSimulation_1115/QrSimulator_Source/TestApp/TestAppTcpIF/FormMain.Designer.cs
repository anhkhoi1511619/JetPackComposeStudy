﻿namespace TestAppTcpIF
{
    partial class FormMain
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.pnlLog = new System.Windows.Forms.Panel();
            this.lbStatus = new System.Windows.Forms.Label();
            this.cboRxIpAddress = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.nudRxPortNo = new System.Windows.Forms.NumericUpDown();
            this.chkAutoRes = new System.Windows.Forms.CheckBox();
            this.nudTxPortNo = new System.Windows.Forms.NumericUpDown();
            this.signalStrength = new System.Windows.Forms.NumericUpDown();
            this.stopSeqNumber = new System.Windows.Forms.NumericUpDown();
            this.routeId = new System.Windows.Forms.NumericUpDown();
            this.diaNo = new System.Windows.Forms.NumericUpDown();
            this.cmdNumber = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.startHour = new System.Windows.Forms.NumericUpDown();
            this.startTimeMinutues = new System.Windows.Forms.NumericUpDown();
            this.startTimeSecond = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cboTxIpAddress = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudRxPortNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTxPortNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalStrength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopSeqNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.routeId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diaNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmdNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startHour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startTimeMinutues)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startTimeSecond)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Open";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 41);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 70);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Send";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // txtLog
            // 
            this.txtLog.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtLog.Location = new System.Drawing.Point(557, 147);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(69, 34);
            this.txtLog.TabIndex = 3;
            // 
            // pnlLog
            // 
            this.pnlLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLog.Location = new System.Drawing.Point(9, 187);
            this.pnlLog.Name = "pnlLog";
            this.pnlLog.Size = new System.Drawing.Size(617, 175);
            this.pnlLog.TabIndex = 4;
            // 
            // lbStatus
            // 
            this.lbStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbStatus.Location = new System.Drawing.Point(9, 365);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(565, 23);
            this.lbStatus.TabIndex = 5;
            this.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboRxIpAddress
            // 
            this.cboRxIpAddress.FormattingEnabled = true;
            this.cboRxIpAddress.Items.AddRange(new object[] {
            "192.168.254.25"});
            this.cboRxIpAddress.Location = new System.Drawing.Point(192, 14);
            this.cboRxIpAddress.Name = "cboRxIpAddress";
            this.cboRxIpAddress.Size = new System.Drawing.Size(122, 20);
            this.cboRxIpAddress.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(93, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "送信先：IPアドレス";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(93, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 12);
            this.label2.TabIndex = 10;
            this.label2.Text = "受信先:IPアドレス";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(95, 147);
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtData.Size = new System.Drawing.Size(456, 34);
            this.txtData.TabIndex = 13;
            this.txtData.Text = "00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 12);
            this.label5.TabIndex = 14;
            this.label5.Text = "Tx:送信データ";
            // 
            // nudRxPortNo
            // 
            this.nudRxPortNo.Location = new System.Drawing.Point(402, 14);
            this.nudRxPortNo.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nudRxPortNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRxPortNo.Name = "nudRxPortNo";
            this.nudRxPortNo.Size = new System.Drawing.Size(84, 19);
            this.nudRxPortNo.TabIndex = 15;
            this.nudRxPortNo.Value = new decimal(new int[] {
            52003,
            0,
            0,
            0});
            // 
            // chkAutoRes
            // 
            this.chkAutoRes.AutoSize = true;
            this.chkAutoRes.Location = new System.Drawing.Point(12, 104);
            this.chkAutoRes.Name = "chkAutoRes";
            this.chkAutoRes.Size = new System.Drawing.Size(72, 16);
            this.chkAutoRes.TabIndex = 18;
            this.chkAutoRes.Text = "自動応答";
            this.chkAutoRes.UseVisualStyleBackColor = true;
            // 
            // nudTxPortNo
            // 
            this.nudTxPortNo.Location = new System.Drawing.Point(402, 41);
            this.nudTxPortNo.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nudTxPortNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudTxPortNo.Name = "nudTxPortNo";
            this.nudTxPortNo.Size = new System.Drawing.Size(84, 19);
            this.nudTxPortNo.TabIndex = 19;
            this.nudTxPortNo.Value = new decimal(new int[] {
            51002,
            0,
            0,
            0});
            // 
            // signalStrength
            // 
            this.signalStrength.Location = new System.Drawing.Point(452, 90);
            this.signalStrength.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.signalStrength.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.signalStrength.Name = "signalStrength";
            this.signalStrength.Size = new System.Drawing.Size(69, 19);
            this.signalStrength.TabIndex = 15;
            this.signalStrength.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // stopSeqNumber
            // 
            this.stopSeqNumber.Location = new System.Drawing.Point(354, 92);
            this.stopSeqNumber.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.stopSeqNumber.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.stopSeqNumber.Name = "stopSeqNumber";
            this.stopSeqNumber.Size = new System.Drawing.Size(76, 19);
            this.stopSeqNumber.TabIndex = 15;
            this.stopSeqNumber.Value = new decimal(new int[] {
            102,
            0,
            0,
            0});
            // 
            // routeId
            // 
            this.routeId.Location = new System.Drawing.Point(263, 92);
            this.routeId.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.routeId.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.routeId.Name = "routeId";
            this.routeId.Size = new System.Drawing.Size(71, 19);
            this.routeId.TabIndex = 15;
            this.routeId.Value = new decimal(new int[] {
            9,
            0,
            0,
            0});
            // 
            // diaNo
            // 
            this.diaNo.Location = new System.Drawing.Point(167, 90);
            this.diaNo.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.diaNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.diaNo.Name = "diaNo";
            this.diaNo.Size = new System.Drawing.Size(75, 19);
            this.diaNo.TabIndex = 15;
            this.diaNo.Value = new decimal(new int[] {
            14,
            0,
            0,
            0});
            // 
            // cmdNumber
            // 
            this.cmdNumber.Location = new System.Drawing.Point(93, 90);
            this.cmdNumber.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.cmdNumber.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.cmdNumber.Name = "cmdNumber";
            this.cmdNumber.Size = new System.Drawing.Size(50, 19);
            this.cmdNumber.TabIndex = 15;
            this.cmdNumber.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(93, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "Cmd：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(179, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "運行ダイヤ：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(527, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "開発時刻：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(275, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "系統番号：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(367, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 12);
            this.label8.TabIndex = 9;
            this.label8.Text = "駒番号：";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(462, 70);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "電波強度：";
            // 
            // startHour
            // 
            this.startHour.Location = new System.Drawing.Point(592, 63);
            this.startHour.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.startHour.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.startHour.Name = "startHour";
            this.startHour.Size = new System.Drawing.Size(34, 19);
            this.startHour.TabIndex = 15;
            this.startHour.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // startTimeMinutues
            // 
            this.startTimeMinutues.Location = new System.Drawing.Point(592, 90);
            this.startTimeMinutues.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.startTimeMinutues.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.startTimeMinutues.Name = "startTimeMinutues";
            this.startTimeMinutues.Size = new System.Drawing.Size(34, 19);
            this.startTimeMinutues.TabIndex = 15;
            this.startTimeMinutues.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // startTimeSecond
            // 
            this.startTimeSecond.Location = new System.Drawing.Point(592, 117);
            this.startTimeSecond.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.startTimeSecond.Name = "startTimeSecond";
            this.startTimeSecond.Size = new System.Drawing.Size(34, 19);
            this.startTimeSecond.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(352, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 12);
            this.label12.TabIndex = 9;
            this.label12.Text = "ポスト：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(352, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 12);
            this.label13.TabIndex = 9;
            this.label13.Text = "ポスト：";
            // 
            // cboTxIpAddress
            // 
            this.cboTxIpAddress.FormattingEnabled = true;
            this.cboTxIpAddress.Items.AddRange(new object[] {
            "192.168.254.30"});
            this.cboTxIpAddress.Location = new System.Drawing.Point(192, 40);
            this.cboTxIpAddress.Name = "cboTxIpAddress";
            this.cboTxIpAddress.Size = new System.Drawing.Size(122, 20);
            this.cboTxIpAddress.TabIndex = 6;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 407);
            this.Controls.Add(this.nudTxPortNo);
            this.Controls.Add(this.chkAutoRes);
            this.Controls.Add(this.signalStrength);
            this.Controls.Add(this.stopSeqNumber);
            this.Controls.Add(this.startTimeSecond);
            this.Controls.Add(this.startTimeMinutues);
            this.Controls.Add(this.startHour);
            this.Controls.Add(this.routeId);
            this.Controls.Add(this.diaNo);
            this.Controls.Add(this.cmdNumber);
            this.Controls.Add(this.nudRxPortNo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cboTxIpAddress);
            this.Controls.Add(this.cboRxIpAddress);
            this.Controls.Add(this.lbStatus);
            this.Controls.Add(this.pnlLog);
            this.Controls.Add(this.txtLog);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "FormMain";
            this.Text = "TcpTestApp";
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudRxPortNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTxPortNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalStrength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopSeqNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.routeId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diaNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmdNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startHour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startTimeMinutues)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startTimeSecond)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Panel pnlLog;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.ComboBox cboRxIpAddress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nudRxPortNo;
        private System.Windows.Forms.CheckBox chkAutoRes;
        private System.Windows.Forms.NumericUpDown nudTxPortNo;
        private System.Windows.Forms.NumericUpDown signalStrength;
        private System.Windows.Forms.NumericUpDown stopSeqNumber;
        private System.Windows.Forms.NumericUpDown routeId;
        private System.Windows.Forms.NumericUpDown diaNo;
        private System.Windows.Forms.NumericUpDown cmdNumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown startHour;
        private System.Windows.Forms.NumericUpDown startTimeMinutues;
        private System.Windows.Forms.NumericUpDown startTimeSecond;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboTxIpAddress;
    }
}

