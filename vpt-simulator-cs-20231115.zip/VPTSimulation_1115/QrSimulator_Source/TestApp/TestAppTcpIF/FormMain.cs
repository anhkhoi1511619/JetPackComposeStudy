﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Lecip;
using Lecip.Net;

namespace TestAppTcpIF
{
    /// <summary>
    /// Lecip.Net.TcpIFを使用してTCP通信を行うサンプルアプリ
    /// </summary>
    public partial class FormMain : Form
    {

        #region TCP_PROTOCOL

        #region Field
        private TcpIF tcp;
        #endregion

        #region Constructor
        public FormMain()
        {
            InitializeComponent();
            this.button1.Click += (sender, e) => { open(); };
            this.button2.Click += (sender, e) => { close(); };
            this.button3.Click += (sender, e) => { send(); };

            var textLog = new TextBoxLog() { Dock = DockStyle.Fill };
            this.pnlLog.Controls.Add((textLog));

            this.tcp                    = new TcpIF();
            this.tcp.TcpIFWriteLog      += (sender, type, log) => { textLog.UpdateLog((MsgType)type, log); };
            this.tcp.TcpIFDataReceived  += (sender, e) => { if (this.chkAutoRes.Checked) send(); };
            this.tcp.TcpIFErrorReceived += (sender, e) => { appendLog(); };

            this.tcp.SendIpAddr         = "192.168.254.25";
            this.tcp.RecvIpAddr         = "192.168.254.30";
            this.tcp.SendPortNo         = 51002;
            this.tcp.RecvPortNo         = 52003;
            this.tcp.ReceiveTimeout     = 5000;
            this.startHour.Text = DateTime.Now.ToString("hh");
            this.startTimeMinutues.Text = DateTime.Now.ToString("mm");
            this.startTimeSecond.Text = DateTime.Now.ToString("ss");
            this.txtData.Text           = convertTxtData();
            this.lbStatus.Text = this.tcp.PortStatus;

            this.cboRxIpAddress.Items.Add(Lecip.Utility.Utility.GetIpV4Address(string.Empty));
            this.cboRxIpAddress.SelectedIndex = 0;

            this.cboTxIpAddress.Items.Add(Lecip.Utility.Utility.GetIpV4Address(string.Empty));
            this.cboTxIpAddress.SelectedIndex = 0;

           
        }
        #endregion


        #region Private Method
        private void open()
        {
            if (this.tcp.IsOpen) return;

            this.tcp.SendIpAddr = this.cboTxIpAddress.Text;
            this.tcp.RecvIpAddr = this.cboRxIpAddress.Text;
            this.tcp.SendPortNo = (int)this.nudTxPortNo.Value;
            this.tcp.RecvPortNo = (int)this.nudRxPortNo.Value;

            this.tcp.Open();
            this.lbStatus.Text = this.tcp.PortStatus;
            this.cboRxIpAddress.Enabled = false;
            this.txtData.Text = convertTxtData();
        }

        private void close()
        {
            if (!this.tcp.IsOpen) return;

            this.tcp.Close();
            this.lbStatus.Text = this.tcp.PortStatus;
            this.cboRxIpAddress.Enabled = true;
            this.txtData.Text = "00";
        }

        private void send()
        {
            string sendData = this.txtData.Text;
            sendData = sendData.Replace("\r\n", "");
            sendData = sendData.Replace(" ", "");

            byte[] s = Util.ToByteArray(sendData);
            this.tcp.Send(s, s.Length);
        }

        private void appendLog()
        {
            if (this.InvokeRequired)
                this.Invoke(new Action<string>(appendLog), this.tcp.ErrorMessage);
            else
                appendLog(this.tcp.ErrorMessage);
        }

        private void appendLog(string log)
        {
            this.txtLog.AppendText(log + "\r\n");
        }

        private string convertTxtData()
        {
            string diaNoHex = Convert.ToInt32(this.diaNo.Value).ToString("X");
            diaNoHex = diaNoHex.PadLeft(6,'0');

            string routeId = this.routeId.Text;
            routeId = routeId.PadLeft(8, '0');

            string second = this.startTimeSecond.Text;
            second = second.PadLeft(2, '0');

            string minutes = this.startTimeMinutues.Text;
            minutes = minutes.PadLeft(2, '0');

            string hours = this.startHour.Text;
            hours = hours.PadLeft(2, '0');

            string startTime = hours + minutes + second;

            string stopSeq = this.stopSeqNumber.Text;
            stopSeq = stopSeq.PadLeft(4, '0');

            string signalStrengthHex = Convert.ToInt32(this.signalStrength.Value).ToString("X");
            signalStrengthHex = signalStrengthHex.PadLeft(4, '0');

            Console.WriteLine(DateTime.Now.ToString("hh"));


            return "020010F00" + this.cmdNumber.Text + "04" + diaNoHex + routeId + startTime + stopSeq + signalStrengthHex + "F203";
        }
        #endregion

        #endregion

        private void FormMain_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
