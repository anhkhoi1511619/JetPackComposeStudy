﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Lecip;
using Lecip.Net;

namespace TestAppTcpIFQr
{
    /// <summary>
    /// Lecip.Net.TcpIFQrを使用してTCP通信を行うサンプルアプリ
    /// </summary>
    public partial class FormMain : Form
    {

        #region TCP_PROTOCOL

        private TcpIF tcp;
        byte sequenceNumber = 1;
        const byte SEQUENCE_MAX = 0xFF;

        #region Constructor
        public FormMain()
        {
            InitializeComponent();
            this.button1.Click += (sender, e) => { open(); };
            this.button2.Click += (sender, e) => { close(); };
            this.button3.Click += (sender, e) => { send(); };
            //this.chkAutoRes.Click += (sender, e) => {if (this.chkAutoRes.Checked) defaultCMD01();};

            var textLog = new TextBoxLog() { Dock = DockStyle.Fill };
            this.pnlLog.Controls.Add((textLog));

            this.tcp = new TcpIF();
            this.tcp.TcpIFWriteLog += (sender, type, log) => { textLog.UpdateLog((MsgType)type, log); };
            //this.tcp.TcpIFDataReceived += (sender, e) => {
            //    if (!this.chkAutoRes.Checked) return;
            //    send();
            //    if (!this.btnCmd02.Enabled && this.btnCmd00.Enabled) defaultCMD01();
            //};

            this.tcp.TcpIFDataReceived += (sender, e) => { analyze(); };
            this.tcp.TcpIFErrorReceived += (sender, e) => { appendLog(); };
            //this.tcp.TcpAnalyzeRxData += (sender, e) => { analyze(); };

            this.tcp.SendIpAddr = "192.168.254.10";
            this.tcp.RecvIpAddr = "192.168.254.30";
            this.tcp.SendPortNo = 53001;
            this.tcp.RecvPortNo = 53001;
            this.tcp.ReceiveTimeout = 5000;
            this.startHour.Text = DateTime.Now.ToString("hh");
            this.startTimeMinutues.Text = DateTime.Now.ToString("mm");
            this.startTimeSecond.Text = DateTime.Now.ToString("ss");
            this.txtData.Text = convertTxtData();
            this.btnCmd02.Enabled = false;
            this.btnCmd02.BackColor = Color.AliceBlue;
            this.btnCmd02.Click += (sender, e) => {
                CMD02();
                this.txtData.Text = convertTxtData();
            };
            this.btnCmd00.Click += (sender, e) => {
                defaultCMD01();
                this.txtData.Text = convertTxtData();
            };
            this.lbStatus.Text = this.tcp.PortStatus;

            this.cboRxIpAddress.Items.Add(Lecip.Utility.Utility.GetIpV4Address(string.Empty));
            this.cboRxIpAddress.SelectedIndex = 0;

            this.cboTxIpAddress.Items.Add(Lecip.Utility.Utility.GetIpV4Address(string.Empty));
            this.cboTxIpAddress.SelectedIndex = 0;


        }
        #endregion


        #region Private Method
        private void open()
        {
            if (this.tcp.IsOpen) return;

            this.tcp.SendIpAddr = this.cboTxIpAddress.Text;
            this.tcp.RecvIpAddr = this.cboRxIpAddress.Text;
            this.tcp.SendPortNo = (int)this.nudTxPortNo.Value;
            this.tcp.RecvPortNo = (int)this.nudRxPortNo.Value;

            this.tcp.Open();
            this.lbStatus.Text = this.tcp.PortStatus;
            this.cboRxIpAddress.Enabled = false;
            this.cboTxIpAddress.Enabled = false;
            this.nudRxPortNo.Enabled = false;
            this.nudTxPortNo.Enabled = false;
            this.txtData.Text = convertTxtData();
        }

        private void close()
        {
            if (!this.tcp.IsOpen) return;

            this.tcp.Close();
            this.lbStatus.Text = this.tcp.PortStatus;
            this.cboRxIpAddress.Enabled = true;
            this.cboTxIpAddress.Enabled = true;
            this.nudRxPortNo.Enabled = true;
            this.nudTxPortNo.Enabled = true;
            this.txtData.Text = "00";
        }

        private void send()
        {
            sequenceNumber = (byte)(sequenceNumber % SEQUENCE_MAX + 1);
            this.txtData.Text = convertTxtData();
            string sendData = this.txtData.Text;
            sendData = sendData.Replace("\r\n", "");
            sendData = sendData.Replace(" ", "");

            byte[] s = Util.ToByteArray(sendData);
            this.tcp.Send(s, s.Length);
        }

        private void appendLog()
        {
            if (this.InvokeRequired)
                this.Invoke(new Action<string>(appendLog), this.tcp.ErrorMessage);
            else
                appendLog(this.tcp.ErrorMessage);
        }
        private void analyze()
        {
            this.txtRawData.Text = convertByteString(this.tcp.RxRawData);

            string ret = this.txtRawData.Text;


            string stx = ret.Substring(0, 2);


            string datasum = ret.Substring(2, 4);


            string datasizesum = ret.Substring(6, 2);

            string cmd = ret.Substring(8, 2);

            string strCmd = (cmd == "03") ? "(運行系統・停留所変更通知の返答結果)" : "(ステータス変更通知の返答結果)";

            string seq = ret.Substring(10, 2);

            string data = ret.Substring(12, 0);

            string datasize = ret.Substring(12, 2);

            string etx = ret.Substring(14, 2);

            string txt = stx + "\r\n" +
                                "\r\n" +
                                datasum + "\r\n" +
                                    "\r\n" +
                                    datasizesum + "\r\n" +
                                        "\r\n" +
                                        cmd + strCmd + "\r\n" +
                                            "\r\n" +
                                            seq + "\r\n" +
                                                "\r\n" +
                                                data + "\r\n" +
                                                    "\r\n" +
                                                    datasize + "\r\n" +
                                                        "\r\n" +
                                                        etx + "\r\n";

            this.lbnAnalyzeRxData.Text = txt;
        }

        private void appendLog(string log)
        {
            this.txtLog.AppendText(log + "\r\n");
        }

        private void defaultCMD01()
        {
            this.btnCmd00.Enabled = false;
            this.btnCmd00.BackColor = Color.AliceBlue;
            this.btnCmd02.Enabled = true;
            this.btnCmd02.BackColor = Color.Transparent;
        }
        private void CMD02()
        {
            this.btnCmd02.Enabled = false;
            this.btnCmd02.BackColor = Color.AliceBlue;
            this.btnCmd00.Enabled = true;
            this.btnCmd00.BackColor = Color.Transparent;
        }

        private string convertTxtData()
        {

            this.startHour.Text = DateTime.Now.ToString("hh");
            this.startTimeMinutues.Text = DateTime.Now.ToString("mm");
            this.startTimeSecond.Text = DateTime.Now.ToString("ss");

            string cmd = !this.btnCmd02.Enabled ? "02" : "00";

            string diaNoHex = Convert.ToInt32(this.diaNo.Value).ToString("X");
            diaNoHex = diaNoHex.PadLeft(6, '0');

            string routeId = this.routeId.Text;
            routeId = routeId.PadLeft(8, '0');

            string routeIdByte1Hex = Int16.Parse(routeId.Substring(0, 2)).ToString("X");
            routeIdByte1Hex = routeIdByte1Hex.PadLeft(2, '0');
            string routeIdByte2Hex = Int16.Parse(routeId.Substring(2, 2)).ToString("X");
            routeIdByte2Hex = routeIdByte2Hex.PadLeft(2, '0');
            string routeIdByte3Hex = Int16.Parse(routeId.Substring(4, 2)).ToString("X");
            routeIdByte3Hex = routeIdByte3Hex.PadLeft(2, '0');
            string routeIdByte4Hex = Int16.Parse(routeId.Substring(6, 2)).ToString("X");
            routeIdByte4Hex = routeIdByte4Hex.PadLeft(2, '0');
            string routeIdByteHex = routeIdByte1Hex + routeIdByte2Hex + routeIdByte3Hex + routeIdByte4Hex;

            string second = this.startTimeSecond.Text;
            second = second.PadLeft(2, '0');

            string secondHex = Convert.ToInt32(this.startTimeSecond.Value).ToString("X");
            secondHex = secondHex.PadLeft(2, '0');


            string minutes = this.startTimeMinutues.Text;
            minutes = minutes.PadLeft(2, '0');

            string minutesHex = Convert.ToInt32(this.startTimeMinutues.Value).ToString("X");
            minutesHex = minutesHex.PadLeft(2, '0');

            string hours = this.startHour.Text;
            hours = hours.PadLeft(2, '0');

            string hoursHex = Convert.ToInt32(this.startHour.Value).ToString("X");
            hoursHex = hoursHex.PadLeft(2, '0');

            string startTime = hours + minutes + second;
            string startTimeHex = hoursHex + minutesHex + secondHex;

            string stopSeq = this.stopSeqNumber.Text;
            stopSeq = stopSeq.PadLeft(4, '0');

            string stopSeqByte1Hex = Int16.Parse(stopSeq.Substring(0, 2)).ToString("X");
            stopSeqByte1Hex = stopSeqByte1Hex.PadLeft(2, '0');

            string stopSeqByte2Hex = Int16.Parse(stopSeq.Substring(2, 2)).ToString("X");
            stopSeqByte2Hex = stopSeqByte2Hex.PadLeft(2, '0');

            string stopSeqByteHex = stopSeqByte1Hex + stopSeqByte2Hex;


            string BCDStr = routeId + hours + minutes + second + stopSeq;

            string signalStrengthHex = Convert.ToInt32(this.signalStrength.Value).ToString("X");
            signalStrengthHex = signalStrengthHex.PadLeft(4, '0');
            string seq = sequenceNumber.ToString("X").PadLeft(2, '0');

            string testTxt = cmd + seq + diaNoHex + routeIdByteHex + startTimeHex + stopSeqByteHex + signalStrengthHex;
            int total = StringToByteArray(testTxt).Sum(x => x);
            string totalStr = string.Format("{0:x}", -total);

            string dataSum = totalStr.Substring(totalStr.Length - 2, 2);

            return "020010F0" + testTxt + calSum(testTxt) + "03";
            //return "020010F0" + cmd + "04" + diaNoHex + routeId + startTime + stopSeq + signalStrengthHex + calSum(testTxt)+"03";
            //return "1";
        }

        public static byte[] StringToByteArray(string text)
        {
            return Enumerable.Range(0, text.Length)
                    .Where(x => x % 2 == 0)
                    .Select(x => Convert.ToByte(text.Substring(x, 2), 16))
                    .ToArray();
        }
        static string calSum(String data)
        {
            String input = "01020304000000a2ff";
            int output = Enumerable.Range(0, data.Length / 2)
                .Select(i => data.Substring(i * 2, 2))
                .Select(s => "0x" + s)
                .Select(s => Convert.ToInt32(s, 16))
                .Sum();
            output = -output & 0xff;
            return output.ToString("X2");
        }

        private string convertByteString(byte[] data, int length = -1)
        {
            if (length < 0) length = data.Length;
            return Util.ToString(data, 0, length);
        }
        #endregion

        #endregion

        private void FormMain_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void pnlLog_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void cboTxIpAddress_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbnAnalyzeRxData_TextChanged(object sender, EventArgs e)
        {

        }

        private void tmrPolling_Tick(object sender, EventArgs e)
        {
            if (!this.tcp.IsOpen) return;
            if (!chkAutoRes.Checked) return;
            send();
            if (!this.btnCmd02.Enabled && this.btnCmd00.Enabled) defaultCMD01();
        }
    }
}
