﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace Lecip.Net 
{

    #region TcpMsgType
    /// <summary> 通信メッセージ種別 </summary>
    public enum TcpMsgType
    {
        /// <summary> Tx:送信 </summary>
        Tx,
        /// <summary> Rx:受信 </summary>
        Rx,
        /// <summary> TxMsg:送信メッセージ </summary>
        TxMsg,
        /// <summary> RxMsg:受信メッセージ </summary>
        RxMsg,
    }
    #endregion

    // State object for receiving data from remote device.
    public class StateObject {
        // Client socket.
        public Socket workSocket = null;
        // Size of receive buffer.
        public const int BufferSize = 256;
        // Receive buffer.
        public byte[] buffer = new byte[BufferSize];
        // Received data string.
        public StringBuilder sb = new StringBuilder();
    }


    /// <summary> UDP通信クラス </summary>
    public class TcpIF
    {

        #region Event Handler
        /// <summary> データ受信時のイベントハンドラ </summary>
        public event EventHandler TcpIFDataReceived;

        /// <summary> エラー発生時のイベントハンドラ </summary>
        public event EventHandler TcpIFErrorReceived;

        /// <summary> 受信タイムアウト発生時のイベントハンドラ </summary>
        public event EventHandler TcpIFTimeoutReceived;

        /// <summary> 通信ログ保存コールバック </summary>
        public delegate void WriteLogEventHandler(object sender, TcpMsgType type, string log);
        /// <summary> 通信ログ保存イベントハンドラ </summary>
        public event WriteLogEventHandler TcpIFWriteLog;

        #endregion

        public static ManualResetEvent allDone      = new ManualResetEvent(false);
        private static ManualResetEvent connectDone = new ManualResetEvent(false);
        private static ManualResetEvent sendDone    = new ManualResetEvent(false);

        #region Property

        /// <summary> 受信タイムアウト(msec) </summary>
        public int ReceiveTimeout { get; set; }

        /// <summary> 通信状態フラグ </summary>
        public bool IsOpen { get; private set; }

        /// <summary> 送信先IPアドレス </summary>
        public string SendIpAddr { get; set; }

        /// <summary> 送信先ポート番号 </summary>
        public int SendPortNo { get; set; }

        /// <summary> 受信IPアドレス(表示にのみ使用) </summary>
        public string RecvIpAddr { get; set; }
        /// <summary> 受信ポート番号 </summary>

        public int RecvPortNo { get; set; }

        /// <summary> TCP受信時の全受信データ </summary>
        public byte[] RxRawData { get; private set; }

        /// <summary> 受信タイムアウトタイマー </summary>
        private System.Timers.Timer recvTimeoutTimer;

        /// <summary> 通信ログファイル書込みクラス </summary>
        private FileLog fileLog;

        /// <summary> 通信ログファイル書込みONOFFフラグ </summary>
        private bool enableWriteLog;


        /// <summary> 通信ログファイル出力ONOFFフラグ </summary>
        public bool EnableWriteLog
        {
            get { return this.enableWriteLog; }

            set
            {
                this.enableWriteLog = value;
                if (this.fileLog != null) this.fileLog.Enabled = value;
            }
        }


        /// <summary> 通信ログのファイルパス </summary>
        public string FileLogPath { get; set; }

        /// <summary> シミュレータの状態を文字列で返す </summary>
        public string PortStatus { get { return $"[{((this.IsOpen) ? "動作中" : "停止中")}] Main(受信)[{this.RecvIpAddr}]→UI(送信先)[{this.SendIpAddr}]"; } }

        /// <summary> エラーメッセージ </summary>
        public string ErrorMessage { get; private set; }



        #endregion


        #region Constructor
        /// <summary>コンストラクタ</summary>
        public TcpIF()
        {
            this.ReceiveTimeout = 2000;
            this.IsOpen = false;

            this.fileLog = new FileLog();
            this.EnableWriteLog = false;

            this.SendIpAddr = "192.168.254.25";
            this.SendPortNo = 52001;

            this.RecvIpAddr = "192.168.254.25";
            this.RecvPortNo = 52003;

            this.RxRawData = null;
        }
        #endregion



        #region Public Method


        

        public void tcpServerStart()
        {
            // create server to receive msg 
            // Create a TCP/IP socket.
            // Socket listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp );

            // string ipAddr = "10.10.34.99";
            // int PORT = 5555; 
            string ipAddr = this.RecvIpAddr;
            int PORT = this.RecvPortNo;

            IPAddress iPAddress = IPAddress.Parse(ipAddr);
            IPEndPoint localEndPoint = new IPEndPoint(iPAddress, PORT);

            Socket listener = new Socket(iPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and listen for incoming connections.
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                //受信タイムアウトタイマー初期化
                this.recvTimeoutTimer = new System.Timers.Timer(this.ReceiveTimeout);
                this.recvTimeoutTimer.Stop();
                this.recvTimeoutTimer.Elapsed += new System.Timers.ElapsedEventHandler(elapsedTimeout);

                while (true)
                {
                    // Set the event to nonsignaled state.
                    allDone.Reset();

                    // Start an asynchronous socket to listen for connections.
                    Console.WriteLine("Waiting for a connection...");
                    listener.BeginAccept(new AsyncCallback(AcceptCallback), listener);

                    // Wait until a connection is made before continuing.
                    allDone.WaitOne();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();

        }



        /// <summary>UDP受信処理を開始</summary>
        public void Open()
        {

            this.IsOpen = true;
            
            
            tcpServerStart();


        }



        /// <summary>UDP通信を終了する。送信側、受信側両方ともCloseする</summary>
        public void Close()
        {
            this.IsOpen = false;

            if (this.recvTimeoutTimer != null)
            {
                this.recvTimeoutTimer.Dispose();
                this.recvTimeoutTimer = null;
            }

            this.fileLog.Close();

        }

        /// <summary>
        /// 受信タイムアウト発生イベント処理(タイマー起動)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void elapsedTimeout(object sender, System.Timers.ElapsedEventArgs e)
        {
            setTimeout();

            // sending msg to antoher sever priodically each 2 seconds
            // Send();

            // System.Timers.Timer timer = (System.Timers.Timer)sender;
            // timer.Stop();
        }

        private void setTimeout()
        {
            Console.WriteLine("受信タイムアウト ===========>>>");

            this.ErrorMessage = "受信タイムアウト";

            writeLog(TcpMsgType.RxMsg, this.ErrorMessage);

            this.TcpIFTimeoutReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>エラーイベントを起こす</summary>
        protected void SetError(TcpMsgType type, string errorMessage)
        {
            StopReceiveTimeout();

            this.ErrorMessage = errorMessage;

            writeLog(type, errorMessage);

            this.TcpIFErrorReceived?.Invoke(this, new EventArgs());
        }


        /// <summary>受信タイムアウト処理を開始する</summary>
        public void StartReceiveTimeout()
        {
            if (this.recvTimeoutTimer == null) return;

            this.recvTimeoutTimer.Stop();
            this.recvTimeoutTimer.Start();

            Console.WriteLine("start timer ======================>>>>");
        }

        /// <summary>受信タイムアウト処理を停止する</summary>
        public void StopReceiveTimeout()
        {
            if (this.recvTimeoutTimer == null) return;

            this.recvTimeoutTimer.Stop();
        }




        // In TCP when accept -> create new socket with appropriate port
        public void AcceptCallback(IAsyncResult ar) {
            // Signal the main thread to continue.
            allDone.Set();

            // Get the socket that handles the client request.
            Socket listener = (Socket)ar.AsyncState;
            Socket handler = listener.EndAccept(ar);

            // Create the state object.
            StateObject state = new StateObject();
            state.workSocket = handler;
            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state);
        }


        // Handling for received msg --> in this case, print out screen only !!! 
        //public void ReadCallback(IAsyncResult ar)
        //{
        //    String content = String.Empty;

        //    // Retrieve the state object and the handler socket
        //    // from the asynchronous state object.
        //    StateObject state = (StateObject)ar.AsyncState;
        //    Socket handler = state.workSocket;

        //    // Read data from the client socket. 
        //    int bytesRead = handler.EndReceive(ar);

        //    if (bytesRead > 0)
        //    {
        //        // There  might be more data, so store the data received so far.
        //        state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, bytesRead));

        //        // Check for end-of-file tag. If it is not there, read 
        //        // more data.
        //        content = state.sb.ToString();
        //        if (content.IndexOf("<EOF>") > -1)
        //        {
        //            // All the data has been read from the 
        //            // client. Display it on the console.
        //            Console.WriteLine("Read {0} bytes from socket. \n Data : {1}", content.Length, content);
        //            // Echo the data back to the client.

        //            // Send(handler, content);  --> must to handling another method

        //            // send to servr for testing purpose!!!!!!!!
        //            //Send();

        //            // due to testing receiving continuously -> disable Send() msg above


        //        }
        //        else
        //        {
        //            // Not all data received. Get more.
        //            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state);
        //        }
        //    }
        //}


        /// <summary> データ受信処理(イベント受信) </summary>
        /// <param name="ar"></param>
        public void ReadCallback(IAsyncResult ar)
        {
            if (!this.IsOpen) return;

            StopReceiveTimeout();

            // Retrieve the state object and the handler socket
            // from the asynchronous state object.
            StateObject state = (StateObject)ar.AsyncState;
            Socket handler = state.workSocket;


            try
            {


                // Read data from the client socket. 
                int bytesRead = handler.EndReceive(ar);
                this.RxRawData = state.buffer;

                string rxData = Util.ToString(state.buffer, 0, bytesRead);
                Console.WriteLine("Received Data : " + rxData + " {0} Bytes", bytesRead);

                setReceive();
            }
            catch (SocketException ex)
            {
                SetError(TcpMsgType.RxMsg, ex.Message.Replace("\r\n", ""));
            }
            catch (ObjectDisposedException ex)
            {
                SetError(TcpMsgType.RxMsg, ex.Message.Replace("\r\n", ""));
            }

            //再びデータ受信を開始する
            if (this.IsOpen)
            {
                try
                {
                    handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state);
                }
                catch (Exception ex)
                {
                    SetError(TcpMsgType.RxMsg, ex.Message.Replace("\r\n", ""));
                }
            }
        }


        /// <summary>受信イベントを起こす</summary>
        private void setReceive()
        {
            writeLog(TcpMsgType.Rx, this.RxRawData);

            this.TcpIFDataReceived?.Invoke(this, new EventArgs());
        }




        private void ConnectCallback(IAsyncResult ar)
        {
            try {
                // retrieve the socket from state object
                Socket sc = (Socket)ar.AsyncState;

                // complete the connection 
                sc.EndConnect(ar);

                Console.WriteLine("Socket connection to {0}", sc.RemoteEndPoint.ToString());

                // signal that the connection has been made
                connectDone.Set();

            } catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

        }


        private string convertByteString(byte[] data)
        {
            StringBuilder s = new StringBuilder();
            foreach (byte e in data)
            {
                s.Append(e);
            }
            return s.ToString();
        }


        /// <summary>
        /// データを送信する
        /// </summary>
        /// <param name="data">送信データ</param>
        /// <param name="length">データ長</param>
        /// <returns></returns>
        public bool Send(byte[] data, int length)
        // public void Send()
        {


            writeLog(TcpMsgType.Tx, data, length);


            //string paraStr = Encoding.ASCII.GetString(data, 0, length);
            string paraStr = convertByteString(data);
            Console.WriteLine(" data from upper layer  : " + paraStr);


            // start timer 
            StartReceiveTimeout();



            // create socket request to server
            string ipAddr = this.SendIpAddr;
            int port = this.SendPortNo;


            IPAddress ipAddress = IPAddress.Parse(ipAddr);
            IPEndPoint remoteEP = new IPEndPoint(ipAddress, port);

            Socket sc = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            sc.BeginConnect(remoteEP, new AsyncCallback(ConnectCallback), sc);
            connectDone.WaitOne();


            //string msg = "This is a test<EOF>";
            //send(sc, msg);


            send(sc, data, length);

            sendDone.WaitOne();

            //Console.WriteLine("send to server message : " + msg);
            Console.WriteLine("start send data to sever ============>>> ");

            // ensure that all data is sent and received on the connected socket before it is closed
            sc.Shutdown(SocketShutdown.Both);
            sc.Close();

            return true;
        }

        private void send(Socket sc, byte[] data, int len)
        {
            byte[] byteData = data;

            sc.BeginSend(byteData, 0, len, 0, new AsyncCallback(SendCB), sc);
        }

        private void send(Socket sc, string msg)
        {
            byte[] byteData = Encoding.ASCII.GetBytes(msg);

            sc.BeginSend(byteData, 0, byteData.Length, 0, new AsyncCallback(SendCB), sc);
        }


        private void SendCB(IAsyncResult ar) {
            try {
                Socket client = (Socket)ar.AsyncState;

                int sentBytes = client.EndSend(ar);
                Console.WriteLine("Send {0} bytes to server !!! ", sentBytes);

                sendDone.Set();

            } catch (Exception e)
            {
                //Console.WriteLine(e.ToString());
            }
        }


        #region WriteLog
        /// <summary>
        /// 通信ログにbyte配列データを16進表記で保存する
        /// </summary>
        /// <param name="type">MsgType</param>
        /// <param name="data">byte配列</param>
        /// <param name="length">通信ログ長(byte)指定無しはbyte配列長</param>
        private void writeLog(TcpMsgType type, byte[] data, int length = -1)
        {
            if (length < 0) length = data.Length;
            string log = Util.ToString(data, 0, length);
            writeLog(type, log);
        }

        /// <summary>
        /// 通信ログに文字列を保存する
        /// </summary>
        /// <param name="type"></param>
        /// <param name="log"></param>
        private void writeLog(TcpMsgType type, string log)
        {
            string writelog = $"{DateTime.Now:HH:mm:ss.fff} {type} {log}";

            if (this.enableWriteLog) this.fileLog.Write(this.FileLogPath, writelog); //ファイルに通信ログを書き込む

            this.TcpIFWriteLog?.Invoke(this, type, writelog);
        }
        #endregion



        #endregion
    }

}