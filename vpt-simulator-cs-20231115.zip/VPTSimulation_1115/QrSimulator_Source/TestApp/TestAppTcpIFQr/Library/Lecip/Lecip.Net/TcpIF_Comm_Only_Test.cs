﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace Lecip.Net 
{

    #region TcpMsgType
    /// <summary> 通信メッセージ種別 </summary>
    public enum TcpMsgType
    {
        /// <summary> Tx:送信 </summary>
        Tx,
        /// <summary> Rx:受信 </summary>
        Rx,
        /// <summary> TxMsg:送信メッセージ </summary>
        TxMsg,
        /// <summary> RxMsg:受信メッセージ </summary>
        RxMsg,
    }
    #endregion

    // State object for receiving data from remote device.
    public class StateObject {
        // Client socket.
        public Socket workSocket = null;
        // Size of receive buffer.
        public const int BufferSize = 256;
        // Receive buffer.
        public byte[] buffer = new byte[BufferSize];
        // Received data string.
        public StringBuilder sb = new StringBuilder();
    }


    /// <summary> UDP通信クラス </summary>
    public class TcpIF
    {

        #region Event Handler
        /// <summary> データ受信時のイベントハンドラ </summary>
        public event EventHandler TcpIFDataReceived;

        /// <summary> エラー発生時のイベントハンドラ </summary>
        public event EventHandler TcpIFErrorReceived;

        /// <summary> 受信タイムアウト発生時のイベントハンドラ </summary>
        public event EventHandler TcpIFTimeoutReceived;

        /// <summary> 通信ログ保存コールバック </summary>
        public delegate void WriteLogEventHandler(object sender, TcpMsgType type, string log);
        /// <summary> 通信ログ保存イベントハンドラ </summary>
        public event WriteLogEventHandler TcpIFWriteLog;

        #endregion


        #region Property

        public static ManualResetEvent allDone      = new ManualResetEvent(false);
        private static ManualResetEvent connectDone = new ManualResetEvent(false);
        private static ManualResetEvent sendDone    = new ManualResetEvent(false);


        // socket TCP server listen message from clients
        public Socket serverSocket;

        /// <summary> 受信タイムアウト(msec) </summary>
        public int ReceiveTimeout { get; set; }

        /// <summary> 通信状態フラグ </summary>
        public bool IsOpen { get; private set; }

        /// <summary> 送信先IPアドレス </summary>
        public string SendIpAddr { get; set; }

        /// <summary> 送信先ポート番号 </summary>
        public int SendPortNo { get; set; }

        /// <summary> 受信IPアドレス(表示にのみ使用) </summary>
        public string RecvIpAddr { get; set; }
        /// <summary> 受信ポート番号 </summary>

        public int RecvPortNo { get; set; }

        /// <summary> TCP受信時の全受信データ </summary>
        public byte[] RxRawData { get; private set; }

        /// <summary> 受信タイムアウトタイマー </summary>
        private System.Timers.Timer recvTimeoutTimer;

        // /// <summary> 通信ログファイル書込みクラス </summary>
        // private FileLog fileLog;

        // /// <summary> 通信ログファイル書込みONOFFフラグ </summary>
        // private bool enableWriteLog;


        // /// <summary> 通信ログファイル出力ONOFFフラグ </summary>
        // public bool EnableWriteLog
        // {
            // get { return this.enableWriteLog; }

            // set
            // {
                // this.enableWriteLog = value;
                // if (this.fileLog != null) this.fileLog.Enabled = value;
            // }
        // }


        /// <summary> 通信ログのファイルパス </summary>
        public string FileLogPath { get; set; }

        /// <summary> シミュレータの状態を文字列で返す </summary>
        // public string PortStatus { get { return $"[{((this.IsOpen) ? "動作中" : "停止中")}] Main(受信)[{this.RecvIpAddr}]→UI(送信先)[{this.SendIpAddr}]"; } }

        /// <summary> エラーメッセージ </summary>
        public string ErrorMessage { get; private set; }



        #endregion


        #region Constructor
        /// <summary>コンストラクタ</summary>
        public TcpIF()
        {
            this.ReceiveTimeout = 2000;
            this.IsOpen = false;

            // this.fileLog = new FileLog();
            // this.EnableWriteLog = false;

            this.SendIpAddr = "192.168.254.25";
            this.SendPortNo = 52001;

            this.RecvIpAddr = "192.168.254.25";
            this.RecvPortNo = 52003;

            this.RxRawData = null;
        }
        #endregion



        #region Public Method


        public void RcvManager()
        {

            Console.WriteLine("RcvManager fucntion is started ...");

           TcpServerStart();
            

        } 


        public int TcpServerStart()
        {
            int rs = -1; 

            // create server to receive msg 
            // Create a TCP/IP socket.
            string ipAddr   = this.RecvIpAddr;
            int PORT        = this.RecvPortNo;

            IPAddress iPAddress = IPAddress.Parse(ipAddr);
            IPEndPoint localEndPoint = new IPEndPoint(iPAddress, PORT);

            Socket listener = new Socket(iPAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            this.serverSocket = listener;

            // Bind the socket to the local endpoint and listen for incoming connections.
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);



                while (true)
                {
                    // Once close button is clicked, close socket
                    if (!this.IsOpen)
                    {
                        listener.Shutdown(SocketShutdown.Both);
                        listener.Close();

                        Console.WriteLine("=============================>> closed socket ");

                        break;
                    }

                    // Set the event to nonsignaled state.
                    allDone.Reset();

                    // Start an asynchronous socket to listen for connections.
                    Console.WriteLine("Waiting for a connection ... ");

                    listener.BeginAccept(new AsyncCallback(AcceptCallback), listener);
                   

                    rs = 0;

                    // Wait until a connection is made before continuing.
                    allDone.WaitOne();
                    
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();

            return rs;

        }



        /// <summary>UDP受信処理を開始</summary>
        public void Open()
        {

            this.IsOpen = true;

            RcvManager();


            //受信タイムアウトタイマー初期化
            this.recvTimeoutTimer = new System.Timers.Timer(this.ReceiveTimeout);
            this.recvTimeoutTimer.Stop();
            this.recvTimeoutTimer.Elapsed += new System.Timers.ElapsedEventHandler(elapsedTimeout);

        }


        /// <summary>UDP通信を終了する。送信側、受信側両方ともCloseする</summary>
        public void Close()
        {
            this.IsOpen = false;

            if (this.recvTimeoutTimer != null)
            {
                this.recvTimeoutTimer.Dispose();
                this.recvTimeoutTimer = null;
            }

            // this.fileLog.Close();

            this.serverSocket.Close();

        }

        /// <summary>
        /// 受信タイムアウト発生イベント処理(タイマー起動)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void elapsedTimeout(object sender, System.Timers.ElapsedEventArgs e)
        {
            setTimeout();

            //System.Timers.Timer timer = (System.Timers.Timer)sender;
            //timer.Stop();

            StopReceiveTimeout();
        }

        private void setTimeout()
        {
            Console.WriteLine("受信タイムアウト ===========>>>");

            this.ErrorMessage = "受信タイムアウト";

            // writeLog(TcpMsgType.RxMsg, this.ErrorMessage);

            // this.TcpIFTimeoutReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>エラーイベントを起こす</summary>
        protected void SetError(TcpMsgType type, string errorMessage)
        {
            StopReceiveTimeout();

            this.ErrorMessage = errorMessage;

            // writeLog(type, errorMessage);

            // this.TcpIFErrorReceived?.Invoke(this, new EventArgs());
        }


        /// <summary>受信タイムアウト処理を開始する</summary>
        public void StartReceiveTimeout()
        {
            if (this.recvTimeoutTimer == null) return;

            this.recvTimeoutTimer.Stop();
            this.recvTimeoutTimer.Start();

            Console.WriteLine("start timer ======================>>>>");
        }

        /// <summary>受信タイムアウト処理を停止する</summary>
        public void StopReceiveTimeout()
        {
            if (this.recvTimeoutTimer == null) return;

            this.recvTimeoutTimer.Stop();
        }




        // In TCP when accept -> create new socket with appropriate port
        public void AcceptCallback(IAsyncResult ar) {

            if (!this.IsOpen) return;

            // Signal the main thread to continue.
            allDone.Set();

            // Get the socket that handles the client request.
            Socket listener = (Socket)ar.AsyncState;
            Socket handler = listener.EndAccept(ar);


            Console.WriteLine(" [ AcceptCallback ] =============================>> socket -->>  E S T A B L I S H E D ");

            // Create the state object.
            StateObject state = new StateObject();
            state.workSocket = handler;
            handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state);
        }


        /// <summary> データ受信処理(イベント受信) </summary>
        /// <param name="ar"></param>
        public void ReadCallback(IAsyncResult ar)
        {
            if (!this.IsOpen) return;

            StopReceiveTimeout();

            // Retrieve the state object and the handler socket
            // from the asynchronous state object.
            StateObject state = (StateObject)ar.AsyncState;
            Socket handler = state.workSocket;


            try
            {

                // Read data from the client socket. 
                int bytesRead = handler.EndReceive(ar);
                this.RxRawData = state.buffer;

                //Console.WriteLine(" [ ReadCallback ] =============================>> Received : {0} Bytes ", bytesRead);


                if (bytesRead > 0)
                {

                    Console.WriteLine(" [ ReadCallback ] =============================>> Received : {0} Bytes ", bytesRead);


                    string rxMsg = Encoding.ASCII.GetString(state.buffer, 0, bytesRead);

                    Console.WriteLine(" [ ReadCallback ] =============================>> Received :  " + rxMsg);


                    Console.WriteLine(" [ ReadCallback ] =============================>> R E A D - D A T A ");

                    // string rxData = Util.ToString(state.buffer, 0, bytesRead);
                    // Console.WriteLine("Received Data : " + rxData + " {0} Bytes", bytesRead);

                    setReceive();

                }
            }
            catch (SocketException ex)
            {
                // SetError(TcpMsgType.RxMsg, ex.Message.Replace("\r\n", ""));
            }
            catch (ObjectDisposedException ex)
            {
                // SetError(TcpMsgType.RxMsg, ex.Message.Replace("\r\n", ""));
            }

            //再びデータ受信を開始する
            if (this.IsOpen)
            {
                try
                {
                    handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state);
                }
                catch (Exception ex)
                {
                    // SetError(TcpMsgType.RxMsg, ex.Message.Replace("\r\n", ""));
                }
            }
        }


        /// <summary>受信イベントを起こす</summary>
        private void setReceive()
        {
            // writeLog(TcpMsgType.Rx, this.RxRawData);

            string rxMsg = convertByteString(this.RxRawData);


            Console.WriteLine("setReceive : received data ==================================>>. " + rxMsg);

            // this.TcpIFDataReceived?.Invoke(this, new EventArgs());
        }




        private void ConnectCallback(IAsyncResult ar)
        {
            try {
                // retrieve the socket from state object
                Socket sc = (Socket)ar.AsyncState;

                // complete the connection 
                sc.EndConnect(ar);

                Console.WriteLine("Socket connection to {0}", sc.RemoteEndPoint.ToString());

                // signal that the connection has been made
                connectDone.Set();

            } catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

        }


        private string convertByteString(byte[] data)
        {
            StringBuilder s = new StringBuilder();
            foreach (byte e in data)
            {
                s.Append(e);
            }
            return s.ToString();
        }


        /// <summary>
        /// データを送信する
        /// </summary>
        /// <param name="data">送信データ</param>
        /// <param name="length">データ長</param>
        /// <returns></returns>
        public bool Send(byte[] data, int length)
        // public void Send()
        {

            if (!this.IsOpen) return false;

            // writeLog(TcpMsgType.Tx, data, length);


            //string paraStr = Encoding.ASCII.GetString(data, 0, length);
            string paraStr = convertByteString(data);
            Console.WriteLine(" data from upper layer  : " + paraStr);


            // start timer 
            StartReceiveTimeout();



            // create socket request to server
            string ipAddr = this.SendIpAddr;
            int port = this.SendPortNo;


            IPAddress ipAddress = IPAddress.Parse(ipAddr);
            IPEndPoint remoteEP = new IPEndPoint(ipAddress, port);

            Socket sc = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            sc.BeginConnect(remoteEP, new AsyncCallback(ConnectCallback), sc);
            connectDone.WaitOne();


            //string msg = "This is a test<EOF>";
            //send(sc, msg);


            send(sc, data, length);

            sendDone.WaitOne();

            //Console.WriteLine("send to server message : " + msg);
            Console.WriteLine("start send data to sever ============>>> ");

            // ensure that all data is sent and received on the connected socket before it is closed
            sc.Shutdown(SocketShutdown.Both);
            sc.Close();

            return true;
        }

        private void send(Socket sc, byte[] data, int len)
        {
            

            byte[] byteData = data;

            sc.BeginSend(byteData, 0, len, 0, new AsyncCallback(SendCB), sc);
        }

        private void send(Socket sc, string msg)
        {
            byte[] byteData = Encoding.ASCII.GetBytes(msg);

            sc.BeginSend(byteData, 0, byteData.Length, 0, new AsyncCallback(SendCB), sc);
        }


        private void SendCB(IAsyncResult ar) {
            try {
                Socket client = (Socket)ar.AsyncState;

                int sentBytes = client.EndSend(ar);
                Console.WriteLine("Send {0} bytes to server !!! ", sentBytes);

                sendDone.Set();

            } catch (Exception e)
            {
                //Console.WriteLine(e.ToString());
            }
        }



        #endregion
        
        
        public static void Main(string[] arg)
        {
            TcpIF test = new TcpIF();
            test.Open();
        }
        

    }
    
    
    

        

}