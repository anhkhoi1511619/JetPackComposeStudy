﻿namespace TestAppTcpIFQr
{
    partial class FormMain
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.pnlLog = new System.Windows.Forms.Panel();
            this.lbStatus = new System.Windows.Forms.Label();
            this.cboRxIpAddress = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.nudRxPortNo = new System.Windows.Forms.NumericUpDown();
            this.chkAutoRes = new System.Windows.Forms.CheckBox();
            this.nudTxPortNo = new System.Windows.Forms.NumericUpDown();
            this.signalStrength = new System.Windows.Forms.NumericUpDown();
            this.stopSeqNumber = new System.Windows.Forms.NumericUpDown();
            this.routeId = new System.Windows.Forms.NumericUpDown();
            this.diaNo = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.startHour = new System.Windows.Forms.NumericUpDown();
            this.startTimeMinutues = new System.Windows.Forms.NumericUpDown();
            this.startTimeSecond = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cboTxIpAddress = new System.Windows.Forms.ComboBox();
            this.lbnRxData = new System.Windows.Forms.Label();
            this.txtRawData = new System.Windows.Forms.TextBox();
            this.lbnAnalyzeRxData = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tcConnect = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnCmd02 = new System.Windows.Forms.Button();
            this.btnCmd00 = new System.Windows.Forms.Button();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.tmrPolling = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nudRxPortNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTxPortNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalStrength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopSeqNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.routeId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diaNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startHour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startTimeMinutues)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startTimeSecond)).BeginInit();
            this.tcConnect.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(5, 74);
            this.button2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 34);
            this.button2.TabIndex = 1;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.Location = new System.Drawing.Point(942, 4);
            this.button3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(125, 34);
            this.button3.TabIndex = 2;
            this.button3.Text = "Send";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // txtLog
            // 
            this.txtLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLog.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtLog.Location = new System.Drawing.Point(930, 140);
            this.txtLog.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(117, 34);
            this.txtLog.TabIndex = 3;
            // 
            // pnlLog
            // 
            this.pnlLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLog.Location = new System.Drawing.Point(5, 4);
            this.pnlLog.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.pnlLog.Name = "pnlLog";
            this.pnlLog.Size = new System.Drawing.Size(1057, 51);
            this.pnlLog.TabIndex = 4;
            this.pnlLog.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlLog_Paint);
            // 
            // lbStatus
            // 
            this.lbStatus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbStatus.Location = new System.Drawing.Point(5, 64);
            this.lbStatus.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(1057, 54);
            this.lbStatus.TabIndex = 5;
            this.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cboRxIpAddress
            // 
            this.cboRxIpAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboRxIpAddress.FormattingEnabled = true;
            this.cboRxIpAddress.Items.AddRange(new object[] {
            "192.168.254.10"});
            this.cboRxIpAddress.Location = new System.Drawing.Point(360, 12);
            this.cboRxIpAddress.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.cboRxIpAddress.Name = "cboRxIpAddress";
            this.cboRxIpAddress.Size = new System.Drawing.Size(201, 26);
            this.cboRxIpAddress.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(195, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 18);
            this.label1.TabIndex = 9;
            this.label1.Text = "送信先：IPアドレス";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 81);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 18);
            this.label2.TabIndex = 10;
            this.label2.Text = "受信先:IPアドレス";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtData
            // 
            this.txtData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtData.Location = new System.Drawing.Point(138, 140);
            this.txtData.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtData.Size = new System.Drawing.Size(779, 34);
            this.txtData.TabIndex = 13;
            this.txtData.Text = "00";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 144);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 18);
            this.label5.TabIndex = 14;
            this.label5.Text = "Tx:送信データ";
            // 
            // nudRxPortNo
            // 
            this.nudRxPortNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nudRxPortNo.Location = new System.Drawing.Point(698, 12);
            this.nudRxPortNo.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.nudRxPortNo.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nudRxPortNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudRxPortNo.Name = "nudRxPortNo";
            this.nudRxPortNo.Size = new System.Drawing.Size(140, 25);
            this.nudRxPortNo.TabIndex = 15;
            this.nudRxPortNo.Value = new decimal(new int[] {
            53001,
            0,
            0,
            0});
            // 
            // chkAutoRes
            // 
            this.chkAutoRes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkAutoRes.AutoSize = true;
            this.chkAutoRes.Location = new System.Drawing.Point(961, 75);
            this.chkAutoRes.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.chkAutoRes.Name = "chkAutoRes";
            this.chkAutoRes.Size = new System.Drawing.Size(106, 22);
            this.chkAutoRes.TabIndex = 18;
            this.chkAutoRes.Text = "自動応答";
            this.chkAutoRes.UseVisualStyleBackColor = true;
            // 
            // nudTxPortNo
            // 
            this.nudTxPortNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nudTxPortNo.Location = new System.Drawing.Point(698, 74);
            this.nudTxPortNo.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.nudTxPortNo.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nudTxPortNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudTxPortNo.Name = "nudTxPortNo";
            this.nudTxPortNo.Size = new System.Drawing.Size(140, 25);
            this.nudTxPortNo.TabIndex = 19;
            this.nudTxPortNo.Value = new decimal(new int[] {
            53001,
            0,
            0,
            0});
            // 
            // signalStrength
            // 
            this.signalStrength.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.signalStrength.Location = new System.Drawing.Point(757, 48);
            this.signalStrength.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.signalStrength.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.signalStrength.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.signalStrength.Name = "signalStrength";
            this.signalStrength.Size = new System.Drawing.Size(115, 25);
            this.signalStrength.TabIndex = 15;
            this.signalStrength.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // stopSeqNumber
            // 
            this.stopSeqNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stopSeqNumber.Location = new System.Drawing.Point(593, 48);
            this.stopSeqNumber.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.stopSeqNumber.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.stopSeqNumber.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.stopSeqNumber.Name = "stopSeqNumber";
            this.stopSeqNumber.Size = new System.Drawing.Size(135, 25);
            this.stopSeqNumber.TabIndex = 15;
            this.stopSeqNumber.Value = new decimal(new int[] {
            102,
            0,
            0,
            0});
            // 
            // routeId
            // 
            this.routeId.Location = new System.Drawing.Point(425, 48);
            this.routeId.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.routeId.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.routeId.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.routeId.Name = "routeId";
            this.routeId.Size = new System.Drawing.Size(138, 25);
            this.routeId.TabIndex = 15;
            this.routeId.Value = new decimal(new int[] {
            9,
            0,
            0,
            0});
            // 
            // diaNo
            // 
            this.diaNo.Location = new System.Drawing.Point(273, 48);
            this.diaNo.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.diaNo.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.diaNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.diaNo.Name = "diaNo";
            this.diaNo.Size = new System.Drawing.Size(125, 25);
            this.diaNo.TabIndex = 15;
            this.diaNo.Value = new decimal(new int[] {
            14,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(93, 16);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 18);
            this.label3.TabIndex = 9;
            this.label3.Text = "Cmd：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(293, 20);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "運行ダイヤ：";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(882, 51);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 18);
            this.label6.TabIndex = 9;
            this.label6.Text = "開発時刻：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(450, 20);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 18);
            this.label7.TabIndex = 9;
            this.label7.Text = "系統番号：";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(628, 20);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 18);
            this.label8.TabIndex = 9;
            this.label8.Text = "駒番号：";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(773, 20);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 18);
            this.label9.TabIndex = 9;
            this.label9.Text = "電波強度：";
            // 
            // startHour
            // 
            this.startHour.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.startHour.Location = new System.Drawing.Point(993, 9);
            this.startHour.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.startHour.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.startHour.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.startHour.Name = "startHour";
            this.startHour.Size = new System.Drawing.Size(57, 25);
            this.startHour.TabIndex = 15;
            this.startHour.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // startTimeMinutues
            // 
            this.startTimeMinutues.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.startTimeMinutues.Location = new System.Drawing.Point(993, 44);
            this.startTimeMinutues.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.startTimeMinutues.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.startTimeMinutues.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.startTimeMinutues.Name = "startTimeMinutues";
            this.startTimeMinutues.Size = new System.Drawing.Size(57, 25);
            this.startTimeMinutues.TabIndex = 15;
            this.startTimeMinutues.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // startTimeSecond
            // 
            this.startTimeSecond.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.startTimeSecond.Location = new System.Drawing.Point(993, 81);
            this.startTimeSecond.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.startTimeSecond.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.startTimeSecond.Name = "startTimeSecond";
            this.startTimeSecond.Size = new System.Drawing.Size(57, 25);
            this.startTimeSecond.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(590, 20);
            this.label12.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 18);
            this.label12.TabIndex = 9;
            this.label12.Text = "ポスト：";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(590, 81);
            this.label13.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 18);
            this.label13.TabIndex = 9;
            this.label13.Text = "ポスト：";
            // 
            // cboTxIpAddress
            // 
            this.cboTxIpAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboTxIpAddress.FormattingEnabled = true;
            this.cboTxIpAddress.Items.AddRange(new object[] {
            "192.168.254.30"});
            this.cboTxIpAddress.Location = new System.Drawing.Point(360, 72);
            this.cboTxIpAddress.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.cboTxIpAddress.Name = "cboTxIpAddress";
            this.cboTxIpAddress.Size = new System.Drawing.Size(201, 26);
            this.cboTxIpAddress.TabIndex = 6;
            this.cboTxIpAddress.SelectedIndexChanged += new System.EventHandler(this.cboTxIpAddress_SelectedIndexChanged);
            // 
            // lbnRxData
            // 
            this.lbnRxData.AutoSize = true;
            this.lbnRxData.Location = new System.Drawing.Point(10, 104);
            this.lbnRxData.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbnRxData.Name = "lbnRxData";
            this.lbnRxData.Size = new System.Drawing.Size(109, 18);
            this.lbnRxData.TabIndex = 14;
            this.lbnRxData.Text = "Rx:受信データ";
            // 
            // txtRawData
            // 
            this.txtRawData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtRawData.Location = new System.Drawing.Point(10, 126);
            this.txtRawData.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.txtRawData.Multiline = true;
            this.txtRawData.Name = "txtRawData";
            this.txtRawData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtRawData.Size = new System.Drawing.Size(406, 34);
            this.txtRawData.TabIndex = 13;
            this.txtRawData.Text = "00";
            // 
            // lbnAnalyzeRxData
            // 
            this.lbnAnalyzeRxData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbnAnalyzeRxData.Location = new System.Drawing.Point(632, 51);
            this.lbnAnalyzeRxData.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.lbnAnalyzeRxData.Multiline = true;
            this.lbnAnalyzeRxData.Name = "lbnAnalyzeRxData";
            this.lbnAnalyzeRxData.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.lbnAnalyzeRxData.Size = new System.Drawing.Size(416, 284);
            this.lbnAnalyzeRxData.TabIndex = 13;
            this.lbnAnalyzeRxData.Text = "00";
            this.lbnAnalyzeRxData.TextChanged += new System.EventHandler(this.lbnAnalyzeRxData_TextChanged);
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(447, 21);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 18);
            this.label10.TabIndex = 14;
            this.label10.Text = "受信データ分解";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(5, 9);
            this.button1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 34);
            this.button1.TabIndex = 0;
            this.button1.Text = "Open";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // tcConnect
            // 
            this.tcConnect.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tcConnect.Controls.Add(this.tabPage1);
            this.tcConnect.Location = new System.Drawing.Point(20, 18);
            this.tcConnect.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tcConnect.Name = "tcConnect";
            this.tcConnect.SelectedIndex = 0;
            this.tcConnect.Size = new System.Drawing.Size(1080, 170);
            this.tcConnect.TabIndex = 20;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.chkAutoRes);
            this.tabPage1.Controls.Add(this.nudTxPortNo);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.cboRxIpAddress);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.cboTxIpAddress);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.nudRxPortNo);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tabPage1.Size = new System.Drawing.Size(1072, 138);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "設定パラメータ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Location = new System.Drawing.Point(20, 196);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1073, 232);
            this.tabControl2.TabIndex = 21;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.startTimeSecond);
            this.tabPage2.Controls.Add(this.signalStrength);
            this.tabPage2.Controls.Add(this.startTimeMinutues);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.startHour);
            this.tabPage2.Controls.Add(this.stopSeqNumber);
            this.tabPage2.Controls.Add(this.diaNo);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.btnCmd02);
            this.tabPage2.Controls.Add(this.btnCmd00);
            this.tabPage2.Controls.Add(this.routeId);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txtLog);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.txtData);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tabPage2.Size = new System.Drawing.Size(1065, 200);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "送信パラメータ";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnCmd02
            // 
            this.btnCmd02.Location = new System.Drawing.Point(10, 76);
            this.btnCmd02.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnCmd02.Name = "btnCmd02";
            this.btnCmd02.Size = new System.Drawing.Size(217, 34);
            this.btnCmd02.TabIndex = 2;
            this.btnCmd02.Text = "[02]系統・・・変更通知";
            this.btnCmd02.UseVisualStyleBackColor = true;
            // 
            // btnCmd00
            // 
            this.btnCmd00.Location = new System.Drawing.Point(10, 39);
            this.btnCmd00.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnCmd00.Name = "btnCmd00";
            this.btnCmd00.Size = new System.Drawing.Size(217, 34);
            this.btnCmd00.TabIndex = 2;
            this.btnCmd00.Text = "[00]ステータス変更通知";
            this.btnCmd00.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl3.Controls.Add(this.tabPage3);
            this.tabControl3.Location = new System.Drawing.Point(20, 446);
            this.tabControl3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1073, 386);
            this.tabControl3.TabIndex = 22;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lbnRxData);
            this.tabPage3.Controls.Add(this.txtRawData);
            this.tabPage3.Controls.Add(this.lbnAnalyzeRxData);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tabPage3.Size = new System.Drawing.Size(1065, 354);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "受信情報";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(485, 306);
            this.label20.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 18);
            this.label20.TabIndex = 14;
            this.label20.Text = "ETX: ";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(485, 274);
            this.label19.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(107, 18);
            this.label19.TabIndex = 14;
            this.label19.Text = "データ部サム: ";
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(480, 240);
            this.label18.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 18);
            this.label18.TabIndex = 14;
            this.label18.Text = " データ部: ";
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(480, 204);
            this.label17.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(129, 18);
            this.label17.TabIndex = 14;
            this.label17.Text = " シーケンス番号: ";
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(480, 171);
            this.label16.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 18);
            this.label16.TabIndex = 14;
            this.label16.Text = " コマンド: ";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(485, 130);
            this.label15.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(127, 18);
            this.label15.TabIndex = 14;
            this.label15.Text = "データサイズサム:";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(485, 90);
            this.label14.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 18);
            this.label14.TabIndex = 14;
            this.label14.Text = "データサイズ:";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(485, 56);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 18);
            this.label11.TabIndex = 14;
            this.label11.Text = "STX:";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.pnlLog, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbStatus, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 836);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1067, 118);
            this.tableLayoutPanel1.TabIndex = 23;
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // tmrPolling
            // 
            this.tmrPolling.Enabled = true;
            this.tmrPolling.Interval = 1000;
            this.tmrPolling.Tick += new System.EventHandler(this.tmrPolling_Tick);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 972);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.tabControl3);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.tcConnect);
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "FormMain";
            this.Text = "VPTSimulation";
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudRxPortNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTxPortNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalStrength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopSeqNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.routeId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diaNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startHour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startTimeMinutues)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startTimeSecond)).EndInit();
            this.tcConnect.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Panel pnlLog;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.ComboBox cboRxIpAddress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nudRxPortNo;
        private System.Windows.Forms.CheckBox chkAutoRes;
        private System.Windows.Forms.NumericUpDown nudTxPortNo;
        private System.Windows.Forms.NumericUpDown signalStrength;
        private System.Windows.Forms.NumericUpDown stopSeqNumber;
        private System.Windows.Forms.NumericUpDown routeId;
        private System.Windows.Forms.NumericUpDown diaNo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown startHour;
        private System.Windows.Forms.NumericUpDown startTimeMinutues;
        private System.Windows.Forms.NumericUpDown startTimeSecond;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboTxIpAddress;
        private System.Windows.Forms.Label lbnRxData;
        private System.Windows.Forms.TextBox txtRawData;
        private System.Windows.Forms.TextBox lbnAnalyzeRxData;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tcConnect;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnCmd02;
        private System.Windows.Forms.Button btnCmd00;
        private System.Diagnostics.EventLog eventLog1;
        private System.Windows.Forms.Timer tmrPolling;
    }
}

