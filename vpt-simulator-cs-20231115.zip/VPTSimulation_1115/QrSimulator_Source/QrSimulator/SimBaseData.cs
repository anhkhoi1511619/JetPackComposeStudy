﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Windows.Forms;

namespace Lecip.Data
{
    /// <summary>
    /// シミュレータが機器と送受信するデータを扱うベースクラス
    /// </summary>
    public class SimBaseData
    {
        #region Property
        public static readonly string ResoucePath = "SimulatorApplication.Resources";

        /// <summary>LOGフォルダパス</summary>
        public static string LogFolder;

        /// <summary>コマンド情報</summary>
        public CommandList CmdList   { get; private set; }

        /// <summary>
        /// SimDataクラスのシングルトンインスタンスを取得
        /// 無ければ生成する
        /// </summary>
        public static SimBaseData Instance
        {
            get
            {
                if (_simDataInstance == null)
                {
                    lock (lockForSingleton)
                    {
                        if (_simDataInstance == null)
                        {
                            _simDataInstance = new SimBaseData();
                        }
                    }
                }
                return _simDataInstance;
            }
        }
        #endregion

        #region Field
        /// <summary>シングルトンインスタンス</summary>
        protected static SimBaseData _simDataInstance = null;
        /// <summary>シングルトン管理用ロックオブジェクト</summary>
        protected static object lockForSingleton = new object();
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        protected SimBaseData()
        {
            this.CmdList = new CommandList();
        }
        #endregion

        #region 初期化処理
        /// <summary>
        /// DataItemListBaseの初期化
        /// リソースファイルを読み込んで初期化する
        /// </summary>
        /// <param name="asm"></param>
        /// <param name="paramName"></param>
        /// <returns></returns>
        protected DataItemListBase InitItemList(System.Reflection.Assembly asm, string paramName)
        {
            using (var s = asm.GetManifestResourceStream($"{ResoucePath}.{paramName}"))
            {
                return new DataItemListBase(s, paramName);
            }
        }

        /// <summary>
        /// DataItemGridの初期化
        /// </summary>
        /// <param name="itemList">DataItemListBaseデータ</param>
        /// <param name="width">幅</param>
        /// <param name="useCombo">false:コマンドパラメータなど任意の値を入れたいとき true:レスポンス表示など</param>
        /// <returns></returns>
        protected DataItemGrid initGrid(DataItemListBase itemList, int width, bool useCombo = true)
        {
            DataItemGrid grid;
            grid = new DataItemGrid();
            grid.Init(itemList, useCombo);
            grid.Width = width;
            grid.Height = 3 + itemList.Count * 17;

            return grid;
        }

        /// <summary>
        /// リソースファイルを読み込んで、ローカルファイルに出力する
        /// </summary>
        /// <param name="paramName"></param>
        /// <param name="dstFilePath"></param>
        /// <param encoding=リソースファイルのエンコーディング(空文字列の場合、バイナリファイルとして出力する)></param>
        public void CopyResourceToLocal(string paramName, string dstFilePath, string encoding = "Shift_JIS", bool checkExist = true)
        {
            if (checkExist && File.Exists(dstFilePath)) return;

            var asm = System.Reflection.Assembly.GetExecutingAssembly();

            using (var s = asm.GetManifestResourceStream($"{ResoucePath}.{paramName}"))
            {
                if (s == null) return;

                if (!string.IsNullOrEmpty(encoding))
                {
                    using (var sr = new StreamReader(s, Encoding.GetEncoding(encoding)))
                    {
                        string buff = sr.ReadToEnd();

                        File.WriteAllText(dstFilePath, buff, Encoding.GetEncoding(encoding));
                    }
                }
                else
                {
                    using (var br = new BinaryReader(s))
                    {
                        File.WriteAllBytes(dstFilePath, br.ReadBytes((int)s.Length));
                    }
                }
            }
        }
        #endregion
    }
}
