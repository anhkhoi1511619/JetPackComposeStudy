﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace SimulatorApplication
{
    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //二重起動防止策(フォルダ名+ファイル名をセマフォ名として生成)
            // Semaphoreクラスのインスタンスを生成し、アプリケーション終了まで保持する
            string SemaphoreName = $@"{Application.ExecutablePath.Replace('\\', '/')}";
            if (SemaphoreName.Length >= 260) SemaphoreName = SemaphoreName.Substring(SemaphoreName.Length - 259, 259);

            bool createdNew;
            using (var semaphore = new System.Threading.Semaphore(1, 1, SemaphoreName, out createdNew))
            {
                if (!createdNew)
                {
                    MessageBox.Show("既に起動しています");
                    return; // プログラム終了
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new FormMain());
            }
        }
    }
}
