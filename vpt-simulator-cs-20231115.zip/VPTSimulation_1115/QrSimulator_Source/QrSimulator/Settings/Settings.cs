﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lecip
{
    #region XmlSettings
    public class XmlSettings
    {
        #region FilePath
        private string filePath;
        #endregion

        #region Settings
        public System.Drawing.Rectangle Bounds                  { get; set; }
        public System.Windows.Forms.FormWindowState WindowState { get; set; }

        public string Title                  { get; set; }
        public int    ReceiveTimeout         { get; set; }
        public string NetworkInterfaceName   { get; set; }
        public string TcpSendIpAddr          { get; set; }
        public int    TcpSendPortNo          { get; set; }
        public int    TcpRecvPortNo          { get; set; }
        public int    SendWaitTime           { get; set; }
        public List<string> CommandParameter { get; set; }
        #endregion

        #region Constructor
        public XmlSettings()
        {
            this.filePath = "Settings.xml";
            this.Bounds = new System.Drawing.Rectangle();
            this.WindowState = System.Windows.Forms.FormWindowState.Normal;
            this.Title = string.Empty;
            this.ReceiveTimeout = 10000;
            this.NetworkInterfaceName = "イーサネット";
            this.TcpSendIpAddr = "192.168.254.30";
            this.TcpSendPortNo = 52001;
            this.TcpRecvPortNo = 51001;
            this.SendWaitTime  = 0;
            this.CommandParameter = new List<string>();
        }
        #endregion

        #region Load & Save
        public static XmlSettings Load(string filePath)
        {
            XmlSettings settings;
            if (System.IO.File.Exists(filePath))
                settings = XmlUtility.Deserialize<XmlSettings>(filePath);
            else
                settings = new XmlSettings();

            settings.filePath = filePath;
            return settings;
        }

        public void Save()
        {
            XmlUtility.Serialize<XmlSettings>(this, this.filePath);
        }

        public void Save(string filePath)
        {
            XmlUtility.Serialize<XmlSettings>(this, filePath);
        }
        #endregion
    }
    #endregion
}