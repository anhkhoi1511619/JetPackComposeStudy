﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Data
{
    /// <summary>
    /// 各コマンド固有のコマンド名称及びレスポンスデータ キー=コマンド番号
    /// カンマ区切りのテキストファイルを埋め込みリソースに登録しておく必要がある
    /// 例)
    /// 01,ポーリング,Cmd01.csv
    /// 11,動作モード設定
    /// コマンド番号("01")でインデクサを呼び出すとコマンド名("ポーリング")を返す
    /// コマンド番号("01")とレスポンスデータでインデクサを呼び出すと分解した結果を返す
    /// </summary>
    public class CommandList
    {
        #region Indexer
        /// <summary>
        /// コマンド番号をキーにコマンド名称を取得
        /// </summary>
        /// <param name="rxCmd">コマンド番号</param>
        /// <returns>コマンド名称</returns>
        public string this[string rxCmd]
        {
            get
            {
                string name = string.Empty;
                this.cmdName.TryGetValue(rxCmd, out name);

                return name;
            }
        }

        /// <summary>
        /// コマンド番号と受信データをキーに分解データを取得
        /// </summary>
        /// <param name="rxCmd">コマンド番号</param>
        /// <param name="rxText">受信データ</param>
        /// <returns></returns>
        public string this[string rxCmd, string rxText]
        {
            get
            {
                string log = string.Empty;
                DataItemListBase res;

                if (this.cmdData.TryGetValue(rxCmd, out res))
                {
                    res.SetString(rxText);
                    foreach (var item in res)
                    {
                        string text = item.Text;
                        if (text.LastIndexOf('\0') > 0) text = text.Substring(0, text.LastIndexOf('\0'));

                        log += "\r\n";
                        log += item.Name + " = " + text;
                    }
                }

                return log;
            }
        }
        #endregion

        #region Field
        /// <summary>コマンド番号とコマンド名の連想配列</summary>
        private Dictionary<string, string> cmdName;
        /// <summary>コマンド番号とDataItemListBaseの連想配列</summary>
        private Dictionary<string, DataItemListBase> cmdData = new Dictionary<string, DataItemListBase>();
        #endregion

        #region Constructor
        public CommandList()
        {
            string rscPath = SimBaseData.ResoucePath;
            string rscName = "CmdList.txt";

            init(rscPath, rscName);
        }

        private CommandList(string rscPath, string rscName)
        {
            init(rscPath, rscName);
        }
        #endregion

        #region initialize
        /// <summary>
        /// 埋め込みリソース(カンマ区切りのテキストファイル)
        /// を読み込み、初期化する
        /// </summary>
        /// <param name="rscPath">リソースパス</param>
        /// <param name="rscName">リソース名</param>
        private void init(string rscPath, string rscName)
        {
            this.cmdName = new Dictionary<string, string>();
            this.cmdData = new Dictionary<string, DataItemListBase>();

            var asm = System.Reflection.Assembly.GetExecutingAssembly();

            using (var s = asm.GetManifestResourceStream($"{rscPath}.{rscName}"))
            {
                if (s == null) return;

                using (var sr = new System.IO.StreamReader(s, System.Text.Encoding.GetEncoding("Shift_JIS")))
                {
                    Lecip.CSVParser csv = new CSVParser();
                    var csvData = csv.Parse(sr);

                    foreach (List<string> row in csvData)
                    {
                        if (row.Count >= 2)
                        {
                            this.cmdName.Add(row[0], row[1]);
                            if (row.Count >= 3)
                            {
                                using (var ss = asm.GetManifestResourceStream($"{rscPath}.{row[2]}"))
                                {
                                    this.cmdData.Add(row[0], new DataItemListBase(ss, row[2]));
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion
    }
}
