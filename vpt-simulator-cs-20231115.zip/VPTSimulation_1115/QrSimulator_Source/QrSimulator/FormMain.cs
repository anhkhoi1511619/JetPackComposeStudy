﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using Lecip;
using Lecip.Utility;
using Lecip.Data;
using Lecip.Net;

namespace SimulatorApplication
{
    public partial class FormMain : Form
    {
        #region Field
        private readonly string Title = "QR乗車・QR降車シミュレータ";
        /// <summary>通信部(主局)</summary>
        private SimulatorMain   simMain;
        /// <summary>通信部(従局)</summary>
        private SimulatorSub    simSub;
        /// <summary>通信データ部</summary>
        private SimData         simData;
        #endregion

        #region Constructor
        public FormMain()
        {
            InitializeComponent();

            //イベントハンドラの登録
            this.Load        += (sender, e) => { loadForm(); };
            this.FormClosing += (sender, e) => { closeForm(); };

            //メニュー
            this.tsmItemOpenQrFolder.Click  += (sender, e) => { Utility.OpenExplorer(SimData.QrFolder); };
            this.tsmItemOpenLogFolder.Click += (sender, e) => { Utility.OpenExplorer(SimData.LogFolder); };
            this.tsmItemExit.Click          += (sender, e) => { this.Close(); };
            this.tsmItemOption.Click        += (sender, e) => { showFormOption(); };
            this.tsmItemTopMost.Click       += (sender, e) => { this.TopMost = ((ToolStripMenuItem)sender).Checked; };
            this.tsmItemScreenShot.Click    += (sender, e) => { menuScreenShot(); };
            this.tsmItemManual.Click        += (sender, e) => { Utility.OpenFile($@"{Application.StartupPath}\説明書.pdf"); };
            this.tsmItemVersion.Click       += (sender, e) => { Utility.DisplayVersion(); };

            //開始ボタン、QRデータ通知ボタン
            this.btnOpen.Click  += (sender, e) => { menuOpenClosePort(sender, e); };
            this.btnA0.Click    += (sender, e) => { doCommand(0xA0); };
            this.btnB0.Click    += (sender, e) => { doCommand(0xB0); };
            this.chkCmd00Log.CheckedChanged += (sender, e) => { this.simData.EnableCmd00Log = this.chkCmd00Log.Checked; };

            //ステータスバー
            this.tssButtonLog.DoubleClick          += (sender, e) => { this.menuLogOnOff(sender, e); };
            this.tsmItemLogClear.Click             += (sender, e) => { this.menuLogClear(sender, e); };
            this.tscDebugMode.SelectedIndexChanged += (sender, e) => { this.menuDebugModeChanged(sender, e); };

            this.tabcButton.SelectedIndexChanged += (sender, e) => { this.tabcCmd.SelectedIndex = this.tabcButton.SelectedIndex; };

            //Simulatorクラスの初期化(主局,従局)
            this.simMain = new SimulatorMain() { Dock = DockStyle.Fill };
            this.simMain.DataReceived  += (sender, e) => { doReceive(); };
            this.simMain.ErrorReceived += (sender, e) => { doError(); };
            this.tlpLog.Controls.Add(this.simMain);

            this.simSub = new SimulatorSub() { Dock = DockStyle.Fill };
            this.simSub.DataReceived += (sender, e) => { doReceiveSub(); };
            this.tlpLog.Controls.Add(this.simSub);

            //結果表示テキストボックスのショートカットメニュー
            ContextMenu menu = new ContextMenu();
            menu.MenuItems.Add(new MenuItem("選択範囲をコピー(&C)", onTxtResultCopyClick));
            menu.MenuItems.Add(new MenuItem("クリア(&X)", onTxtResultClearClick));
            this.txtResult.ContextMenu = menu;

            //設定の読み込み
            loadSettings();
        }
        #endregion

        #region Event Handler
        /// <summary>画面ロード処理</summary>
        private void loadForm()
        {
            //画面の位置を設定
            if (this.simData.Settings.Bounds.Width > 0)
            {
                foreach (Screen scr in Screen.AllScreens)
                {
                    if (scr.WorkingArea.Contains(this.simData.Settings.Bounds.Location))
                    {
                        this.Bounds = this.simData.Settings.Bounds;
                        break;
                    }
                }
            } 
            this.WindowState = this.simData.Settings.WindowState;
            this.simData.GridClearSelection();
        }
        /// <summary>終了処理</summary>
        private void closeForm()
        {
            saveSettings();                      //設定保存
            this.simMain.Tcp.Close();            //通信終了
            this.simSub.Tcp.Close();             //通信終了
        }
        /// <summary>スクリーンショットを撮る</summary>
        private void menuScreenShot()
        {
            Rectangle rc = this.Bounds;
            string filename = $@"{SimData.LogFolder}\{DateTime.Now.ToString("yyMMdd_HHmmss")}.PNG";
            Utility.SaveFromScreen(rc, filename);
        }
        /// <summary>通信ログONOFF切替</summary>
        private void menuLogOnOff(object sender, EventArgs e)
        {
            this.simMain.Tcp.EnableWriteLog = !this.simMain.Tcp.EnableWriteLog;
            this.simSub.Tcp.EnableWriteLog  = !this.simSub.Tcp.EnableWriteLog;
            ((ToolStripItem)sender).Text = $"通信ログ:{(this.simMain.Tcp.EnableWriteLog ? "ON" : "OFF")}";
        }
        /// <summary>通信ログの消去</summary>
        private void menuLogClear(object sender, EventArgs e)
        {
            if (!File.Exists(this.simMain.Tcp.FileLogPath) && this.simMain.Tcp.EnableWriteLog) return;
            try
            {
                File.Delete(this.simMain.Tcp.FileLogPath);
            }
            catch (Exception ex)
            {
                Util.MessageErr(ex.Message, string.Empty);
            }
        }
        /// <summary>デバッグモードの切り替え</summary>
        private void menuDebugModeChanged(object sender, EventArgs e)
        {
            this.tssButtonDebug.Text = ((ToolStripComboBox)sender).Text;
            this.simMain.Tcp.DebugMode   = ((ToolStripComboBox)sender).SelectedIndex;
        }
        /// <summary>結果表示クリア</summary>
        private void onTxtResultClearClick(object sender, EventArgs e)
        {
            this.txtResult.Clear();
        }
        /// <summary>結果表示クリップボードコピー</summary>
        private void onTxtResultCopyClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txtResult.Text)) return;
            if (string.IsNullOrEmpty(this.txtResult.SelectedText)) return;
            Clipboard.SetText(this.txtResult.SelectedText, TextDataFormat.Text);
        }
        /// <summary>開始・停止ボタンの切り替え</summary>
        private void menuOpenClosePort(object sender, EventArgs e)
        {
            Button btn = null;

            if (sender is Button) btn = (Button)sender;

            bool isOpen = openclosePort();
            foreach (TabPage tp in this.tabcButton.TabPages)
            {
                if (tp.Controls[0] is FlowLayoutPanel)
                {
                    FlowLayoutPanel fp = (FlowLayoutPanel)tp.Controls[0];
                    foreach (Control c in fp.Controls)
                    {
                        c.Enabled = isOpen; //各ボタンの有効・無効を切り替える
                    }
                }
            }
            if (btn != null)
            {
                btn.Text = (isOpen) ? "停止" : "開始";
                btn.Enabled = true; //開始・停止ボタンは常に有効
            }
        }
        #endregion

        #region 初期化処理
        /// <summary>設定を読み込む</summary>
        private void loadSettings()
        {
            //シミュレータデータの初期化
            SimData.SettingFilePath = $"{Application.StartupPath}\\Settings.xml";
            this.simData = SimData.Instance;

            //qrフォルダとlogフォルダを生成し、空であればtxtファイルを1個生成する
            SimData.QrFolder = $@"{Application.StartupPath}\qr";
            SimData.LogFolder = $@"{Application.StartupPath}\log";
            Directory.CreateDirectory(SimData.QrFolder);
            Directory.CreateDirectory(SimData.LogFolder);
            var files = Directory.GetFiles(SimData.QrFolder, "*.txt");
            if (files.Length == 0) this.simData.CopyResourceToLocal("QR01.txt", $@"{SimData.QrFolder}\QR01.txt");
            this.simData.CopyResourceToLocal("説明書.pdf", $@"{Application.StartupPath}\説明書.pdf", "");

            //設定値読み込みと反映
            this.simData.LoadSettings(this);

            //画面の初期化
            initDisplay();

            //通信設定
            setPortParameter();

            //タイトルバー表示
            setTitle(this.simData.Settings.Title);
        }

        /// <summary>設定を保存する</summary>
        private void saveSettings()
        {
            this.simData.Save(this);
        }

        /// <summary>タイトル画面の表示</summary>
        private void setTitle(string filename)
        {
            this.Text = $"{this.Title} [{filename}]";
        }
        #endregion

        #region 別画面表示処理
        /// <summary>オプション画面表示</summary>
        private void showFormOption()
        {
            bool isOpen = this.simMain.Tcp.IsOpen;

            if (isOpen) this.openclosePort(); //接続中はいったん閉じる

            using (var dlg = new FormOption())
            {
                dlg.Settings = this.simData.Settings;
                dlg.ShowDialog();
                if (dlg.DialogResult == DialogResult.OK)
                {
                    this.simData.Save(this);
                    setPortParameter();
                }
            }

            if (isOpen) this.openclosePort(); //再接続する
        }
        #endregion

        #region 通信処理
        /// <summary>
        /// 通信ポートのOpen/Close
        /// </summary>
        /// <returns>true:ポートオープン中 false:ポートクローズ中</returns>
        private bool openclosePort()
        {
            try
            {
                if (this.simMain.Tcp.IsOpen)
                {
                    this.simMain.Tcp.Close();
                    this.simSub.Tcp.Close();
                    this.simData.Cmd00.ClearText();
                    this.simData.Cmd10.ClearText();
                }
                else
                {
                    //bool isAny = false;
                    this.simMain.Tcp.Open();
                    this.simSub.Tcp.Open();
                }
                this.displaySimStatus();
            }
            catch (Exception ex)
            {
                Util.MessageErr(ex.Message, string.Empty);

                this.simMain.Tcp.Close();
                this.simSub.Tcp.Close();
            }
            return this.simMain.Tcp.IsOpen;
        }
        
        /// <summary>
        /// コマンド送信処理
        /// </summary>
        /// <param name="cmd">コマンド</param>
        private void doCommand(byte cmd)
        {
            this.simMain.SendCommand(cmd);
        }

        /// <summary>
        /// 受信処理
        /// </summary>
        private void doReceive()
        {
            if (string.IsNullOrEmpty(this.simMain.ResultLog)) return;

            string msg = $"{DateTime.Now:HH:mm:ss.fff} {this.simMain.ResultLog}";
            if (this.InvokeRequired) this.Invoke(new Action<string>(appendTxtResult), msg);
            else  appendTxtResult(msg);

            if (this.InvokeRequired) this.Invoke(new Action(sendNextQr));
            else sendNextQr();
        }
        private void doReceiveSub()
        {
            if (string.IsNullOrEmpty(this.simSub.ResultLog)) return;

            string msg = $"{DateTime.Now:HH:mm:ss.fff} {this.simSub.ResultLog}";
            if (this.InvokeRequired) this.Invoke(new Action<string>(appendTxtResult), msg);
            else appendTxtResult(msg);
        }

        /// <summary>
        /// 通信エラー処理
        /// </summary>
        private void doError()
        {
            string msg = $"{DateTime.Now:HH:mm:ss.fff} Err\r\n{this.simMain.Tcp.ErrorMessage}";
            if (this.InvokeRequired) this.Invoke(new Action<string>(appendTxtResult), msg);
            else appendTxtResult(msg);
        }

        /// <summary>
        /// 通信ポート設定
        /// </summary>
        private void setPortParameter()
        {
            
            //PCのIPアドレスを取得するためにネットワーク名称リストを取得
            var networkNames    = Utility.GetIpV4NetworkNameList();
            string networkName  = this.simData.Settings.NetworkInterfaceName;
            if (!networkNames.Contains(networkName)) networkName = string.Empty;

            this.simMain.Tcp.SendIpAddr      = this.simData.Settings.TcpSendIpAddr;  //送信先IPアドレス(制御部)
            this.simMain.Tcp.RecvIpAddr      = Utility.GetIpV4Address(networkName);  //受信IPアドレス(シミュレータPCのIPアドレス)
            this.simMain.Tcp.SendPortNo      = this.simData.Settings.TcpSendPortNo;  //QR主局->制御部従局 送信先ポート番号
            this.simMain.Tcp.RecvPortNo      = this.simData.Settings.TcpSendPortNo;  //QR主局<-制御部従局 主局の受信ポート番号=送信先ポート番号 
            this.simMain.Tcp.ReceiveTimeout  = this.simData.Settings.ReceiveTimeout;
            this.simMain.Tcp.FileLogPath     = $@"{SimData.LogFolder}\{this.Title}通信ログ_主局_{DateTime.Now:yyyyMMdd}.txt";

            this.simSub.Tcp.SendIpAddr       = this.simData.Settings.TcpSendIpAddr;  //送信先IPアドレス(制御部)
            this.simSub.Tcp.RecvIpAddr       = Utility.GetIpV4Address(networkName);  //受信IPアドレス(シミュレータPCのIPアドレス)
            this.simSub.Tcp.SendPortNo       = this.simData.Settings.TcpRecvPortNo;  //QR従局->制御部主局 送信先ポート番号=従局の受信ポート番号
            this.simSub.Tcp.RecvPortNo       = this.simData.Settings.TcpRecvPortNo;  //QR従局<-制御部主局 従局の受信ポート番号
            this.simSub.Tcp.ReceiveTimeout   = this.simData.Settings.ReceiveTimeout;
            this.simSub.Tcp.FileLogPath      = $@"{SimData.LogFolder}\{this.Title}通信ログ_従局_{DateTime.Now:yyyyMMdd}.txt";

            //ステータスバー
            this.displaySimStatus();

        }
        #endregion

        #region 表示処理
        /// <summary>
        /// ステータスバーの状態表示
        /// </summary>
        private void displaySimStatus()
        {
            this.tssLabelSimStatus.Text = $"{this.simMain.Tcp.PortStatus}[制御部主局:{this.simData.Settings.TcpRecvPortNo}][QR主局:{this.simData.Settings.TcpSendPortNo}]";
            this.tssLabelMessage.Text   = string.Empty;
        }
 
        /// <summary>
        /// 結果表示テキストボックスに表示
        /// </summary>
        /// <param name="log"></param>
        private void appendTxtResult(string log)
        {
            this.txtResult.AppendText(log + "\r\n");
        }
        #endregion

        
        #region 画面初期化処理
        private void initDisplay()
        {
            //デバッグモード
            this.tscDebugMode.Items.AddRange(this.simMain.Tcp.DebugList);
            this.tscDebugMode.SelectedIndex = 0;

            //DataGridViewの高さ調整
            this.simData.GridRes01.Height = this.simData.Res01.Count * 17 + 3;
            this.simData.GridRes91.Height = this.simData.Res91.Count * 17 + 3;
            this.simData.GridCmd00.Height = this.simData.Cmd00.Count * 17 + 3;
            this.simData.GridCmd10.Height = this.simData.Cmd10.Count * 17 + 3;

            this.simData.GridRes01.Width = 350;
            this.simData.GridRes91.Width = 350;
            this.simData.GridCmd00.Width = 350;
            this.simData.GridCmd10.Width = 350;

            //ステータス設定リスト取得・1件目を設定
            var stList = this.simData.GetStatusParameterList();
            this.simData.LoadStatusParameter(stList[0]);

            //QRデータファイルリスト取得・1件目を設定
            var qrList = this.simData.GetQrFileList();
            this.simData.QrDataFile = qrList[0];

            //ステータス設定コンボボックス生成
            var stsCbo = new ComboBox() { DropDownStyle = ComboBoxStyle.DropDownList, Width = this.simData.GridRes01.Width } ;
            stsCbo.SelectedIndexChanged += (s, e) => { setStatusParameter(s, e); };
            stsCbo.DataSource = stList;

            //QRデータファイル設定コンボボックス生成
            var qrCbo = new ComboBox() { DropDownStyle = ComboBoxStyle.DropDownList, Width = this.simData.GridRes01.Width };
            qrCbo.SelectedIndexChanged += (s, e) => { readQrFile(s, e); };
            qrCbo.DataSource = qrList;

            //パネルに追加
            this.pnlParam1.Controls.AddRange(new Control[]
            {
                new Label() { Text = "ステータスレスポンスパラメータ", AutoSize = true },
                stsCbo,
                this.simData.GridRes01,
                new Label() { Text = "QRデータ通知コマンドパラメータ  ", AutoSize = true },
                qrCbo,
                new Label() { Text = "バージョン要求レスポンスパラメータ", AutoSize = true },
                this.simData.GridRes91,
            });

            this.pnlRes1.Controls.Add(new Label() { Text = "ステータス通知・要求", AutoSize = true });
            this.pnlRes1.Controls.Add(this.simData.GridCmd00);
            this.pnlRes1.Controls.Add(new Label() { Text = "接客表示要求", AutoSize = true });
            this.pnlRes1.Controls.Add(this.simData.GridCmd10);
        }
        #endregion

        #region Qrファイル処理
        /// <summary>
        /// CSVリストコンボボックスイベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void readQrFile(object sender, EventArgs e)
        {
            ComboBox item = sender as ComboBox;

            if (item.Text.StartsWith("最新の情報に更新"))
            {
                item.DataSource = this.simData.GetQrFileList();
            }
            else if (item.Text.StartsWith("QRフォルダを開く"))
            {
                Utility.OpenExplorer(SimData.QrFolder);
                item.DataSource = this.simData.GetQrFileList();
            }
            else
            {
                this.simData.QrDataFile = $@"{item.Text}";
            }
        }
        #endregion

        #region ステータスパラメータ設定処理
        private void setStatusParameter(object sender, EventArgs e)
        {
            ComboBox item = sender as ComboBox;

            if (item.Text.StartsWith("設定値の保存"))
            {
                this.simData.SaveStatusParameter();
                item.Text = this.simData.StsParamName;
            }
            if (item.Text.StartsWith("設定値の新規登録"))
            {
                using (var dlg = new Lecip.Windows.Forms.InputBox())
                {
                    dlg.StartPosition = FormStartPosition.CenterParent;

                    if (dlg.Show("登録名を入力してください", "設定値の新規登録", "新規1") == DialogResult.Cancel) return;
                    string newParamName = dlg.InputText;
                    this.simData.StsParamName = newParamName;
                    this.simData.SaveStatusParameter();

                    item.DataSource = this.simData.GetStatusParameterList();
                    item.Text = newParamName;
                }
            }
            else if (item.Text.StartsWith("リストから削除"))
            {
                if (MessageBox.Show($"{this.simData.StsParamName}をリストから削除します", "リストから削除", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel) return;
                this.simData.RemoveStatusParameter();
                item.DataSource = this.simData.GetStatusParameterList();
            }
            else
            {
                this.simData.LoadStatusParameter($"{item.Text}");
            }
        }
        #endregion

        #region QRデータ連続送信モード
        /// <summary>
        /// QRデータ連続送信モード
        /// </summary>
        private void sendNextQr()
        {
            if (!this.chkQrSend.Checked) return;

            if (this.nudQrSendInterval.Value > 0)
            {
                System.Threading.Thread.Sleep((int)this.nudQrSendInterval.Value);
            }

            if (this.simMain.Tcp.IsOpen) doCommand(0xA0);
        }
        #endregion

    }
}
