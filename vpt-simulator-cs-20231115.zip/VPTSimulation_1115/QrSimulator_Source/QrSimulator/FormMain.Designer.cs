﻿namespace SimulatorApplication
{
    partial class FormMain
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.tsmItemFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemOpenQrFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemOpenLogFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.tssFileMenu = new System.Windows.Forms.ToolStripSeparator();
            this.tsmItemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemTool = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemOption = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemTopMost = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemScreenShot = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemManual = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemVersion = new System.Windows.Forms.ToolStripMenuItem();
            this.stsMain = new System.Windows.Forms.StatusStrip();
            this.tssLabelSimStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssButtonLog = new System.Windows.Forms.ToolStripSplitButton();
            this.tsmItemLogClear = new System.Windows.Forms.ToolStripMenuItem();
            this.tssButtonDebug = new System.Windows.Forms.ToolStripSplitButton();
            this.tscDebugMode = new System.Windows.Forms.ToolStripComboBox();
            this.tssLabelMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.spcHorizontal = new System.Windows.Forms.SplitContainer();
            this.spcVertical = new System.Windows.Forms.SplitContainer();
            this.tabcButton = new System.Windows.Forms.TabControl();
            this.tabpButton1 = new System.Windows.Forms.TabPage();
            this.pnlButton1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnB0 = new System.Windows.Forms.Button();
            this.btnA0 = new System.Windows.Forms.Button();
            this.chkCmd00Log = new System.Windows.Forms.CheckBox();
            this.chkQrSend = new System.Windows.Forms.CheckBox();
            this.lbQrSendInterval = new System.Windows.Forms.Label();
            this.nudQrSendInterval = new System.Windows.Forms.NumericUpDown();
            this.tabcRes = new System.Windows.Forms.TabControl();
            this.tabpRes1 = new System.Windows.Forms.TabPage();
            this.pnlRes1 = new System.Windows.Forms.FlowLayoutPanel();
            this.tabpRes2 = new System.Windows.Forms.TabPage();
            this.txtResult = new System.Windows.Forms.RichTextBox();
            this.tabcCmd = new System.Windows.Forms.TabControl();
            this.tabpCmd1 = new System.Windows.Forms.TabPage();
            this.pnlParam1 = new System.Windows.Forms.FlowLayoutPanel();
            this.tlpLog = new System.Windows.Forms.TableLayoutPanel();
            this.mnuMain.SuspendLayout();
            this.stsMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spcHorizontal)).BeginInit();
            this.spcHorizontal.Panel1.SuspendLayout();
            this.spcHorizontal.Panel2.SuspendLayout();
            this.spcHorizontal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spcVertical)).BeginInit();
            this.spcVertical.Panel1.SuspendLayout();
            this.spcVertical.Panel2.SuspendLayout();
            this.spcVertical.SuspendLayout();
            this.tabcButton.SuspendLayout();
            this.tabpButton1.SuspendLayout();
            this.pnlButton1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQrSendInterval)).BeginInit();
            this.tabcRes.SuspendLayout();
            this.tabpRes1.SuspendLayout();
            this.tabpRes2.SuspendLayout();
            this.tabcCmd.SuspendLayout();
            this.tabpCmd1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmItemFile,
            this.tsmItemTool,
            this.tsmItemHelp});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(943, 24);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // tsmItemFile
            // 
            this.tsmItemFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmItemOpenQrFolder,
            this.tsmItemOpenLogFolder,
            this.tssFileMenu,
            this.tsmItemExit});
            this.tsmItemFile.Name = "tsmItemFile";
            this.tsmItemFile.Size = new System.Drawing.Size(67, 20);
            this.tsmItemFile.Text = "ファイル(&F)";
            // 
            // tsmItemOpenQrFolder
            // 
            this.tsmItemOpenQrFolder.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemOpenQrFolder.Image")));
            this.tsmItemOpenQrFolder.Name = "tsmItemOpenQrFolder";
            this.tsmItemOpenQrFolder.Size = new System.Drawing.Size(179, 22);
            this.tsmItemOpenQrFolder.Text = "QRフォルダを開く";
            // 
            // tsmItemOpenLogFolder
            // 
            this.tsmItemOpenLogFolder.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemOpenLogFolder.Image")));
            this.tsmItemOpenLogFolder.Name = "tsmItemOpenLogFolder";
            this.tsmItemOpenLogFolder.Size = new System.Drawing.Size(179, 22);
            this.tsmItemOpenLogFolder.Text = "通信ログフォルダを開く";
            // 
            // tssFileMenu
            // 
            this.tssFileMenu.Name = "tssFileMenu";
            this.tssFileMenu.Size = new System.Drawing.Size(176, 6);
            // 
            // tsmItemExit
            // 
            this.tsmItemExit.Name = "tsmItemExit";
            this.tsmItemExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.tsmItemExit.Size = new System.Drawing.Size(179, 22);
            this.tsmItemExit.Text = "終了(&X)";
            // 
            // tsmItemTool
            // 
            this.tsmItemTool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmItemOption,
            this.tsmItemTopMost,
            this.tsmItemScreenShot});
            this.tsmItemTool.Name = "tsmItemTool";
            this.tsmItemTool.Size = new System.Drawing.Size(60, 20);
            this.tsmItemTool.Text = "ツール(&T)";
            // 
            // tsmItemOption
            // 
            this.tsmItemOption.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemOption.Image")));
            this.tsmItemOption.Name = "tsmItemOption";
            this.tsmItemOption.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.tsmItemOption.Size = new System.Drawing.Size(191, 22);
            this.tsmItemOption.Text = "オプション(&O)";
            // 
            // tsmItemTopMost
            // 
            this.tsmItemTopMost.CheckOnClick = true;
            this.tsmItemTopMost.Name = "tsmItemTopMost";
            this.tsmItemTopMost.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.tsmItemTopMost.Size = new System.Drawing.Size(191, 22);
            this.tsmItemTopMost.Text = "常に手前に表示";
            // 
            // tsmItemScreenShot
            // 
            this.tsmItemScreenShot.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemScreenShot.Image")));
            this.tsmItemScreenShot.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmItemScreenShot.Name = "tsmItemScreenShot";
            this.tsmItemScreenShot.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.tsmItemScreenShot.Size = new System.Drawing.Size(191, 22);
            this.tsmItemScreenShot.Text = "スクリーンショット";
            // 
            // tsmItemHelp
            // 
            this.tsmItemHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmItemManual,
            this.tsmItemVersion});
            this.tsmItemHelp.Name = "tsmItemHelp";
            this.tsmItemHelp.Size = new System.Drawing.Size(65, 20);
            this.tsmItemHelp.Text = "ヘルプ(&H)";
            // 
            // tsmItemManual
            // 
            this.tsmItemManual.Name = "tsmItemManual";
            this.tsmItemManual.Size = new System.Drawing.Size(172, 22);
            this.tsmItemManual.Text = "マニュアルの表示(&M)";
            // 
            // tsmItemVersion
            // 
            this.tsmItemVersion.Name = "tsmItemVersion";
            this.tsmItemVersion.Size = new System.Drawing.Size(172, 22);
            this.tsmItemVersion.Text = "バージョン情報(&V)";
            // 
            // stsMain
            // 
            this.stsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tssLabelSimStatus,
            this.tssButtonLog,
            this.tssButtonDebug,
            this.tssLabelMessage});
            this.stsMain.Location = new System.Drawing.Point(0, 691);
            this.stsMain.Name = "stsMain";
            this.stsMain.Size = new System.Drawing.Size(943, 22);
            this.stsMain.TabIndex = 1;
            this.stsMain.Text = "stsMain";
            // 
            // tssLabelSimStatus
            // 
            this.tssLabelSimStatus.Name = "tssLabelSimStatus";
            this.tssLabelSimStatus.Size = new System.Drawing.Size(151, 17);
            this.tssLabelSimStatus.Text = "COMXXX:Close (9600,N,8,1)";
            // 
            // tssButtonLog
            // 
            this.tssButtonLog.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tssButtonLog.DoubleClickEnabled = true;
            this.tssButtonLog.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmItemLogClear});
            this.tssButtonLog.Image = ((System.Drawing.Image)(resources.GetObject("tssButtonLog.Image")));
            this.tssButtonLog.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tssButtonLog.Name = "tssButtonLog";
            this.tssButtonLog.Size = new System.Drawing.Size(89, 20);
            this.tssButtonLog.Text = "通信ログ:OFF";
            // 
            // tsmItemLogClear
            // 
            this.tsmItemLogClear.Name = "tsmItemLogClear";
            this.tsmItemLogClear.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.tsmItemLogClear.Size = new System.Drawing.Size(181, 22);
            this.tsmItemLogClear.Text = "通信ログクリア";
            // 
            // tssButtonDebug
            // 
            this.tssButtonDebug.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tssButtonDebug.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tscDebugMode});
            this.tssButtonDebug.Image = ((System.Drawing.Image)(resources.GetObject("tssButtonDebug.Image")));
            this.tssButtonDebug.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tssButtonDebug.Name = "tssButtonDebug";
            this.tssButtonDebug.Size = new System.Drawing.Size(47, 20);
            this.tssButtonDebug.Text = "通常";
            // 
            // tscDebugMode
            // 
            this.tscDebugMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tscDebugMode.Name = "tscDebugMode";
            this.tscDebugMode.Size = new System.Drawing.Size(121, 23);
            // 
            // tssLabelMessage
            // 
            this.tssLabelMessage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tssLabelMessage.Name = "tssLabelMessage";
            this.tssLabelMessage.Size = new System.Drawing.Size(641, 17);
            this.tssLabelMessage.Spring = true;
            this.tssLabelMessage.Text = "     ";
            this.tssLabelMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // spcHorizontal
            // 
            this.spcHorizontal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.spcHorizontal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spcHorizontal.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.spcHorizontal.IsSplitterFixed = true;
            this.spcHorizontal.Location = new System.Drawing.Point(0, 24);
            this.spcHorizontal.Name = "spcHorizontal";
            this.spcHorizontal.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spcHorizontal.Panel1
            // 
            this.spcHorizontal.Panel1.AutoScroll = true;
            this.spcHorizontal.Panel1.Controls.Add(this.spcVertical);
            // 
            // spcHorizontal.Panel2
            // 
            this.spcHorizontal.Panel2.Controls.Add(this.tlpLog);
            this.spcHorizontal.Size = new System.Drawing.Size(943, 667);
            this.spcHorizontal.SplitterDistance = 584;
            this.spcHorizontal.SplitterWidth = 1;
            this.spcHorizontal.TabIndex = 3;
            // 
            // spcVertical
            // 
            this.spcVertical.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.spcVertical.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spcVertical.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.spcVertical.Location = new System.Drawing.Point(0, 0);
            this.spcVertical.Name = "spcVertical";
            // 
            // spcVertical.Panel1
            // 
            this.spcVertical.Panel1.Controls.Add(this.tabcButton);
            this.spcVertical.Panel1.Padding = new System.Windows.Forms.Padding(1);
            // 
            // spcVertical.Panel2
            // 
            this.spcVertical.Panel2.AutoScroll = true;
            this.spcVertical.Panel2.Controls.Add(this.tabcRes);
            this.spcVertical.Panel2.Controls.Add(this.tabcCmd);
            this.spcVertical.Size = new System.Drawing.Size(943, 584);
            this.spcVertical.SplitterDistance = 140;
            this.spcVertical.TabIndex = 2;
            // 
            // tabcButton
            // 
            this.tabcButton.Controls.Add(this.tabpButton1);
            this.tabcButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabcButton.Location = new System.Drawing.Point(1, 1);
            this.tabcButton.Margin = new System.Windows.Forms.Padding(0);
            this.tabcButton.Name = "tabcButton";
            this.tabcButton.SelectedIndex = 0;
            this.tabcButton.Size = new System.Drawing.Size(134, 578);
            this.tabcButton.TabIndex = 1;
            // 
            // tabpButton1
            // 
            this.tabpButton1.Controls.Add(this.pnlButton1);
            this.tabpButton1.Location = new System.Drawing.Point(4, 22);
            this.tabpButton1.Margin = new System.Windows.Forms.Padding(0);
            this.tabpButton1.Name = "tabpButton1";
            this.tabpButton1.Size = new System.Drawing.Size(126, 552);
            this.tabpButton1.TabIndex = 0;
            this.tabpButton1.Text = "コマンド";
            this.tabpButton1.UseVisualStyleBackColor = true;
            // 
            // pnlButton1
            // 
            this.pnlButton1.AutoScroll = true;
            this.pnlButton1.BackColor = System.Drawing.SystemColors.Control;
            this.pnlButton1.Controls.Add(this.btnOpen);
            this.pnlButton1.Controls.Add(this.btnB0);
            this.pnlButton1.Controls.Add(this.btnA0);
            this.pnlButton1.Controls.Add(this.chkCmd00Log);
            this.pnlButton1.Controls.Add(this.chkQrSend);
            this.pnlButton1.Controls.Add(this.lbQrSendInterval);
            this.pnlButton1.Controls.Add(this.nudQrSendInterval);
            this.pnlButton1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlButton1.Location = new System.Drawing.Point(0, 0);
            this.pnlButton1.Margin = new System.Windows.Forms.Padding(0);
            this.pnlButton1.Name = "pnlButton1";
            this.pnlButton1.Size = new System.Drawing.Size(126, 552);
            this.pnlButton1.TabIndex = 0;
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(1, 1);
            this.btnOpen.Margin = new System.Windows.Forms.Padding(1);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(110, 30);
            this.btnOpen.TabIndex = 1;
            this.btnOpen.Text = "開始";
            this.btnOpen.UseVisualStyleBackColor = true;
            // 
            // btnB0
            // 
            this.btnB0.Enabled = false;
            this.btnB0.Location = new System.Drawing.Point(1, 33);
            this.btnB0.Margin = new System.Windows.Forms.Padding(1);
            this.btnB0.Name = "btnB0";
            this.btnB0.Size = new System.Drawing.Size(110, 30);
            this.btnB0.TabIndex = 2;
            this.btnB0.Text = "ICデータ通知";
            this.btnB0.UseVisualStyleBackColor = true;
            // 
            // btnA0
            // 
            this.btnA0.Enabled = false;
            this.btnA0.Location = new System.Drawing.Point(1, 65);
            this.btnA0.Margin = new System.Windows.Forms.Padding(1);
            this.btnA0.Name = "btnA0";
            this.btnA0.Size = new System.Drawing.Size(110, 30);
            this.btnA0.TabIndex = 2;
            this.btnA0.Text = "QRデータ通知";
            this.btnA0.UseVisualStyleBackColor = true;
            // 
            // chkCmd00Log
            // 
            this.chkCmd00Log.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chkCmd00Log.Location = new System.Drawing.Point(1, 97);
            this.chkCmd00Log.Margin = new System.Windows.Forms.Padding(1);
            this.chkCmd00Log.Name = "chkCmd00Log";
            this.chkCmd00Log.Size = new System.Drawing.Size(110, 30);
            this.chkCmd00Log.TabIndex = 3;
            this.chkCmd00Log.Text = "ステータスログ有効";
            this.chkCmd00Log.UseVisualStyleBackColor = true;
            // 
            // chkQrSend
            // 
            this.chkQrSend.Location = new System.Drawing.Point(1, 129);
            this.chkQrSend.Margin = new System.Windows.Forms.Padding(1);
            this.chkQrSend.Name = "chkQrSend";
            this.chkQrSend.Size = new System.Drawing.Size(110, 30);
            this.chkQrSend.TabIndex = 4;
            this.chkQrSend.Text = "QR連続送信";
            this.chkQrSend.UseVisualStyleBackColor = true;
            // 
            // lbQrSendInterval
            // 
            this.lbQrSendInterval.Location = new System.Drawing.Point(1, 161);
            this.lbQrSendInterval.Margin = new System.Windows.Forms.Padding(1);
            this.lbQrSendInterval.Name = "lbQrSendInterval";
            this.lbQrSendInterval.Size = new System.Drawing.Size(110, 40);
            this.lbQrSendInterval.TabIndex = 6;
            this.lbQrSendInterval.Text = "QR連続送信間隔\r\nRes受信～次回送信\r\n間隔(msec)";
            // 
            // nudQrSendInterval
            // 
            this.nudQrSendInterval.Location = new System.Drawing.Point(3, 205);
            this.nudQrSendInterval.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudQrSendInterval.Name = "nudQrSendInterval";
            this.nudQrSendInterval.Size = new System.Drawing.Size(120, 19);
            this.nudQrSendInterval.TabIndex = 5;
            this.nudQrSendInterval.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // tabcRes
            // 
            this.tabcRes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tabcRes.Controls.Add(this.tabpRes1);
            this.tabcRes.Controls.Add(this.tabpRes2);
            this.tabcRes.Location = new System.Drawing.Point(382, 1);
            this.tabcRes.Margin = new System.Windows.Forms.Padding(1);
            this.tabcRes.Name = "tabcRes";
            this.tabcRes.SelectedIndex = 0;
            this.tabcRes.Size = new System.Drawing.Size(400, 603);
            this.tabcRes.TabIndex = 39;
            // 
            // tabpRes1
            // 
            this.tabpRes1.BackColor = System.Drawing.SystemColors.Control;
            this.tabpRes1.Controls.Add(this.pnlRes1);
            this.tabpRes1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabpRes1.Location = new System.Drawing.Point(4, 22);
            this.tabpRes1.Margin = new System.Windows.Forms.Padding(1);
            this.tabpRes1.Name = "tabpRes1";
            this.tabpRes1.Size = new System.Drawing.Size(392, 577);
            this.tabpRes1.TabIndex = 0;
            this.tabpRes1.Text = "受信情報1";
            // 
            // pnlRes1
            // 
            this.pnlRes1.AutoScroll = true;
            this.pnlRes1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRes1.Location = new System.Drawing.Point(0, 0);
            this.pnlRes1.Name = "pnlRes1";
            this.pnlRes1.Size = new System.Drawing.Size(392, 577);
            this.pnlRes1.TabIndex = 0;
            // 
            // tabpRes2
            // 
            this.tabpRes2.BackColor = System.Drawing.SystemColors.Control;
            this.tabpRes2.Controls.Add(this.txtResult);
            this.tabpRes2.Location = new System.Drawing.Point(4, 22);
            this.tabpRes2.Margin = new System.Windows.Forms.Padding(1);
            this.tabpRes2.Name = "tabpRes2";
            this.tabpRes2.Size = new System.Drawing.Size(492, 560);
            this.tabpRes2.TabIndex = 1;
            this.tabpRes2.Text = "受信情報2";
            // 
            // txtResult
            // 
            this.txtResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResult.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtResult.HideSelection = false;
            this.txtResult.Location = new System.Drawing.Point(0, 0);
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
            this.txtResult.Size = new System.Drawing.Size(492, 560);
            this.txtResult.TabIndex = 2;
            this.txtResult.Text = "";
            // 
            // tabcCmd
            // 
            this.tabcCmd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tabcCmd.Controls.Add(this.tabpCmd1);
            this.tabcCmd.ItemSize = new System.Drawing.Size(30, 18);
            this.tabcCmd.Location = new System.Drawing.Point(1, 1);
            this.tabcCmd.Margin = new System.Windows.Forms.Padding(0);
            this.tabcCmd.Name = "tabcCmd";
            this.tabcCmd.SelectedIndex = 0;
            this.tabcCmd.Size = new System.Drawing.Size(380, 601);
            this.tabcCmd.TabIndex = 38;
            // 
            // tabpCmd1
            // 
            this.tabpCmd1.BackColor = System.Drawing.SystemColors.Control;
            this.tabpCmd1.Controls.Add(this.pnlParam1);
            this.tabpCmd1.Location = new System.Drawing.Point(4, 22);
            this.tabpCmd1.Margin = new System.Windows.Forms.Padding(1);
            this.tabpCmd1.Name = "tabpCmd1";
            this.tabpCmd1.Size = new System.Drawing.Size(372, 575);
            this.tabpCmd1.TabIndex = 0;
            this.tabpCmd1.Text = "送信パラメータ1";
            this.tabpCmd1.ToolTipText = "コマンドパラメータNo.1";
            // 
            // pnlParam1
            // 
            this.pnlParam1.AutoScroll = true;
            this.pnlParam1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlParam1.Location = new System.Drawing.Point(0, 0);
            this.pnlParam1.Name = "pnlParam1";
            this.pnlParam1.Size = new System.Drawing.Size(372, 575);
            this.pnlParam1.TabIndex = 0;
            // 
            // tlpLog
            // 
            this.tlpLog.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tlpLog.ColumnCount = 1;
            this.tlpLog.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpLog.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpLog.Location = new System.Drawing.Point(0, 0);
            this.tlpLog.Margin = new System.Windows.Forms.Padding(0);
            this.tlpLog.Name = "tlpLog";
            this.tlpLog.RowCount = 2;
            this.tlpLog.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpLog.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpLog.Size = new System.Drawing.Size(939, 78);
            this.tlpLog.TabIndex = 0;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 713);
            this.Controls.Add(this.spcHorizontal);
            this.Controls.Add(this.stsMain);
            this.Controls.Add(this.mnuMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mnuMain;
            this.MinimumSize = new System.Drawing.Size(800, 400);
            this.Name = "FormMain";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "FormMain";
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.stsMain.ResumeLayout(false);
            this.stsMain.PerformLayout();
            this.spcHorizontal.Panel1.ResumeLayout(false);
            this.spcHorizontal.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spcHorizontal)).EndInit();
            this.spcHorizontal.ResumeLayout(false);
            this.spcVertical.Panel1.ResumeLayout(false);
            this.spcVertical.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spcVertical)).EndInit();
            this.spcVertical.ResumeLayout(false);
            this.tabcButton.ResumeLayout(false);
            this.tabpButton1.ResumeLayout(false);
            this.pnlButton1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudQrSendInterval)).EndInit();
            this.tabcRes.ResumeLayout(false);
            this.tabpRes1.ResumeLayout(false);
            this.tabpRes2.ResumeLayout(false);
            this.tabcCmd.ResumeLayout(false);
            this.tabpCmd1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.StatusStrip stsMain;
        private System.Windows.Forms.ToolStripMenuItem tsmItemFile;
        private System.Windows.Forms.ToolStripMenuItem tsmItemOpenLogFolder;
        private System.Windows.Forms.ToolStripSeparator tssFileMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmItemExit;
        private System.Windows.Forms.ToolStripMenuItem tsmItemTool;
        private System.Windows.Forms.ToolStripMenuItem tsmItemOption;
        private System.Windows.Forms.ToolStripMenuItem tsmItemHelp;
        private System.Windows.Forms.ToolStripMenuItem tsmItemManual;
        private System.Windows.Forms.ToolStripMenuItem tsmItemVersion;
        private System.Windows.Forms.ToolStripMenuItem tsmItemTopMost;
        private System.Windows.Forms.ToolStripMenuItem tsmItemScreenShot;
        private System.Windows.Forms.ToolStripStatusLabel tssLabelSimStatus;
        private System.Windows.Forms.ToolStripSplitButton tssButtonLog;
        private System.Windows.Forms.ToolStripMenuItem tsmItemLogClear;
        private System.Windows.Forms.ToolStripSplitButton tssButtonDebug;
        private System.Windows.Forms.ToolStripComboBox tscDebugMode;
        private System.Windows.Forms.ToolStripMenuItem tsmItemOpenQrFolder;
        private System.Windows.Forms.ToolStripStatusLabel tssLabelMessage;
        private System.Windows.Forms.SplitContainer spcHorizontal;
        private System.Windows.Forms.SplitContainer spcVertical;
        private System.Windows.Forms.TabControl tabcButton;
        private System.Windows.Forms.TabPage tabpButton1;
        private System.Windows.Forms.FlowLayoutPanel pnlButton1;
        private System.Windows.Forms.TabControl tabcCmd;
        private System.Windows.Forms.TabPage tabpCmd1;
        private System.Windows.Forms.FlowLayoutPanel pnlParam1;
        private System.Windows.Forms.TabControl tabcRes;
        private System.Windows.Forms.TabPage tabpRes1;
        private System.Windows.Forms.TabPage tabpRes2;
        private System.Windows.Forms.FlowLayoutPanel pnlRes1;
        private System.Windows.Forms.RichTextBox txtResult;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnA0;
        private System.Windows.Forms.TableLayoutPanel tlpLog;
        private System.Windows.Forms.CheckBox chkCmd00Log;
        private System.Windows.Forms.CheckBox chkQrSend;
        private System.Windows.Forms.NumericUpDown nudQrSendInterval;
        private System.Windows.Forms.Label lbQrSendInterval;
        private System.Windows.Forms.Button btnB0;
    }
}

