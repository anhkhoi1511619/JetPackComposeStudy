﻿using System;
using System.Text;
using Lecip;
using Lecip.Net;
using Lecip.Data;

namespace SimulatorApplication
{
    /// <summary>
    /// 主局
    /// </summary>
    class SimulatorMain : TcpIFQrControl
    {
        #region Event Handler
        /// <summary> 受信イベント </summary>
        public event EventHandler DataReceived;
        /// <summary> 受信イベント </summary>
        public event EventHandler ErrorReceived;
        /// <summary> タイムアウトイベント </summary>
        public event EventHandler TimeoutReceived;
        #endregion

        #region Property
        /// <summary> 結果ログ </summary>
        public string ResultLog       { get; set; }
        #endregion

        #region Field
        /// <summary> シミュレータデータ </summary>
        private SimData simData;
        #endregion

        #region Constructor
        public SimulatorMain()
        {
            this.TcpDataReceived    += (sender, e) => { receive(); };
            this.TcpErrorReceived   += (sender, e) => { error(); };
            this.TcpTimeoutReceived += (sender, e) => { timeout(); };

            this.simData = SimData.Instance;
            this.ResultLog = string.Empty;            
        }
        #endregion

        #region Private Method
        /// <summary>
        /// データ受信処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void receive()
        {
            receiveRes();

            this.DataReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>
        /// 通信エラー発生処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void error()
        {
            this.ErrorReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>
        /// 通信タイムアウト発生処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timeout()
        {
            this.TimeoutReceived?.Invoke(this, new EventArgs());
        }
        #endregion

        #region Send / Receive
        #region Send
        /// <summary>
        /// コマンドを送受信する
        /// </summary>
        /// <param name="cmd">コマンドコード</param>
        /// <returns></returns>
        public void SendCommand(byte cmd)
        {
            sendCommand(cmd);
        }

        /// <summary>
        /// コマンドを送受信する
        /// </summary>
        /// <param name="cmd">コマンドコード</param>
        /// <returns></returns>
        private void sendCommand(byte cmd)
        {
            this.Tcp.Send(cmd, getCmdParameter(cmd));
        }
        #endregion

        #region コマンド生成処理
        /// <summary>
        /// コマンドパラメータを生成
        /// </summary>
        /// <param name="cmd">コマンド</param>
        /// <returns>パラメータ</returns>
        private byte[] getCmdParameter(byte cmd)
        {
            switch (cmd)
            {
                case 0xA0: return getCmdA0();
                case 0xB0: return getCmdB0();
                default:
                    break;
            }

            return null;
        }

        /// <summary>
        /// A0Hコマンドのデータ部生成
        /// 異常発生時やQRデータが無い時はサイズ=0x00,0x00,データ無しを送信する
        /// </summary>
        /// <returns>コマンドデータ部</returns>
        private byte[] getCmdA0()
        {
            try
            {
                if (!System.IO.File.Exists($@"{SimData.QrFolder}\{this.simData.QrDataFile}"))
                {
                    return new byte[] { 0x00, 0x00 };
                }

                return readQrDataFile();
            }
            catch (Exception)
            {
                return new byte[] { 0x00, 0x00 };
            }
        }

        /// <summary>
        /// B0Hコマンドのデータ部生成
        /// 異常発生時やQRデータが無い時はサイズ=0x00,0x00,データ無しを送信する
        /// 現在ではB0のデータがQR01.txtファイルから取得している
        /// </summary>
        /// <returns>コマンドデータ部</returns>
        private byte[] getCmdB0()
        {
            try
            {
                if (!System.IO.File.Exists($@"{SimData.QrFolder}\{this.simData.QrDataFile}"))
                {
                    return new byte[] { 0x00, 0x00 };
                }

                return readQrDataFile();
            }
            catch (Exception)
            {
                return new byte[] { 0x00, 0x00 };
            }
        }

        /// <summary>
        /// QRデータファイルを読み込んで送信データを生成する
        /// </summary>
        /// <returns></returns>
        private byte[] readQrDataFile()
        {
            var qrTextData = System.IO.File.ReadAllText($@"{SimData.QrFolder}\{this.simData.QrDataFile}", Encoding.GetEncoding("Shift_JIS"));

            qrTextData = qrTextData.Replace("\r\n", string.Empty);
            var qrByteData = Util.ToByteArray(qrTextData);

            byte[] qrSendData = new byte[qrByteData.Length + 2];
            qrSendData[0] = (byte)((qrByteData.Length >> 8) & 0xFF);
            qrSendData[1] = (byte)(qrByteData.Length & 0xFF);
            Array.Copy(qrByteData, 0, qrSendData, 2, qrByteData.Length);

            return qrSendData;
        }
        #endregion

        #region Receive
        /// <summary>
        /// 受信結果表示処理
        /// </summary>
        private void receiveRes()
        {
            string rxCmd = $"{this.Tcp.RxCmd:X2}";
            string rxData = Util.ToString(this.Tcp.RxData);

            string log = $"Res[{rxCmd}H {this.simData.CmdList[rxCmd]}]";
            log += this.simData.CmdList[rxCmd, rxData];
            this.ResultLog = log;
        }
        #endregion
        #endregion
    }
}
