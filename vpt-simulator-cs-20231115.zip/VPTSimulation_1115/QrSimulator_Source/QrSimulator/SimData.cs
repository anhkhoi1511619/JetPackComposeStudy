﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace Lecip.Data
{
    /// <summary>
    /// シミュレータが機器と送受信するデータを扱うシングルトンクラス
    /// MainUIシミュレータ用にSimDataから継承
    /// 固有処理をこちらに定義
    /// </summary>
    public class SimData : SimBaseData
    {
        #region Property
        /// <summary>設定ファイルのファイルパス</summary>
        public static string SettingFilePath;

        /// <summary>CSVフォルダパス</summary>
        public static string QrFolder;

        #region Instance
        /// <summary>
        /// SimDataTabletのシングルトンインスタンスを取得
        /// 無ければ生成
        /// </summary>
        public new static SimData Instance
        {
            get
            {
                if (_simDataInstance == null)
                {
                    lock (lockForSingleton)
                    {
                        _simDataInstance = new SimData();
                    }
                }

                return (SimData)_simDataInstance;
            }
        }
        #endregion

        public XmlSettings Settings { get; private set; }

        #region 受信情報(制御部->QR(シミュレータ)
        public DataItemListBase Cmd00     { get; private set; }
        public DataItemListBase Cmd10     { get; private set; }

        public DataItemGrid     GridCmd00 { get; private set; }
        public DataItemGrid     GridCmd10 { get; private set; }

        /// <summary>ステータスコマンドのログを受信情報2に載せるかどうかのフラグ</summary>
        public bool             EnableCmd00Log { get; set; }
        #endregion

        #region 送信情報(QRシミュレータ->制御部)
        public DataItemListBase Res01     { get; private set; }
        public DataItemListBase Res91     { get; private set; }

        public DataItemGrid     GridRes01 { get; private set; }
        public DataItemGrid     GridRes91 { get; private set; }

        public string StsParamName { get; set; }
        public string QrDataFile   { get; set; }
        #endregion
        #endregion

        #region Constructor
        public SimData()
        {
            var asm = System.Reflection.Assembly.GetExecutingAssembly();

            this.Cmd00 = InitItemList(asm, "Cmd00.txt");
            this.Cmd10 = InitItemList(asm, "Cmd10.txt");
            this.Res01 = InitItemList(asm, "Res01.txt");
            this.Res91 = InitItemList(asm, "Res91.txt");

            this.GridCmd00 = new DataItemGrid();
            this.GridCmd00.Init(this.Cmd00, false);

            this.GridCmd10 = new DataItemGrid();
            this.GridCmd10.Init(this.Cmd10, false);

            this.GridRes01 = new DataItemGrid();
            this.GridRes01.Init(this.Res01, true);

            this.GridRes91 = new DataItemGrid();
            this.GridRes91.Init(this.Res91, true);

            var initList = new[] { this.Res01, this.Res91 };

            foreach (var cmd in initList)
            {
                foreach (var item in cmd)
                    if (item.DataType != DataType.Str) item.Text = "0";
            }
        }
        #endregion

        #region 設定値の復元、保存
        /// <summary>設定ファイルの読み込み</summary>
        public void LoadSettings(Form loadForm)
        {
            this.Settings = XmlSettings.Load(SettingFilePath);

            if (this.Settings.CommandParameter.Count <= 0)
            {
                saveCommandParameter("IPL", "01",     this.Res01);
                this.Res01[0].SetString("01");
                saveCommandParameter("APL", "01",     this.Res01);
                saveCommandParameter("Version", "11", this.Res91);
            }
            else
            {
                loadCommandParameter("Version", "11", this.Res91);
            }
        }

        /// <summary>設定ファイルの保存</summary>
        public void Save(Form loadForm)
        {
            saveCommandParameter("Version", "11", this.Res91);

            if (loadForm.WindowState == FormWindowState.Normal)
                this.Settings.Bounds = loadForm.Bounds;
            else
                this.Settings.Bounds = loadForm.RestoreBounds;
            this.Settings.WindowState = loadForm.WindowState;

            this.Settings.Save();
        }

        /// <summary>コマンドパラメータ設定の読み込み</summary>
        private void loadCommandParameter(string paramName, string cmdName, DataItemListBase paramList)
        {
            string p = this.Settings.CommandParameter.FirstOrDefault(i => i.StartsWith($"{paramName},{cmdName},"));
            if (!string.IsNullOrEmpty(p))
            {
                string[] pList = p.Split(',');
                paramList.SetString(pList[2]); //3番目に送信データ設定が入っている
            }
        }

        /// <summary>コマンドパラメータ設定の保存</summary>
        private void saveCommandParameter(string paramName, string cmdName, DataItemListBase paramList)
        {
            removeCommandParameter(paramName, cmdName);

            this.Settings.CommandParameter.Add($"{paramName},{cmdName},{Util.ToString(paramList.GetByteArray())}");
        }

        private void removeCommandParameter(string paramName, string cmdName)
        {
            string p = this.Settings.CommandParameter.FirstOrDefault(i => i.StartsWith($"{paramName},{cmdName},"));
            if (!string.IsNullOrEmpty(p))
            {
                this.Settings.CommandParameter.Remove(p);
            }
        }
        #endregion

        #region Public Method
        /// <summary>DataGridViewの選択表示をクリアする</summary>
        public void GridClearSelection()
        {
            this.GridRes01.ClearSelection();
            this.GridRes91.ClearSelection();
            this.GridCmd00.ClearSelection();
            this.GridCmd10.ClearSelection();
        }
        #endregion

        #region ステータス設定処理
        public List<string> GetStatusParameterList()
        {
            var list = new List<string>();

            foreach (var p in this.Settings.CommandParameter)
            {
                string[] pList = p.Split(',');
                if (pList[1] == "01") list.Add(pList[0]);
            }
            list.Add("設定値の保存");
            list.Add("設定値の新規登録");
            list.Add("リストから削除");

            return list;
        }

        public void LoadStatusParameter(string paramName)
        {
            this.StsParamName = paramName;
            loadCommandParameter(paramName, "01", this.Res01);
        }

        public void SaveStatusParameter()
        {
            saveCommandParameter(this.StsParamName, "01", this.Res01);
        }

        public void RemoveStatusParameter()
        {
            if (this.Settings.CommandParameter.Count <= 2) return;

            removeCommandParameter(this.StsParamName, "01");
        }
        #endregion

        #region QRファイル処理
        /// <summary>
        /// Qrファイルリストの一覧(List string)を取得する。
        /// </summary>
        /// <returns></returns>
        public List<string> GetQrFileList()
        {
            var filePathList = getFileList(SimData.QrFolder, "*.txt");
            filePathList.Add("最新の情報に更新...");
            filePathList.Add("QRフォルダを開く");

            return filePathList;
        }
        #endregion

        #region Private Method
        public List<string> getFileList(string directoryPath, string searchPattern)
        {
            var list = getFileList(directoryPath, searchPattern, true);

            return list.Select(i => i.Substring(directoryPath.Length + 1)).ToList();
        }

        private List<string> getFileList(string directoryPath, string searchPattern, bool getSubDirectory)
        {
            List<string> fileList = new List<string>();

            if (!Directory.Exists(directoryPath)) return fileList;

            string[] files = Directory.GetFiles(directoryPath, searchPattern);
            fileList.AddRange(files);

            if (getSubDirectory)
            {
                string[] dirList = Directory.GetDirectories(directoryPath);
                foreach (string dir in dirList)
                {
                    fileList.AddRange(getFileList(dir, searchPattern, true));
                }
            }
            return fileList;
        }
        #endregion
    }
}
