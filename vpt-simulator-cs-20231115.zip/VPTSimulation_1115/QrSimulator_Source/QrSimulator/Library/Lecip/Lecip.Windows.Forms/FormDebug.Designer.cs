﻿namespace Lecip.Windows.Forms
{
    partial class FormDebug
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDebug));
            this.rtbDebug = new System.Windows.Forms.RichTextBox();
            this.cmnuMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmItemCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemClear = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemTopMost = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemSaveText = new System.Windows.Forms.ToolStripMenuItem();
            this.cmnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // rtbDebug
            // 
            this.rtbDebug.ContextMenuStrip = this.cmnuMain;
            this.rtbDebug.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbDebug.Location = new System.Drawing.Point(0, 0);
            this.rtbDebug.Name = "rtbDebug";
            this.rtbDebug.ReadOnly = true;
            this.rtbDebug.Size = new System.Drawing.Size(800, 362);
            this.rtbDebug.TabIndex = 0;
            this.rtbDebug.Text = "";
            // 
            // cmnuMain
            // 
            this.cmnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmItemCopy,
            this.tsmItemClear,
            this.tsmItemTopMost,
            this.tsmItemSaveText});
            this.cmnuMain.Name = "cmnuMain";
            this.cmnuMain.Size = new System.Drawing.Size(238, 92);
            // 
            // tsmItemCopy
            // 
            this.tsmItemCopy.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemCopy.Image")));
            this.tsmItemCopy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmItemCopy.Name = "tsmItemCopy";
            this.tsmItemCopy.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.tsmItemCopy.Size = new System.Drawing.Size(237, 22);
            this.tsmItemCopy.Text = "コピー(&C)";
            this.tsmItemCopy.Click += new System.EventHandler(this.tsmItemCopy_Click);
            // 
            // tsmItemClear
            // 
            this.tsmItemClear.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemClear.Image")));
            this.tsmItemClear.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmItemClear.Name = "tsmItemClear";
            this.tsmItemClear.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.tsmItemClear.Size = new System.Drawing.Size(177, 22);
            this.tsmItemClear.Text = "削除(&D)";
            this.tsmItemClear.Click += new System.EventHandler(this.tsmItemClear_Click);
            // 
            // tsmItemTopMost
            // 
            this.tsmItemTopMost.CheckOnClick = true;
            this.tsmItemTopMost.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemTopMost.Image")));
            this.tsmItemTopMost.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsmItemTopMost.Name = "tsmItemTopMost";
            this.tsmItemTopMost.Size = new System.Drawing.Size(177, 22);
            this.tsmItemTopMost.Text = "常に手前に表示";
            this.tsmItemTopMost.CheckedChanged += new System.EventHandler(this.tsmItemTopMost_CheckedChanged);
            // 
            // tsmItemSaveText
            // 
            this.tsmItemSaveText.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemSaveText.Image")));
            this.tsmItemSaveText.Name = "tsmItemSaveText";
            this.tsmItemSaveText.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.tsmItemSaveText.Size = new System.Drawing.Size(237, 22);
            this.tsmItemSaveText.Text = "名前を付けて保存(&A)";
            this.tsmItemSaveText.Click += new System.EventHandler(this.tsmItemSaveText_Click);
            // 
            // FormDebug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 362);
            this.ContextMenuStrip = this.cmnuMain;
            this.Controls.Add(this.rtbDebug);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormDebug";
            this.Text = "デバッグ画面";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormDebug_FormClosing);
            this.cmnuMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbDebug;
        private System.Windows.Forms.ContextMenuStrip cmnuMain;
        private System.Windows.Forms.ToolStripMenuItem tsmItemTopMost;
        private System.Windows.Forms.ToolStripMenuItem tsmItemClear;
        private System.Windows.Forms.ToolStripMenuItem tsmItemCopy;
        private System.Windows.Forms.ToolStripMenuItem tsmItemSaveText;
    }
}