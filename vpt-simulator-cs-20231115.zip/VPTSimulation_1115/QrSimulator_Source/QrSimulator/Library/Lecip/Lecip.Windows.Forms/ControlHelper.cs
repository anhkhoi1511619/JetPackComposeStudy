﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace Lecip.Windows.Forms
{
    /// <summary>
    /// コントロール関係のヘルパークラス
    /// </summary>
    public class ControlHelper
    {
        #region DataGridView処理
        /// <summary>
        /// 選択セルの内容をクリアする コンテキストメニューから呼ばれる
        /// </summary>
        public static void ClearGridCell(Control control)
        {
            if (!(control is DataGridView)) return;

            DataGridView grid = (DataGridView)control;

            if (grid.SelectedCells.Count > 1)
            {
                if (!Util.MessageQ("選択されたセルの内容をクリアしてよろしいですか？", "セルクリア")) return;
            }

            foreach (DataGridViewCell cell in grid.SelectedCells)
            {
                if (!(cell is DataGridViewButtonCell))
                    cell.Value = string.Empty;
            }
        }

        /// <summary>
        /// 選択行の内容をクリアする コンテキストメニューから呼ばれる
        /// </summary>
        public static void ClearGridRow(Control control)
        {
            if (!(control is DataGridView)) return;

            if (!Util.MessageQ("選択された行の内容をクリアしてよろしいですか？", "行クリア")) return;

            DataGridView grid = (DataGridView)control;

            if (grid.SelectedRows.Count <= 0)
            {
                Util.MessageInfo("行クリアするには行全体を選択してしてください", "行クリア");
                return;
            }

            foreach (DataGridViewRow row in grid.SelectedRows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (!(cell is DataGridViewButtonCell))
                        cell.Value = null;
                }
            }
        }

        /// <summary>
        /// 選択範囲のセルからタブ区切りのテキストを生成しクリップボードにコピーする
        /// </summary>
        /// <param name="control">コピー元のコントロール(DataGridView限定)を指定</param>
        /// <param name="includeHeader">ヘッダを含めるか否かの設定 true:含める false:含めない(デフォルト)</param>
        public static void CopyGridToClipboard(Control control, bool includeHeader = false)
        {
            if (!(control is DataGridView)) return;
            DataGridView grid = (DataGridView)control;

            //選択セルを取得
            DataGridViewSelectedCellCollection selectedCells = grid.SelectedCells;

            //選択の仕方でコレクションの並びが違うので、総なめして開始位置、終了位置を求める
            string tsv = string.Empty;
            int topCol = int.MaxValue;
            int topRow = int.MaxValue;
            int endCol = -1;
            int endRow = -1;
            foreach (DataGridViewCell cell in selectedCells)
            {
                if (cell.ColumnIndex < topCol) topCol = cell.ColumnIndex;
                if (cell.RowIndex < topRow) topRow = cell.RowIndex;
                if (cell.ColumnIndex > endCol) endCol = cell.ColumnIndex;
                if (cell.RowIndex > endRow) endRow = cell.RowIndex;
            }

            if (includeHeader)
            {
                for (int col = topCol; col < endCol; col++)
                {
                    tsv += $"{grid.Columns[col].HeaderText}\t";
                }
                tsv += grid.Columns[endCol].HeaderText;
                tsv += "\n";
            }

            //タブ区切りのテキストを生成してクリップボードに貼り付ける
            for (int row = topRow; row <= endRow; row++)
            {
                for (int col = topCol; col <= endCol; col++)
                {
                    if ((grid[col, row].Value != null) && !(grid[col, row].Value is DBNull)) tsv += (string)grid[col, row].Value;
                    if (col != endCol) tsv += "\t";
                }
                if (row != endRow) tsv += "\n";
            }
            if (!string.IsNullOrEmpty(tsv)) Clipboard.SetText(tsv, TextDataFormat.Text);
            grid.CurrentCell = grid[topCol, topRow];
        }

        /// <summary>
        /// タブ区切りのクリップボードテキストを選択セルを先頭に貼り付ける
        /// 行追加可能タイプ
        /// </summary>
        /// <param name="control">コピー先のコントロール(DataGridView限定)を指定</param>
        public static void PasteGridFromClipboard(Control control)
        {
            if (!(control is DataGridView) && !(control is DataGridViewEx)) return;
            DataGridView grid = (DataGridView)control;

            int startRowIndex = grid.CurrentCell.RowIndex;    //貼り付け開始行
            int startColIndex = grid.CurrentCell.ColumnIndex; //貼り付け開始列
            int gridRowCount = grid.RowCount;                 //gridの現在行数
            int gridColCount = grid.Columns.Count;            //gridの列数
            int gridMaxRowCount = (control is DataGridViewEx) ? ((DataGridViewEx)control).MaxRowCount : grid.RowCount; //gridの増やせる最大行数

            //クリップボードにテキストデータが無いときは何もしない
            IDataObject data = Clipboard.GetDataObject();
            if (data == null) return;
            //DataFormats.Textに関連付けられたデータがあるか調べる
            if (!data.GetDataPresent(DataFormats.Text)) return;

            object getData = Clipboard.GetData(DataFormats.Text);
            if (getData == null)
            {
                Util.MessageInfo("貼り付けるデータがありません", "貼り付け");
                return;
            }

            var pasteRows = ((string)getData).Replace("\r", "")
                .Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);

            var pasteRowCount = Math.Min(pasteRows.Length, gridMaxRowCount - startRowIndex);
            for (int rowCount = 0; rowCount < pasteRowCount; rowCount++)
            {
                var rowIndex = startRowIndex + rowCount;

                if ((grid.RowCount <= rowIndex + 1) && grid.AllowUserToAddRows) grid.Rows.Add(new string[gridColCount]);

                // タブ区切りでセル値を取得
                var pasteCells = pasteRows[rowCount].Split('\t');

                // 選択位置から列数繰り返す
                var maxColCount = Math.Min(pasteCells.Length, gridColCount - startColIndex);
                for (int colCount = 0; colCount < maxColCount; colCount++)
                {
                    var colIndex = startColIndex + colCount;

                    grid[colIndex, rowIndex].Value = pasteCells[colCount];
                    grid[colIndex, rowIndex].Selected = true;
                }
            }
            if (grid.RowCount >= gridMaxRowCount) grid.AllowUserToAddRows = false;
        }

        /// <summary>
        /// CSVの内容をDataGridViewへ取り込む
        /// </summary>
        /// <param name="control"></param>
        public static void ImportCsv(Control control)
        {
            if (!(control is DataGridView) && !(control is DataGridViewEx)) return;
            DataGridView grid = (DataGridView)control;

            int    gridColCount = grid.Columns.Count; //gridの列数
            string dirPath  = $@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}";
            string filePath = $"{grid.Name}.csv";

            if (!Util.MessageQ($"CSVファイルを取り込んで{grid.Name}を更新しますか？\r\n(※CSVの内容に上書きされますが保存を実行するまではファイルに書き込まれません)", "CSVファイルからのインポート")) return;
            if (Util.SelectFile("インポートするCSVファイルを指定してください", "CSVファイル|*.csv", dirPath, ref filePath) == DialogResult.Cancel) return;

            try
            {
                using (var sr = new StreamReader(filePath, Encoding.GetEncoding("Shift_JIS")))
                {
                    string line;
                    //ヘッダチェック
                    if (sr.EndOfStream)
                    {
                        Util.MessageErr("CSVファイルにデータが存在しません。中止しました。", "CSVファイルからのインポート");
                        return;
                    }

                    line = sr.ReadLine();
                    string[] cells = line.Split(',');
                    if (cells.Length < gridColCount)
                    {
                        if (!Util.MessageQ("CSVファイルとインポート先が一致しない可能性があります\r\n(列数不一致)。続行しますか？", "CSVファイルからのインポート")) return;
                    }
                    for (int i = 0; i < gridColCount; i++)
                    {
                        if (grid.Columns[i].Name != cells[i])
                        {
                            if (!Util.MessageQ($"CSVファイルとインポート先が一致しない可能性があります\r\n(項目名不一致 {grid.Columns[i].Name} <-> {cells[i]})。続行しますか？", "CSVファイルからのインポート")) return;
                        }
                    }

                    int gridMaxRowCount = (control is DataGridViewEx) ? ((DataGridViewEx)control).MaxRowCount : grid.RowCount; //gridの増やせる最大行数
                    grid.Rows.Clear();
                    if (gridMaxRowCount < 10000)
                    {
                        //1万件未満の時は全件表示する
                        grid.RowCount = gridMaxRowCount;
                        grid.AllowUserToAddRows = false;
                    }
                    else
                    {
                        grid.AllowUserToAddRows = true;
                    }

                    int rowIndex = 0;
                    while (!sr.EndOfStream)
                    {
                        line = sr.ReadLine();
                        cells = line.Split(',');

                        if (cells.Length >= gridColCount)
                        {
                            //行を追加できるのであれば追加
                            if ((grid.RowCount <= rowIndex + 1) && grid.AllowUserToAddRows) grid.Rows.Add(new string[gridColCount]);

                            for (int colIndex = 0; colIndex < gridColCount; colIndex++)
                            {
                                grid[colIndex, rowIndex].Value = cells[colIndex];
                            }

                            rowIndex++;
                            if (rowIndex >= gridMaxRowCount) break;
                        }
                    }

                    if (grid.RowCount >= gridMaxRowCount) grid.AllowUserToAddRows = false;
                }

                Util.MessageInfo("CSVファイルからのインポートを完了しました", "CSVファイルからのインポート");
            }
            catch (Exception ex)
            {
                Util.MessageErr($"CSVファイルからのインポートに失敗しました。\r\n{ex.Message}", "CSVファイルからのインポート");
            }
        }

        /// <summary>
        /// DataGridViewの内容をCSVファイルへエクスポートする
        /// </summary>
        /// <param name="control"></param>
        public static void ExportCsv(Control control)
        {
            if (!(control is DataGridView)) return;
            DataGridView grid = (DataGridView)control;

            string dirPath  = $@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}";
            string filePath = $"{grid.Name}.csv";

            if (!Util.MessageQ($"{grid.Name}をCSVファイルへエクスポートしますか？", "CSVファイルへのエクスポート")) return;
            if (Util.SaveFile("出力先CSVファイルを指定してください", "CSVファイル|*.csv", dirPath, ref filePath) == DialogResult.Cancel) return;

            try
            {
                using (var sw = new StreamWriter(filePath, false, Encoding.GetEncoding("Shift_JIS")))
                {
                    //ヘッダ書込
                    foreach (DataGridViewColumn c in grid.Columns)
                    {
                        sw.Write($"{c.Name},");
                    }
                    sw.WriteLine();

                    //データ書込
                    foreach (DataGridViewRow row in grid.Rows)
                    {
                        string oneline = string.Empty;
                        bool allEmpty = true;

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (!string.IsNullOrEmpty((string)cell.Value)) allEmpty = false;

                            oneline += $"{cell.Value},";
                        }
                        if (allEmpty) break;    //全部空だったら途中でも終わる

                        sw.WriteLine(oneline); //1行追加
                    }
                }

                Util.MessageInfo("CSVファイルへのエクスポートを完了しました", "CSVファイルへのエクスポート");
            }
            catch (Exception ex)
            {
                Util.MessageErr($"CSVファイルへのエクスポートに失敗しました。\r\n{ex.Message}", "CSVファイルへのエクスポート");
            }
        }
        #endregion

        #region テキスト関係処理
        /// <summary>
        /// 指定の文字数をテキストボックスに表示する際の横幅ピクセルを返す
        /// </summary>
        /// <param name="length"></param>
        /// <param name="f"></param>
        /// <returns></returns>
        public static int TextWidth(int length, Font f)
        {
            string text = "D".PadLeft(length, 'D');

            return TextRenderer.MeasureText(text, f).Width;
        }

        /// <summary>
        /// 指定の文字列をテキストボックスに表示する際の横幅ピクセルを返す
        /// </summary>
        /// <param name="text"></param>
        /// <param name="f"></param>
        /// <returns></returns>
        public static int TextWidth(string text, Font f)
        {
            return TextRenderer.MeasureText(text, f).Width;
        }

        /// <summary>
        /// 指定バイトサイズの10進入力時の最大文字数を返す
        /// 例) byteSize = 1  戻り=3 (255)
        ///     byteSize = 2  戻り=5 (65535)
        ///     byteSize上限8まで
        /// </summary>
        /// <param name="byteSize"></param>
        /// <returns></returns>
        public static int GetDecTextMaxLength(int byteSize)
        {
            byteSize = (byteSize > 8) ? 8 : byteSize;

            UInt64 max;

            max = Convert.ToUInt64(System.Math.Pow(0x100, byteSize) - 1);

            string text = max.ToString();

            return text.Length;
        }

        /// <summary>
        /// SJISコードの文字列のバイト数を返す
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static int GetSjisByteCount(string text)
        {
            var sjis = Encoding.GetEncoding("shift-jis");

            return sjis.GetByteCount(text);
        }
        #endregion

        #region その他
        /// <summary>
        /// ツールチップをコントロールに追加する
        /// </summary>
        /// <param name="c"></param>
        /// <param name="caption"></param>
        public static void AddToolTip(Control c, string caption)
        {
            var t = new ToolTip();

            t.SetToolTip(c, caption);
        }

        /// <summary>
        /// テキストボックスでEnterキーが押されたときにTABキーを送って
        /// 次のコントロールへ移動する(親フォームに設定する)
        /// </summary>
        public static KeyEventHandler FormKeyDownEvent()
        {
            return (object sender, KeyEventArgs e) =>
            {
                Form frm = (Form)sender;

                if (e.KeyCode == Keys.Enter)
                {
                    if (!e.Control && !(frm.ActiveControl is DataGridView))
                    {
                        frm.SelectNextControl(frm.ActiveControl, !e.Shift, true, true, true);
                    }
                }
            };
        }

        /// <summary>
        /// ComboBox にboolean の DataSource を設定。
        /// </summary>
        /// <param name="comboBox">対象の ComboBox</param>
        /// <param name="trueText">true の場合の表示文字列</param>
        /// <param name="falseText">false の場合の表示文字列</param>
        public static void SetBooleanDataSource(ComboBox comboBox, string trueText, string falseText)
        {
            var b = new Dictionary<bool, string>();
            b.Add(true, trueText);
            b.Add(false, falseText);
            comboBox.DataSource = null;
            comboBox.ValueMember = "Key";
            comboBox.DisplayMember = "Value";
            comboBox.DataSource = b.ToList();
        }
        #endregion

    }
}
