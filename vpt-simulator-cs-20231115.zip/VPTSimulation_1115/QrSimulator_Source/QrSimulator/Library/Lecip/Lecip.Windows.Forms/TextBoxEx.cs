﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Windows.Forms
{
    /// <summary>
    /// 入力制限・入力テキスト整形機能付きのテキストボックス
    /// </summary>
    public class TextBoxEx : TextBox
    {
        #region enum
        /// <summary>
        /// 入力制限・入力テキスト整形機能付きのテキストボックス
        /// </summary>
        public enum InputMode
        {
            /// <summary>制限なし</summary>
            All,
            /// <summary>16進数</summary>
            Hex,
            /// <summary>10進数</summary>
            Dec,
            /// <summary>Bcd</summary>
            Bcd,
            /// <summary>通貨(未使用)</summary>
            Money,
        }
        #endregion

        #region Property
        /// <summary>
        /// 入力モード切り替え
        /// </summary>
        public InputMode Input
        {
            get
            {
                return input;
            }
            set
            {
                input = value;
                if (input == InputMode.All)
                {
                    this.ImeMode = ImeMode.Off;
                    this.CharacterCasing = CharacterCasing.Normal;
                }
                else
                {
                    this.ImeMode = ImeMode.Disable;
                    this.CharacterCasing = CharacterCasing.Upper;
                }
            }
        }
        /// <summary>最小値</summary>
        public decimal Minimum { get; set; }
        /// <summary>最大値</summary>
        public decimal Maximum { get; set; }
        #endregion

        #region Field
        private string prvText;
        private InputMode input;
        #endregion

        #region Constructror
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TextBoxEx()
        {
            this.ImeMode = ImeMode.Off;
            this.Text = "";
            this.prvText = "";
            this.input = InputMode.All;

            Minimum = 0;
            Maximum = -1;
        }
        #endregion

        #region Override
        /// <summary>
        /// 入力値のチェック
        /// </summary>
        /// <param name="e"></param>
        protected override void OnValidated(EventArgs e)
        {
            base.OnValidated(e);

            if (input == InputMode.Hex || input == InputMode.Bcd)
            {
                //入力文字列を整形する(大文字＋指定バイトまで"0"を付ける
                //Hexの時は上限128文字(64Byte)とする(MaxLengthの設定し忘れを考慮)
                int maxLength = (this.MaxLength > 128) ? 128 : this.MaxLength; 

                this.Text = this.Text.ToUpper().PadLeft(maxLength, '0');
            }

            if (Maximum > Minimum)
            {
                if (input == InputMode.Dec || input == InputMode.Hex)
                {
                    //最小値・最大値の範囲内にあるかチェック(範囲外なら直前の入力値に戻す)
                    if (checkMinMax())
                    {
                        prvText = this.Text;
                    }
                    else
                    {
                        this.Text = prvText;
                    }
                }
            }

            if (input == InputMode.All)
            {
                //日本語入力の時の入力文字数チェック(バイト数でチェック。文字数オーバーなら直前の入力値に戻す)
                var sjis = Encoding.GetEncoding("shift-jis");
                var text = sjis.GetBytes(this.Text);

                if (text.Length <= MaxLength)
                {
                    prvText = this.Text;
                }
                else
                {
                    this.Text = prvText;
                }
            }
        }

        /// <summary>
        /// 入力制限をかける
        /// </summary>
        /// <param name="e"></param>
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            base.OnKeyPress(e);

            if (input != InputMode.All)
            {
                //文字制限チェック
                if (e.KeyChar == '\b' || e.KeyChar == '\n' || e.KeyChar == '\r' || e.KeyChar == 0x3 || e.KeyChar == 0x16) return;

                if (input == InputMode.Dec || input == InputMode.Bcd)
                {
                    if ((e.KeyChar < '0' || e.KeyChar > '9'))
                    {
                        e.Handled = true;
                        return;
                    }
                }

                if (input == InputMode.Hex)
                {
                    if ((e.KeyChar < '0' || e.KeyChar > '9') &&
                        (e.KeyChar < 'A' || e.KeyChar > 'F') &&
                        (e.KeyChar < 'a' || e.KeyChar > 'f'))
                    {
                        e.Handled = true;
                        return;
                    }
                }
            }

        }

        /// <summary>
        /// フォーカスが来たときに全選択する
        /// マウスクリック時は無効
        /// </summary>
        /// <param name="e"></param>
        protected override void OnEnter(EventArgs e)
        {
            base.OnEnter(e);

            this.SelectAll();
        }
        #endregion

        #region Private Method
        /// <summary>
        /// 最小値・最大値範囲チェック
        /// </summary>
        /// <returns></returns>
        private bool checkMinMax()
        {
            decimal val;
            string text = (string.IsNullOrEmpty(this.Text)) ? "0" : this.Text;
            if (input == InputMode.Hex)
            {
                if (text.Length > 16) return true; //16進文字列が16文字(8Byte)以上の場合、範囲チェックをしない

                UInt64 temp = Convert.ToUInt64(text, 16);
                val = Convert.ToDecimal(temp);
            }
            else
            {
                val = Convert.ToDecimal(text);
            }
            //Min 
            if (val < Minimum) return false;
            
            //Maximum < Minimumの場合、最大値範囲チェックをしない
            if (Maximum < Minimum) return true;

            //Max            
            if (val > Maximum) return false;

            return true;
        }
        #endregion
    }
}
