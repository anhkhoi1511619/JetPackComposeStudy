﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Windows.Forms
{
    /// <summary>
    /// 入力ボックス画面クラス
    /// </summary>
    public partial class InputBox : Form
    {
        /// <summary>
        /// 入出力テキスト
        /// </summary>
        public string InputText
        {
            get
            {
                return this.txtInput.Text;
            }
            set
            {
                this.txtInput.Text = value;
            }
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public InputBox()
        {
            InitializeComponent();
        }

        private void FormInput_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 入力ボックス画面を表示する
        /// </summary>
        /// <param name="text"></param>
        /// <param name="caption"></param>
        /// <param name="initialText"></param>
        /// <returns></returns>
        public DialogResult Show(string text, string caption, string initialText)
        {
            this.Text = caption;
            this.lblText.Text = text;
            if (initialText != string.Empty) this.txtInput.Text = initialText;

            return this.ShowDialog();
        }
    }
}
