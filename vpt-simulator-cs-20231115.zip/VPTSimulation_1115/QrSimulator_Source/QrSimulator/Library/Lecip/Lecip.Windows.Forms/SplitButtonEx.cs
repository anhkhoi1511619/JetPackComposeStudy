﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Windows.Forms
{
    /// <summary>
    /// SplitButtonクラスの拡張版
    /// Itemsプロパティでリストの一覧を設定
    /// SelectedIndexプロパティで選択中の一覧の設定・取得が可能
    /// </summary>
    public class SplitButtonEx : SplitButton
    {
        #region Field
        private string   headerText;
        private string[] items;
        private int      selectedIndex;
        #endregion
        
        #region event
        /// <summary>
        /// リスト中の選択項目が切り替わったときに発生するイベント
        /// </summary>
        public event System.EventHandler SelectedIndexChanged;
        #endregion

        #region Properties
        /// <summary>
        /// 選択したアイテムの要素番号(0～)
        /// </summary>
        public int SelectedIndex
        {
            get { return selectedIndex; }
            set
            {
                if (items != null && 0 <= value && value < items.Length)
                {
                    selectedIndex = value;
                    this.Text = headerText + "\n" + items[selectedIndex];
                }
            }
        }

        /// <summary>
        /// リストに表示する項目
        /// </summary>
        public string[] Items
        {
            get { return items; }
            set
            {
                items = value;

                this.ContextMenuStrip.Items.Clear();

                for (int i = 0; i < items.Length; i++)
                {
                    ToolStripMenuItem item = new ToolStripMenuItem(items[i], null, this.onClick, items[i]);

                    this.ContextMenuStrip.Items.Add(item);
                }
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SplitButtonEx()
        {
            var menu = new ContextMenuStrip();
            this.ContextMenuStrip = menu;
            selectedIndex = -1;
            headerText = string.Empty;
            items = new string[] { "" };
        }
        #endregion

        #region Private Method
        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        protected override void OnTextChanged(EventArgs e)
        {
            base.OnTextChanged(e);

            if (string.IsNullOrEmpty(headerText)) headerText = this.Text;
        }

        private void onClick(object sender, EventArgs e)
        {
            ToolStripMenuItem item = (ToolStripMenuItem)sender;

            this.Text = headerText + "\n" + item.Text;

            for (int i = 0; i < this.SplitMenuStrip.Items.Count; i++)
            {
                ToolStripMenuItem strip = (ToolStripMenuItem)this.SplitMenuStrip.Items[i];
                if (item.Equals(strip))
                {
                    selectedIndex = i;
                    break;
                }
            }

            if (SelectedIndexChanged != null) SelectedIndexChanged(this, e);
        }
        #endregion
    }
}