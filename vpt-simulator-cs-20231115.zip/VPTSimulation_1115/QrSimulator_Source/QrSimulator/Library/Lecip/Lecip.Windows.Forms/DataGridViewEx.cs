﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;

namespace Lecip.Windows.Forms
{
    /// <summary>
    /// DataGridViewの拡張版
    /// 入力抑制機能あり
    /// </summary>
    public class DataGridViewEx : DataGridView
    {
        /// <summary>
        /// 以下は暫定的・・・本当はもっといいやり方があるはず
        /// 入力制限のための定義
        /// </summary>
        public enum InputMode
        {
            /// <summary>文字列(制限無し)</summary>
            All,
            /// <summary>16進数</summary>
            Hex,
            /// <summary>10進数</summary>
            Dec,
            /// <summary>Bcd</summary>
            Bcd,
            /// <summary>通貨(未実装)</summary>
            Money,
            /// <summary>コンボボックス(未実装)</summary>
            Combo,
            /// <summary>チェックボックス(未実装)</summary>
            Check,
        }

        //各列に対して入力制限設定を持つ
        private List<InputMode> lstInput;

        private List<decimal> lstMin;
        private List<decimal> lstMax;

        private bool rowNumberVisible;
        private bool rowNumberZeroStart;

        /// <summary>行番号を行ヘッダに表示するか否かの設定 true:する false:しない</summary>
        public bool RowNumberVisible
        {
            get { return rowNumberVisible; }
            set { rowNumberVisible = value; }
        }

        /// <summary>行番号の先頭を0とするかしないかの設定 true:する false:しない</summary>
        public bool RowNumberZeroStart
        {
            get { return rowNumberZeroStart; }
            set { rowNumberZeroStart = value; }
        }

        /// <summary>
        /// 設定できる最大行数
        /// </summary>
        public int MaxRowCount { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public DataGridViewEx()
        {
            //DoubleBuffered = true;
            this.lstInput = new List<InputMode>();
            this.lstMin = new List<decimal>();
            this.lstMax = new List<decimal>();

            this.rowNumberVisible = true;
            this.rowNumberZeroStart = false;
            this.MaxRowCount = -1;

            this.RowTemplate.HeaderCell = new DataGridViewRowHeaderCellEx();
            this.RowTemplate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        /// <summary>
        /// 入力モードを設定(カラムごと)
        /// </summary>
        /// <param name="m"></param>
        public void SetInputMode(InputMode m)
        {
            lstInput.Add(m);
        }

        /// <summary>
        /// 最小値を設定(カラムごと)
        /// </summary>
        /// <param name="min"></param>
        public void SetMin(decimal min)
        {
            lstMin.Add(min);
        }

        /// <summary>
        /// 最大値を設定(カラムごと)
        /// </summary>
        /// <param name="max"></param>
        public void SetMax(decimal max)
        {
            lstMax.Add(max);
        }

        /// <summary>
        /// 行ヘッダに行番号を表示するためのオーバーライド
        /// </summary>
        /// <param name="e"></param>
        protected override void OnRowPostPaint(DataGridViewRowPostPaintEventArgs e)
        {
            base.OnRowPostPaint(e);

            if (!rowNumberVisible) return;

            int rowNumber = (rowNumberZeroStart) ? e.RowIndex : e.RowIndex + 1;

            Rectangle rect = new Rectangle(
                e.RowBounds.Location.X,
                e.RowBounds.Location.Y,
                this.RowHeadersWidth - 4,
                e.RowBounds.Height);

            TextRenderer.DrawText(
                e.Graphics,
                rowNumber.ToString(),
                this.RowHeadersDefaultCellStyle.Font,
                rect,
                this.RowHeadersDefaultCellStyle.ForeColor,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
        }

        /// <summary>
        /// イベントハンドラの登録・解除を行う
        /// </summary>
        /// <param name="e"></param>
        protected override void OnEditingControlShowing(DataGridViewEditingControlShowingEventArgs e)
        {
            base.OnEditingControlShowing(e);

            if (e.Control is DataGridViewTextBoxEditingControl)
            {
                var tb = (DataGridViewTextBoxEditingControl)e.Control;

                tb.KeyPress -= new KeyPressEventHandler(dgvtb_HexKeyPress);
                tb.KeyPress -= new KeyPressEventHandler(dgvtb_DecKeyPress);
                //tb.KeyDown  -= new KeyEventHandler(dgvtb_KeyDown);

                if (this.CurrentCell.ColumnIndex >= lstInput.Count) return;

                if (lstInput[this.CurrentCell.ColumnIndex] == InputMode.Hex)
                {
                    tb.KeyPress += new KeyPressEventHandler(dgvtb_HexKeyPress);
                }
                if (lstInput[this.CurrentCell.ColumnIndex] == InputMode.Dec)
                {
                    tb.KeyPress += new KeyPressEventHandler(dgvtb_DecKeyPress);
                }
                if (lstInput[this.CurrentCell.ColumnIndex] == InputMode.Bcd)
                {
                    tb.KeyPress += new KeyPressEventHandler(dgvtb_DecKeyPress);
                }

                //tb.KeyDown += new KeyEventHandler(dgvtb_KeyDown);
            }
        }

        /// <summary>
        /// 16進数のときのみ、入力内容を指定桁数に合わせて整形する
        /// 整形の後でまたこれが呼ばれる。改良の余地あり
        /// </summary>
        /// <param name="e"></param>
        protected override void OnCellValueChanged(DataGridViewCellEventArgs e)
        {
            base.OnCellValueChanged(e);

            if (e.RowIndex < 0) return;
            if (e.ColumnIndex < 0) return;

            if (e.ColumnIndex >= lstInput.Count) return;

            if (!(this.Columns[e.ColumnIndex] is DataGridViewTextBoxColumn)) return;

            DataGridViewCell cell = this[e.ColumnIndex, e.RowIndex];

            if (cell.Value == null) return;
            if (string.IsNullOrEmpty(cell.Value.ToString())) return;

            string v = cell.Value.ToString();
            int maxInputLength = ((DataGridViewTextBoxColumn)this.Columns[e.ColumnIndex]).MaxInputLength;
            
            //16進数のときのみ、入力内容を指定桁数に合わせて整形する
            if (lstInput[e.ColumnIndex] == InputMode.Hex || lstInput[e.ColumnIndex] == InputMode.Bcd)
            {
                //入力文字列を整形する(大文字＋指定バイトまで"0"を付ける
                //Hexの時は上限128文字(64Byte)とする(MaxLengthの設定し忘れを考慮)
                int maxLength = (maxInputLength > 128) ? 128 : maxInputLength;

                v = v.ToUpper().PadLeft(maxLength, '0');
                cell.Value = v;
            }

            if (lstInput[e.ColumnIndex] == InputMode.Dec || lstInput[e.ColumnIndex] == InputMode.Bcd)
            {
                if (!isNumeric((string)cell.Value))
                {
                    string msg = string.Format("不正な文字 [{0}]が入力されました", (string)cell.Value);
                    MessageBox.Show(msg, "入力チェック", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cell.Value = lstMin[e.ColumnIndex].ToString();
                    return;
                }
            }
            if (lstInput[e.ColumnIndex] == InputMode.Hex)
            {
                if (!IsHexadecimal((string)cell.Value))
                {
                    string msg = string.Format("不正な文字 [{0}]が入力されました", (string)cell.Value);
                    MessageBox.Show(msg, "入力チェック", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cell.Value = lstMin[e.ColumnIndex].ToString();
                    return;
                }
            }

            if (lstInput[e.ColumnIndex] == InputMode.Dec ||
                lstInput[e.ColumnIndex] == InputMode.Hex ||
                lstInput[e.ColumnIndex] == InputMode.Bcd)
            {

                if (!checkMinMax((string)cell.Value, e.ColumnIndex))
                {
                    string msg = string.Format("上限または下限をオーバーしています\n{0}～{1}で入力してください", lstMin[e.ColumnIndex], lstMax[e.ColumnIndex]);
                    MessageBox.Show(msg, "範囲チェック", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cell.Value = lstMin[e.ColumnIndex].ToString();
                }
            }

            if (lstInput[e.ColumnIndex] == InputMode.All)
            {
                var sjis = Encoding.GetEncoding("shift-jis");
                byte[] bytText = sjis.GetBytes(v);

                if (bytText.Length > maxInputLength)
                {
                    string msg = string.Format("入力文字数がオーバーしています\n{0}文字(byte)で入力してください", maxInputLength);
                    MessageBox.Show(msg, "文字数チェック", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cell.Value = "";
                }
            }
        }

        /// <summary>
        /// CellEnter時の処理
        /// </summary>
        /// <param name="e"></param>
        protected override void OnCellEnter(DataGridViewCellEventArgs e)
        {
            base.OnCellEnter(e);

            if (this.Columns[e.ColumnIndex] is DataGridViewComboBoxColumn)
            {
               //SendKeys.Send("{F4}");
            }
        }

        private void dgvtb_HexKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b' || e.KeyChar == '\n' || e.KeyChar == '\r' || e.KeyChar == 0x3 || e.KeyChar == 0x16) return;

            if ((e.KeyChar < '0' || e.KeyChar > '9') &&
                (e.KeyChar < 'A' || e.KeyChar > 'F') &&
                (e.KeyChar < 'a' || e.KeyChar > 'f'))
            {
                e.Handled = true;
                return;
            }
        }

        private void dgvtb_DecKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\b' || e.KeyChar == '\n' || e.KeyChar == '\r' || e.KeyChar == 0x3 || e.KeyChar == 0x16) return;

            if ((e.KeyChar < '0' || e.KeyChar > '9'))
            {
                e.Handled = true;
                return;
            }
        }

        private void dgvtb_KeyDown(object sender, KeyEventArgs e)
        {
            var tb = (DataGridViewTextBoxEditingControl)sender;

            if (e.Control) System.Diagnostics.Debug.WriteLine(e.KeyCode.ToString());

            if (e.Control && e.KeyCode.ToString() == "C")
            {
                Clipboard.SetDataObject(tb.SelectedText.ToString());
            }
        }

        /// <summary>
        /// 最小値・最大値範囲チェック
        /// </summary>
        /// <returns></returns>
        private bool checkMinMax(string text, int colIndex)
        {
            decimal val;
            text = text ?? "0";

            if (lstMax[colIndex] <= lstMin[colIndex]) return true;

            if (lstInput[colIndex] == InputMode.Hex)
            {
                UInt64 temp = Convert.ToUInt64(text, 16);
                val = Convert.ToDecimal(temp);
            }
            else
            {
                val = Convert.ToDecimal(text);
            }
            //Min 
            if (val < lstMin[colIndex]) return false;
            //Max
            if (val > lstMax[colIndex]) return false;

            return true;
        }

        private bool IsHexadecimal(string value)
        {
            System.Text.RegularExpressions.Regex r = null;
            System.Text.RegularExpressions.Match m = null;

            r = new System.Text.RegularExpressions.Regex(@"^[0-9A-Fa-f]+$");
            m = r.Match(value);
            if (!m.Success)
            {
                return false;
            }

            return true;
        }

        private bool isNumeric(string value)
        {
            System.Text.RegularExpressions.Regex r = null;
            System.Text.RegularExpressions.Match m = null;

            r = new System.Text.RegularExpressions.Regex(@"\d+");
            m = r.Match(value);
            if (!m.Success)
            {
                return false;
            }

            return true;
        }
    }
}
