﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Windows.Forms
{
    /// <summary>
    /// デバッグ画面クラス
    /// </summary>
    public partial class FormDebug : Form
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public FormDebug()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 表示クリア
        /// </summary>
        public void Clear()
        {
            this.rtbDebug.Clear();
        }

        /// <summary>
        /// 文字列を追加
        /// </summary>
        /// <param name="text"></param>
        public void AppendLine(string text)
        {
            //text = DateTime.Now.ToString("HH:mm:ss.fff> ") + text + "\r\n";

            this.rtbDebug.AppendText(text + "\r\n");
        }

        /// <summary>
        /// ×ボタンを押したときにクローズではなく非表示にする
        /// ソフト終了時に呼び出し元で確実にClose、Disposeすること
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormDebug_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        /// <summary>
        /// クリップボードにコピー
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsmItemCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(this.rtbDebug.SelectedText);
        }

        /// <summary>
        /// 表示内容を全て削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsmItemClear_Click(object sender, EventArgs e)
        {
            this.rtbDebug.Clear();
        }

        /// <summary>
        /// 常に手前に表示のONOFF
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsmItemTopMost_CheckedChanged(object sender, EventArgs e)
        {
            var item = (ToolStripMenuItem)sender;

            this.TopMost = item.Checked;
        }

        /// <summary>
        /// 名前を付けて保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tsmItemSaveText_Click(object sender, EventArgs e)
        {
            string filename = string.Empty;

            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "テキスト ファイル(*.txt)|*.txt";
                dlg.Title = "名前を付けて保存";
                dlg.FileName = "デバッグログ_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";

                if (dlg.ShowDialog() == DialogResult.Cancel) return;

                System.IO.File.WriteAllText(dlg.FileName, this.rtbDebug.Text, Encoding.GetEncoding("Shift_JIS"));
            }
        }
    }
}