﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Utility
{
    /// <summary>
    /// コメント機能クラス
    /// </summary>
    public class Commenter
    {
        private static List<Setting> settings = new List<Setting>();

        /// <summary>
        /// コメントを追加
        /// 引数のcontrolにフォーカスが来たときに引数のlabelにコメントを表示する
        /// </summary>
        /// <param name="label">コメントを表示するラベルコントロール</param>
        /// <param name="control">フォーカス対象のコントロール</param>
        /// <param name="comment">コメント文字列</param>
        public static void Add(Label label, Control control, string comment)
        {
            if (label == null || control == null) return;

            Remove(label, control);

            var s = new Setting();
            s.Label = label;
            s.Control = control;

            try
            {
                s.Enter = (sender, e) =>
                {
                    label.Text = comment;
                };
                control.Enter += s.Enter;

                s.Leave = (sender, e) =>
                {
                    label.Text = string.Empty;
                };
                control.Leave += s.Leave;

                settings.Add(s);
            }
            catch
            {
                if (s.Enter != null)
                {
                    control.Enter -= s.Enter;
                }

                if (s.Leave != null)
                {
                    control.Leave -= s.Leave;
                }

                throw;
            }
        }

        /// <summary>
        /// コメントを追加
        /// 引数のDataGridViewにフォーカスが来たときに引数のlabelにコメントを表示する
        /// </summary>
        /// <param name="label">コメントを表示するラベルコントロール</param>
        /// <param name="control">フォーカス対象のDataGridView</param>
        /// <param name="comments">コメント文字列リスト(一列目のコメント、二列目のコメント...の順番)</param>
        public static void Add(Label label, DataGridView control, List<string> comments)
        {
            if (label == null || control == null) return;

            Remove(label, control);

            var s = new Setting();
            s.Label = label;
            s.Control = control;

            try
            {
                s.CellEnter = (sender, e) =>
                {
                    label.Text = comments[e.ColumnIndex];
                };
                control.CellEnter += s.CellEnter;

                s.CellLeave = (sender, e) =>
                {
                    label.Text = string.Empty;
                };
                control.CellLeave += s.CellLeave;

                settings.Add(s);
            }
            catch
            {
                if (s.CellEnter != null)
                {
                    control.CellEnter -= s.CellEnter;
                }

                if (s.CellLeave != null)
                {
                    control.CellLeave -= s.CellLeave;
                }

                throw;
            }
        }

        /// <summary>
        /// コメントを表示する機能を停止する
        /// </summary>
        /// <param name="label">コメントを表示していたラベルコントロール</param>
        /// <param name="control">フォーカス対象のコントロール</param>
        public static void Remove(Label label, Control control)
        {
            var list = settings.FindAll(i => i.Label == label && i.Control == control);
            foreach (var item in list)
            {
                label.Text = string.Empty;
                item.Label = null;
                if (item.Control is DataGridView)
                {
                    ((DataGridView)item.Control).CellEnter -= item.CellEnter;
                    ((DataGridView)item.Control).CellLeave -= item.CellLeave;
                }
                else
                {
                    item.Control.Enter -= item.Enter;
                    item.Control.Leave -= item.Leave;
                }
                item.Control = null;
                settings.Remove(item);
            }
        }

        private class Setting
        {
            public Label Label { get; set; }
            public Control Control { get; set; }
            public EventHandler Enter { get; set; }
            public EventHandler Leave { get; set; }

            public DataGridViewCellEventHandler CellEnter { get; set; }
            public DataGridViewCellEventHandler CellLeave { get; set; }

        }

    }
}