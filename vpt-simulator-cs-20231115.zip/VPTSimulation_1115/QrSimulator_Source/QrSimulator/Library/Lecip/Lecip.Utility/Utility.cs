﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Net.NetworkInformation;

namespace Lecip.Utility
{
    /// <summary>
    /// 少し役に立つクラス
    /// </summary>
    public static class Utility
    {
        #region Menu Function
        /// <summary>
        /// エクスプローラで指定したフォルダを開く
        /// </summary>
        /// <param name="folderPath">フォルダパス</param>
        public static void OpenExplorer(string folderPath)
        {
            if (!Directory.Exists(folderPath)) return;
            System.Diagnostics.Process.Start(folderPath);
        }

        /// <summary>
        /// 指定したファイルを開く(関連付けられたアプリケーションが起動する)
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        public static void OpenFile(string filePath)
        {
            if (!File.Exists(filePath)) return;
            System.Diagnostics.Process.Start(filePath);
        }

        /// <summary>
        /// アプリケーションのバージョン情報を表示する
        /// </summary>
        public static void DisplayVersion()
        {
            string msg = string.Empty;

            var a = new FileInfo(Application.ExecutablePath);

            msg += Path.GetFileName(Application.ExecutablePath);
            msg += "\r\n作成日時: ";
            msg += a.LastWriteTime.ToString();

            Util.MessageInfo(msg, "バージョン情報");
        }

        /// <summary>
        /// 指定したサイズのスクリーンショットをファイルに保存する
        /// 保存先はファイル名の拡張子で変化する(bmp or png)
        /// </summary>
        /// <param name="rc"></param>
        /// <param name="filename"></param>
        public static void SaveFromScreen(Rectangle rc, string filename)
        {
            using (Bitmap bmp = new Bitmap(rc.Width, rc.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb))
            {
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.CopyFromScreen(rc.X, rc.Y, 0, 0, rc.Size, CopyPixelOperation.SourceCopy);
                }

                bmp.Save(filename);
            }
        }

        /// <summary>
        /// 指定したホスト名またはIPアドレスにPingを1回打つ
        /// 結果を文字列で返す
        /// </summary>
        /// <param name="hostname"></param>
        /// <returns></returns>
        public static string Ping(string hostname)
        {
            if (string.IsNullOrEmpty(hostname)) return string.Empty; //hostnameが無いときは何もしない

            using (var p = new System.Net.NetworkInformation.Ping())
            {
                var reply = p.Send(hostname);

                if (reply.Status == System.Net.NetworkInformation.IPStatus.Success)
                {
                    return string.Format("Ping reply from {0}:bytes={1} time={2}ms TTL={3}",
                                          reply.Address, 
                                          reply.Buffer.Length, 
                                          reply.RoundtripTime, 
                                          reply.Options.Ttl);
                }
                else
                {
                    return string.Format("Ping fail ({0})", reply.Status);
                }
            }
        }
        #endregion

        #region Network Function
        /// <summary>
        /// ネットワーク名に該当するIPアドレス(v4)を文字列で返す
        /// ネットワーク名が空文字の場合、一番最初のアドレスを返す
        /// (ネットワークにつながっていなくても取得可能)
        /// </summary>
        /// <param name="networkName">ネットワーク名(ローカル エリア接続)など</param>
        /// <returns></returns>
        public static string GetIpV4Address(string networkName)
        {
            NetworkInterface[] adp = NetworkInterface.GetAllNetworkInterfaces();

            foreach (NetworkInterface nic in adp)
            {
                if (networkName == string.Empty || networkName == nic.Name)
                {
                    UnicastIPAddressInformationCollection addrs = nic.GetIPProperties().UnicastAddresses;

                    foreach (UnicastIPAddressInformation addr in addrs)
                    {
                        if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            string ipaddress = addr.Address.ToString();

                            //PC起動直後でLANに未接続時、IP=169.254.XXX.XXXの誤った値になるので
                            //その場合レジストリから固定IPアドレスを取得する
                            if (ipaddress.StartsWith("169.254")) ipaddress = GetIpV4AddressFromReg(nic.Id, ipaddress);

                            return ipaddress;
                        }
                    }
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// レジストリに設定されたIPアドレスをネットワークGUIDを元に取得する
        /// 取得失敗時は引数に渡されたIPアドレスを返す
        /// </summary>
        /// <param name="networkId">ネットワークGUID</param>
        /// <param name="ipaddress">取得失敗時に返すIPアドレス</param>
        /// <returns>取得IPアドレス</returns>
        public static string GetIpV4AddressFromReg(string networkId, string ipaddress)
        {
            using (Microsoft.Win32.RegistryKey regkey =
                Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"System\CurrentControlSet\services\Tcpip\Parameters\Interfaces\" + networkId, false))
            {
                try
                {
                    if (regkey != null)
                    {
                        string[] v = (string[])regkey.GetValue("IPAddress");

                        if (v != null && v.Length > 0)
                        {
                            ipaddress = (string)v[0]; //取得成功
                        }

                        //閉じる
                        regkey.Close();
                    }
                }
                catch (Exception)
                {
                    return ipaddress; //取得失敗
                }
            }

            return ipaddress;
        }

        /// <summary>
        /// IPV4のネットワーク名の一覧リストを返す
        /// </summary>
        /// <returns></returns>
        public static string[] GetIpV4NetworkNameList()
        {
            List<string> networkNames = new List<string>();
            NetworkInterface[] adp = NetworkInterface.GetAllNetworkInterfaces();

            foreach (NetworkInterface nic in adp)
            {
                UnicastIPAddressInformationCollection addrs = nic.GetIPProperties().UnicastAddresses;

                foreach (UnicastIPAddressInformation addr in addrs)
                {
                    if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        if (!nic.Name.StartsWith("Loopback Pseudo-Interface"))
                        {
                            networkNames.Add(nic.Name);
                            break;
                        }
                    }
                }
            }

            return networkNames.ToArray();
        }

        /// <summary>
        /// 入力文字列がIPアドレスV4形式か調べる
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsIpAddrV4Format(string value)
        {
            var split = value.Split('.');

            if (split.Length != 4) return false;

            foreach (string s in split)
            {
                if (!Util.IsNumeric(s)) return false;

                int v = Convert.ToInt32(s);
                if (v < 0 || 255 < v) return false;
            }

            return true;
        }

        public static string calcIntegerToHex(decimal value)
        {
            return value.ToString("X");
        }
        #endregion

        #region Control
        /// <summary>
        /// パネル上の全てのDataGridViewの選択状態を解除
        /// </summary>
        /// <param name="pnl"></param>
        public static void ClearSelectionGridOnPanel(Panel pnl)
        {
            foreach (var control in pnl.Controls)
            {
                if (control is DataGridView)
                {
                    ((DataGridView)control).ClearSelection();
                }
                else if (control is TabControl)
                {
                    foreach (TabPage p in ((TabControl)control).TabPages)
                    {
                        foreach (var control2 in p.Controls)
                        {
                            if (control2 is DataGridView)
                            {
                                ((DataGridView)control2).ClearSelection();
                            }
                            else if (control2 is Panel)
                            {
                                foreach (Control control3 in ((Panel)control2).Controls)
                                {
                                    if (control3 is DataGridView)
                                    {
                                        ((DataGridView)control3).ClearSelection();
                                    }
                                }
                            }
                        }
                    }
                }
                else if (control is Panel)
                {
                    foreach (Control child in ((Panel)control).Controls)
                    {
                        if (child is DataGridView)
                        {
                            ((DataGridView)child).ClearSelection();
                        }
                    }
                }
            }
        }
        #endregion

        #region File
        /// <summary>
        /// デスクトップのフォルダパスを取得
        /// </summary>
        /// <returns></returns>
        public static string DesktopFolder()
        {
            return Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        }

        /// <summary>
        /// ディレクトリをコピーする
        /// </summary>
        /// <param name="sourceDirName">コピーするディレクトリ</param>
        /// <param name="destDirName">コピー先のディレクトリ</param>
        /// <param name="overWrite">コピー先を上書きするフラグ</param>
        public static void CopyDirectory(string sourceDirName, string destDirName, bool overWrite = false)
        {
            if (!Directory.Exists(sourceDirName)) return;
            if (!overWrite) if (Directory.Exists(destDirName)) return;

            //コピー先のディレクトリがないときは作る
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
                //属性もコピー
                File.SetAttributes(destDirName, File.GetAttributes(sourceDirName));
            }

            //コピー先のディレクトリ名の末尾に"\"をつける
            if (destDirName[destDirName.Length - 1] != Path.DirectorySeparatorChar)
                destDirName = destDirName + Path.DirectorySeparatorChar;

            //コピー元のディレクトリにあるファイルをコピー
            string[] files = Directory.GetFiles(sourceDirName);
            foreach (string file in files)
                File.Copy(file, destDirName + Path.GetFileName(file), true);

            //コピー元のディレクトリにあるディレクトリについて、再帰的に呼び出す
            string[] dirs = Directory.GetDirectories(sourceDirName);
            foreach (string dir in dirs)
                CopyDirectory(dir, destDirName + Path.GetFileName(dir));
        }
        #endregion
    }
}
