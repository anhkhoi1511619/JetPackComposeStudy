﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Lecip.Utility
{
    /// <summary>
    /// プロパティ更新通知機能を持つクラス
    /// </summary>
    public class NotifyPropertyChange : INotifyPropertyChanged
    {
        /// <summary>
        /// プロパティが更新通知イベントハンドラ
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// プロパティが更新されたことを通知
        /// </summary>
        /// <param name="propertyName">プロパティ名</param>
        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
