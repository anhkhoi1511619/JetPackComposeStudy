﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Lecip.Utility
{
    /// <summary>
    /// 時間計測用クラス
    /// </summary>
    public class TimeCountByPerfomanceCounter
    {
        [DllImport("kernel32.dll")]
        static extern bool QueryPerformanceCounter(ref long lpPerformanceCount);
        [DllImport("kernel32.dll")]
        static extern bool QueryPerformanceFrequency(ref long lpPerformanceFrequency);

        /// <summary>計測開始カウンタ</summary>
        private static long startCounter;

        /// <summary>計測開始</summary>
        public static void Start()
        {
            QueryPerformanceCounter(ref startCounter);
        }

        /// <summary>
        /// 計測終了(ミリ秒を返す)
        /// </summary>
        /// <returns>計測開始から終了までにかかった時間(ミリ秒)</returns>
        public static double ElapsedMilliSec()
        {
            long stopCounter = 0;
            QueryPerformanceCounter(ref stopCounter);
            long frequency = 0;
            QueryPerformanceFrequency(ref frequency);
            return (double)(stopCounter - startCounter) * 1000.0 / frequency;
        }

    }
}
