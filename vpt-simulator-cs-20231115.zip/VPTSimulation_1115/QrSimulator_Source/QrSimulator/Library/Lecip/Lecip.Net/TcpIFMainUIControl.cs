﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Net
{
    /// <summary>Main-UI間 TCP通信インターフェースコントロール</summary>
    public class TcpIFMainUIControl : Control
    {
        #region Event Handler
        /// <summary> データ受信イベントハンドラ </summary>
        public event EventHandler TcpDataReceived;
        /// <summary> エラー発生イベントハンドラ </summary>
        public event EventHandler TcpErrorReceived;
        /// <summary> タイムアウト発生イベントハンドラ </summary>
        public event EventHandler TcpTimeoutReceived;
        #endregion

        #region Property
        /// <summary> MainUI TCP通信インターフェース </summary>
        public TcpIFMainUI Tcp      { get; private set; }
        #endregion

        #region Constructor
        /// <summary> コンストラクタ </summary>
        public TcpIFMainUIControl()
        {
            TextBoxLog textLog = new TextBoxLog() { Dock = DockStyle.Fill };
            this.Controls.Add(textLog);

            this.Tcp = new TcpIFMainUI();
            this.Tcp.TcpIFWriteLog        += (sender, type, log) => {


                Console.WriteLine("=====================================>>>>>");
                textLog.UpdateLog((MsgType)type, log); 
            
            
            };
            this.Tcp.TcpIFMainUIReceived  += (sender, e) => { if (this.TcpDataReceived != null)    base.Invoke(this.TcpDataReceived, sender, e); };
            this.Tcp.TcpIFErrorReceived   += (sender, e) => { if (this.TcpErrorReceived != null)   base.Invoke(this.TcpErrorReceived, sender, e); };
            this.Tcp.TcpIFTimeoutReceived += (sender, e) => { if (this.TcpTimeoutReceived != null) base.Invoke(this.TcpTimeoutReceived, sender, e); };
        }
        #endregion
    }
}
