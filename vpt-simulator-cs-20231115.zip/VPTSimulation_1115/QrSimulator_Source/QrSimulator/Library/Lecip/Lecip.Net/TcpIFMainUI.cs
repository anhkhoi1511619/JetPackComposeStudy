﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lecip.Net
{
    /// <summary>Main-UI間 TCP通信インターフェース</summary>
    public class TcpIFMainUI : TcpIF
    {
        #region Event Handler
        /// <summary>受信イベントハンドラ</summary>
        public event EventHandler TcpIFMainUIReceived;
        #endregion

        #region Property
        /// <summary>送信コマンド</summary>
        public byte TxCmd    { get; private set; }
        /// <summary>受信コマンド</summary>
        public byte RxCmd    { get; private set; }
        /// <summary>受信データ部</summary>
        public byte[] RxData { get; private set; }
        /// <summary>シーケンス番号</summary>
        public byte SeqNo    { get; set; }

        #region Debug Property
        /// <summary>デバッグモード データサイズ異常</summary>
        public bool DebugSize     { get; set; }
        /// <summary>デバッグモード データサイズサム異常</summary>
        public bool DebugSizeSum  { get; set; }
        /// <summary>デバッグモード シーケンス番号固定</summary>
        public bool DebugSeqNo    { get; set; }
        /// <summary>デバッグモード データ部サム異常</summary>
        public bool DebugDataSum  { get; set; }
        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return new string[] { "通常", "データサイズ異常", "データサイズサム異常", "シーケンス番号固定", "データ部サム異常" }; } }
        /// <summary>
        /// デバッグモードを設定するプロパティ
        /// 0:通常(デバッグモード解除) / 1:データサイズ項目異常 / 2:データサイズサム異常 / 3:シーケンス番号固定 / 4:データ部サム異常 </summary>
        public int DebugMode
        {
            set
            {
                this.DebugSize = this.DebugSizeSum = this.DebugSeqNo = this.DebugDataSum = false;

                switch (value)
                {
                    case 0: break; //通常
                    case 1: this.DebugSize    = true; break; //データサイズ異常
                    case 2: this.DebugSizeSum = true; break; //データサイズサム異常
                    case 3: this.DebugSeqNo   = true; break; //シーケンス番号固定
                    case 4: this.DebugDataSum = true; break; //データ部サム異常
                    default: break;
                }
            }
        }
        #endregion
        #endregion

        #region Field
        /// <summary>Stx</summary>
        private readonly byte Stx = 0x02;
        /// <summary>Etx</summary>
        private readonly byte Etx = 0x03;
        /// <summary>最小サイズ(STX,SZ,SZ,SZSUM,CMD,SEQ,DATASUM,ETX)</summary>
        private readonly int MinSize = 8;
        /// <summary>送信コマンドバッファ</summary>
        private byte[] sendBuffer;
        #endregion

        #region Constructor
        /// <summary> コンストラクタ </summary>
        public TcpIFMainUI()
        {
            this.DebugMode = 0;
            this.SeqNo    = 0x01;

            this.sendBuffer = new byte[65535];
            this.TcpIFDataReceived += (sender, e) => { receive(); };
        }
        #endregion

        #region Public Method
        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="cmd">送信コマンド</param>
        /// <param name="data">送信コマンドデータ部</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        /// <returns></returns>
        public bool Send(byte cmd, byte[] data, int receiveTimeout = 0)
        {
            if (receiveTimeout > 0) this.ReceiveTimeout = receiveTimeout;
            int size     = (data != null) ? data.Length : 0;
            int dataSize = size;           //データサイズ項目(データ部のサイズ)
            int sendSize = MinSize + size; //データ送信総サイズ

            //STX
            this.sendBuffer[0] = Stx;
            //データサイズセット(対象:データ部)
            if (this.DebugSize) dataSize++;
            this.sendBuffer[1] = (byte)(dataSize >> 8 & 0xFF);
            this.sendBuffer[2] = (byte)(dataSize & 0xFF);
            //データサイズサムセット(対象:データサイズ)
            this.sendBuffer[3] = calcSum(this.sendBuffer, 1, 2);
            if (this.DebugSizeSum) this.sendBuffer[3]++;
            //コマンドセット
            this.TxCmd = cmd;
            this.sendBuffer[4] = cmd;
            //シーケンス番号セット
            this.sendBuffer[5] = this.SeqNo;
            //データ部セット
            if (size > 0) Array.Copy(data, 0, this.sendBuffer, 6, size);
            //データ部サムセット(対象:コマンド～データ部)
            this.sendBuffer[6 + size] = calcSum(this.sendBuffer, 4, 2 + size);
            if (this.DebugDataSum) this.sendBuffer[6 + size]++;
            //ETXセット
            this.sendBuffer[7 + size] = Etx;

            //応答が必要なコマンドの場合、タイムアウト処理を開始(recevieTimeoutが0未満の場合、タイムアウト処理を行わない)
            if (receiveTimeout >= 0) base.StartReceiveTimeout();

            //送信
            return base.Send(this.sendBuffer, sendSize);
        }
        #endregion

        #region Private Method
        /// <summary>
        /// LFZZ Main-UI通信受信処理
        /// フォーマットが正しいかチェックし、データを格納する
        /// </summary>
        private void receive()
        {
            //Stxチェック
            if (this.RxRawData[0] != Stx)
            {
                SetError(MsgType.RxMsg, "受信データエラー(STX)");
                return;
            }
            // 受信サイズチェック
            if (this.RxRawData.Length < MinSize)
            {
                SetError(MsgType.RxMsg, "受信データエラー(サイズ)");
                return;
            }
            //データサイズ長チェック(受信トータルサイズとの一致チェック)
            int size = this.RxRawData[1] * 0x100 + this.RxRawData[2];
            if (this.RxRawData.Length != (size + MinSize))
            {
                SetError(MsgType.RxMsg, "受信データエラー(データサイズ)");
                return;
            }
            //データサイズサムチェック
            byte sum = calcSum(this.RxRawData, 1, 2);
            if (this.RxRawData[3] != sum)
            {
                SetError(MsgType.RxMsg, "受信データエラー(データサイズサム)");
                return;
            }
            //受信コマンド格納
            this.RxCmd = this.RxRawData[4];
            //シーケンス番号更新
            this.SeqNo = this.RxRawData[5];
            if (!this.DebugSeqNo)
            {
                if (this.SeqNo >= 0xFE)
                    this.SeqNo = 0x01;
                else
                    this.SeqNo++;
            }
            //データ部格納
            this.RxData = new byte[size];
            if (size > 0) Array.Copy(this.RxRawData, 6, this.RxData, 0, size);
            //データ部サムチェック
            sum = calcSum(this.RxRawData, 4, 2 + size);
            if (this.RxRawData[6 + size] != sum)
            {
                SetError(MsgType.RxMsg, "受信データエラー(データ部サム)");
                return;
            }
            //Etxチェック
            if (this.RxRawData[7 + size] != Etx)
            {
                SetError(MsgType.RxMsg, "受信データエラー(ETX)");
                return;
            }

            setReceive();
        }

        /// <summary>受信イベントを起こす</summary>
        private void setReceive()
        {
            this.TcpIFMainUIReceived?.Invoke(this, new EventArgs());
        }
        /// <summary>
        /// チェックサムを計算する
        /// </summary>
        /// <param name="data">チェックサム対象データ</param>
        /// <param name="start">開始インデックス</param>
        /// <param name="length">データ長</param>
        /// <returns></returns>
        private byte calcSum(byte[] data, int start, int length)
        {
            byte sum = 0;
            for (int i = 0; (i < length) && (i + start < data.Length); i++)
            {
                sum += data[i + start];
            }

            sum = (byte)(0x100 - sum);
            return sum;
        }
        #endregion
    }
}
