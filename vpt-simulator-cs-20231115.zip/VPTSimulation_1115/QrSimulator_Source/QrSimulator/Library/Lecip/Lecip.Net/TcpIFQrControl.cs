﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Net
{
    /// <summary>QR制御部-QR乗車降車間 TCP通信インターフェースコントロール</summary>
    public class TcpIFQrControl : Control
    {
        #region Event Handler
        /// <summary> データ受信イベントハンドラ </summary>
        public event EventHandler TcpDataReceived;
        /// <summary> エラー発生イベントハンドラ </summary>
        public event EventHandler TcpErrorReceived;
        /// <summary> タイムアウト発生イベントハンドラ </summary>
        public event EventHandler TcpTimeoutReceived;
        #endregion

        #region Property
        /// <summary> MainUI TCP通信インターフェース </summary>
        public TcpIFQr Tcp { get; private set; }
        #endregion

        #region Constructor
        /// <summary> コンストラクタ </summary>
        public TcpIFQrControl()
        {
            TextBoxLog textLog = new TextBoxLog() { Dock = DockStyle.Fill };
            this.Controls.Add(textLog);

            this.Tcp = new TcpIFQr();
            this.Tcp.TcpIFWriteLog        += (sender, type, log) => {

                Console.WriteLine(" show on GUI PLZ ==========================>>> ");
                
                textLog.UpdateLog((MsgType)type, log); 
            
            };
            this.Tcp.TcpIFQrReceived      += (sender, e) => { if (this.TcpDataReceived != null)    base.Invoke(this.TcpDataReceived, sender, e); };
            this.Tcp.TcpIFErrorReceived   += (sender, e) => { if (this.TcpErrorReceived != null)   base.Invoke(this.TcpErrorReceived, sender, e); };
            this.Tcp.TcpIFTimeoutReceived += (sender, e) => { if (this.TcpTimeoutReceived != null) base.Invoke(this.TcpTimeoutReceived, sender, e); };
        }
        #endregion
    }
}
