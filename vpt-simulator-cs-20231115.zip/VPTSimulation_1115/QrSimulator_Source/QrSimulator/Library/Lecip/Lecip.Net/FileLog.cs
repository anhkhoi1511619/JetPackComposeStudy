﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Lecip.Net
{
    /// <summary>
    /// テキストファイルにログを出力するクラス
    /// </summary>
    public class FileLog : IDisposable
    {

        #region メンバ変数
        /// <summary> ログを出力するファイルパス </summary>
        private string filePath = string.Empty;
        /// <summary> ログを出力するためのStreamWriter </summary>
        private StreamWriter sw = null;
        /// <summary> 書込み有効無効フラグ </summary>
        private bool enbaled = false;
        #endregion

        #region プロパティ
        /// <summary> 書込み有効無効フラグ </summary>
        public bool Enabled
        {
            get 
            {
                return this.enbaled;
            }
            set
            {
                if (this.enbaled != value)
                {
                    this.enbaled = value;
                    if (!this.Enabled) close();
                }
            }
        }
        #endregion

        #region Dispose
        /// <summary> Dispose処理 </summary>
        public void Dispose()
        {
            this.Close();
        }
        #endregion

        #region Public Method
        /// <summary>
        /// ログに追加する(即ログファイルに書き込む)
        /// </summary>
        /// <param name="filePath">ログファイルパス</param>
        /// <param name="writeLog">書込むデータ</param>
        public void Write(string filePath, string writeLog)
        {
            //無効の時は何もしない
            if (!this.enbaled) return;

            //ファイルをオープンする
            open(filePath);

            //ファイルに書込む(クローズはしない)
            write(writeLog);
        }

        /// <summary>
        /// ログファイルをクローズする
        /// </summary>
        public void Close()
        {
            close();
        }
        #endregion

        #region Private Method
        /// <summary>
        /// ログファイルをオープンする
        /// (ファイルが無ければこの時点で空のファイルが生成される)
        /// (追記型、エンコード=ShiftJIS固定)
        /// </summary>
        /// <param name="filePath"></param>
        private void open(string filePath)
        {
            if (this.sw == null)
            {
                this.sw = new StreamWriter(filePath, true, Encoding.GetEncoding("shift_jis"));
                this.filePath = filePath;
            }
            else
            {
                if (this.filePath != filePath)
                {
                    //ファイルパスが切り替わったらクローズして再オープンする
                    close();
                    open(filePath);
                } 
            }
        }

        /// <summary>
        /// ログファイルをクローズする
        /// </summary>
        private void close()
        { 
            if (this.sw != null)
            {
                this.sw.Close();
                this.sw.Dispose();
                this.sw = null;
            }
        }

        /// <summary>
        /// ログファイルにログを書込む
        /// ファイルをオープンしていない場合は何もしない
        /// </summary>
        /// <param name="log">書込むログ</param>
        private void write(string log)
        {
            if (this.sw != null)
            {
                this.sw.WriteLine(log);
            }
        }
        #endregion
    }
}
