﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Lecip
{
    /// <summary>
    /// byte型Listの拡張クラス
    /// </summary>
    public class ByteList : List<byte>
    {
        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public ByteList()
        {
        }

        /// <summary>
        /// インスタンス生成時にbyte配列を指定
        /// </summary>
        /// <param name="array"></param>
        public ByteList(byte[] array)
        {
            this.AddRange(array);
        }

        /// <summary>
        /// インスタンス生成時にバイナリファイルパスを指定
        /// </summary>
        /// <param name="filePath"></param>
        public ByteList(string filePath)
        {
            this.Read(filePath);
        }
        #endregion

        /// <summary>
        /// byte型ListをListに追加
        /// </summary>
        /// <param name="collection">追加データ</param>
        public void Add(IEnumerable<byte> collection)
        {
            this.AddRange(collection);
        }

        /// <summary>
        /// ByteListをListに追加
        /// </summary>
        /// <param name="byteList">追加データ</param>
        public void Add(ByteList byteList)
        {
            this.AddRange(byteList.ToList());
        }

        /// <summary>
        /// byte配列をListに追加
        /// </summary>
        /// <param name="array">追加データ</param>
        public void Add(byte[] array)
        {
            //array.ToList<byte>();

            this.AddRange(array);
        }

        /// <summary>
        /// UInt16をListに追加(BigEndian) 
        ///     0x1234 => 0x12, 0x34
        /// </summary>
        /// <param name="value">追加データ</param>
        public void Add(UInt16 value)
        {
            this.Add(value, false);
        }

        /// <summary>
        /// byteをListに追加
        ///     0x12 => 0x12
        /// </summary>
        /// <param name="value">追加データ</param>
        public new void Add(byte value)
        {
            base.Add(value);
        }

        /// <summary>
        /// UInt16をListに追加(BigEndian,LittleEndian指定可能)
        ///     (B) 0x1234 => 0x12, 0x34
        ///     (L) 0x1234 => 0x34, 0x12
        /// </summary>
        /// <param name="value">追加データ</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        public void Add(UInt16 value, bool isLittleEndian)
        {
            var array = BitConverter.GetBytes(value);
            if (BitConverter.IsLittleEndian != isLittleEndian)
            {
                Array.Reverse(array);
            }

            this.Add(array);
        }

        /// <summary>
        /// UInt32をListに追加(BigEndian)
        ///     0x12345678 => 0x12, 0x34, 0x56, 0x78
        /// </summary>
        /// <param name="value">追加データ</param>
        public void Add(UInt32 value)
        {
            this.Add(value, false);
        }

        /// <summary>
        /// UInt32をListに追加(BigEndian,LittleEndian指定可能)
        ///     (B) 0x12345678 => 0x12, 0x34, 0x56, 0x78
        ///     (L) 0x12345678 => 0x78, 0x56, 0x34, 0x12
        /// </summary>
        /// <param name="value">追加データ</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        public void Add(UInt32 value, bool isLittleEndian)
        {
            var array = BitConverter.GetBytes(value);
            if (BitConverter.IsLittleEndian != isLittleEndian)
            {
                Array.Reverse(array);
            }

            this.Add(array);
        }

        /// <summary>
        /// UInt64をListに追加(BigEndian)
        ///     0x123456789ABCDEF0 => 0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0
        /// </summary>
        /// <param name="value">>追加データ</param>
        public void Add(UInt64 value)
        {
            this.Add(value, false);
        }

        /// <summary>
        /// UInt64をListに追加(BigEndian,LittleEndian指定可能)
        ///     (B) 0x123456789ABCDEF0 => 0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC, 0xDE, 0xF0
        ///     (L) 0x123456789ABCDEF0 => 0xF0, 0xDE, 0xBC, 0x9A, 0x78, 0x56, 0x34, 0x12
        /// </summary>
        /// <param name="value">追加データ</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        public void Add(UInt64 value, bool isLittleEndian)
        {
            var array = BitConverter.GetBytes(value);
            if (BitConverter.IsLittleEndian != isLittleEndian)
            {
                Array.Reverse(array);
            }

            this.Add(array);
        }

        /// <summary>
        /// 数値文字列(16進文字列であること)をListに追加(BigEndian)
        ///     "1234FA" -> 0x12, 0x34, 0xFA
        ///  
        /// 例外:
        ///     System.FormatException
        /// </summary>
        /// <param name="value">追加データ</param>
        public void Add(string value)
        {
            if (!Util.IsHexadecimal(value)) throw new FormatException(string.Format("{0}は16進文字列ではありません", value));
            if (value.Length % 2 != 0) throw new FormatException(string.Format("{0}は16進文字列ではありません(桁数エラー)", value));

            for (int i = 0; i < value.Length; i += 2)
            {
                base.Add(Convert.ToByte(value.Substring(i, 2), 16));
            }
        }

        /// <summary>
        /// 数値文字列(16進文字列であること)をListに追加(BigEndian,LittleEndian指定可能)
        ///     (B) "1234FA" -> 0x12, 0x34, 0xFA
        ///     (L) "1234FA" -> 0xFA, 0x34, 0x12
        /// 例外:
        ///     System.FormatException
        /// </summary>
        /// <param name="value">追加データ</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        public void Add(string value, bool isLittleEndian)
        {
            if (!isLittleEndian)
            {
                this.Add(value);
                return;
            }

            if (!Util.IsHexadecimal(value)) throw new FormatException(string.Format("{0}は16進文字列ではありません", value));
            if (value.Length % 2 != 0) throw new FormatException(string.Format("{0}は16進文字列ではありません(桁数エラー)", value));

            for (int i = value.Length - 2; i >= 0; i -= 2)
            {
                this.Add(Convert.ToByte(value.Substring(i, 2), 16));
            }
        }

        /// <summary>
        /// 数値文字列(10進,16進文字列であること)を指定バイトサイズ、Listに追加(BigEndian,LittleEndian指定可能)
        ///     (B) "1234FA" 4byte指定 16進 -> 0x00, 0x12, 0x34, 0xFA
        ///     (L) "1234FA" 4byte指定 16進 -> 0xFA, 0x34, 0x12, 0x00
        ///     (B) "65535"  4byte指定 10進 -> 0x00, 0x00, 0xFF, 0xFF
        ///     (L) "65535"  4byte指定 10進 -> 0xFF, 0xFF, 0x00, 0x00
        ///     (B) ""       2byte指定 16進 -> 0x00, 0x00
        ///     (B) "123456" 2byte指定 16進 -> 0x34, 0x56
        /// 例外:
        ///       System.FormatException
        ///       System.OverflowException
        /// </summary>
        /// <param name="value">追加データ(10進の場合、上限16文字(8byte)。それ以上指定した場合はOverflowException発生)</param>
        /// <param name="byteSize">バイトサイズを指定</param>
        /// <param name="fromBase">10:10進数 16:16進数 それ以外:何もしない</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        public void Add(string value, int byteSize, int fromBase, bool isLittleEndian)
        {
            if (fromBase == 16)
            {
                if (value.Length < (byteSize * 2))
                {
                    value = Util.FmtStr(value, byteSize * 2);
                }
                else if (value.Length > (byteSize * 2))
                {
                    value = value.Remove(0, value.Length - (byteSize * 2));
                }

                this.Add(value, isLittleEndian);
            }

            if (fromBase == 10)
            {
                if (!Util.IsNumeric(value)) throw new FormatException(string.Format("{0}は16進文字列ではありません", value));
                if (value.Length > 16) throw new OverflowException(string.Format("{0}は16進文字列ではありません(桁数エラー)", value));
                
                UInt64 v = Convert.ToUInt64(value);
                var ret = new List<byte>();
                for (int i = 0; i < byteSize; i++)
                {
                    ret.Add((byte)((v >> (i * 8)) & 0xFF));
                }
                if (!isLittleEndian)
                {
                    ret.Reverse();
                }
                this.AddRange(ret);
            }
        }

        /// <summary>
        /// 全ての要素を16進文字列に変換する(BigEndian)
        ///     0x12,0x34 -> "1234"
        /// </summary>
        /// <returns>16進文字列(指定バイトサイズx2文字) 4byte->8文字</returns>
        public new string ToString()
        {
            string ret = string.Empty;

            foreach (byte b in this)
            {
                ret += b.ToString("X2");
            }

            return ret;
        }

        /// <summary>
        /// 16進文字列に変換する(BigEndian)
        ///    0x12,0x34 -> "1234"
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <param name="length">変換対象のバイトサイズ</param>
        /// <returns>16進文字列(指定バイトサイズx2文字) 4byte->8文字</returns>
        public string ToString(int startIndex, int length)
        {
            string ret = string.Empty;

            for (int i = 0; (i < length) && (startIndex + i < this.Count); i++)
            {
                ret += this[startIndex + i].ToString("X2");
            }

            return ret;
        }

        /// <summary>
        /// 16進文字列に変換する(BigEndian,LittleEndian指定可能)
        ///     (B) 0x12,0x34,0x56,0x78 -> "12345678"
        ///     (L) 0x12,0x34,0x56,0x78 -> "78563412"
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <param name="length">変換対象のバイトサイズ</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        /// <returns>16進文字列(指定バイトサイズx2文字) 4byte->8文字</returns>
        public string ToString(int startIndex, int length, bool isLittleEndian)
        {
            if (!isLittleEndian) return ToString(startIndex, length);

            string ret = string.Empty;

            if (this.Count < startIndex + length)
            {
                length = this.Count - startIndex;
            }
            for (int i = (length - 1); i >= 0; i--)
            {
                ret += this[startIndex + i].ToString("X2");
            }

            return ret;
        }

        /// <summary>
        /// 数値文字列(10進,16進)に変換する(BigEndian,LittleEndian指定可能)
        ///     (B) 0x12,0x34 "X" -> "1234"
        ///     (L) 0x12,0x34 "X" -> "3412"
        ///     (B) 0x12,0x34 "D" -> "4660"
        ///     (L) 0x12,0x34 "X" -> "13330"
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <param name="length">変換対象のバイトサイズ</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        /// <param name="format">"X":16進に変換 "D":10進に変換 それ以外:空文字列を返す</param>
        /// <returns>数値文字列(10進,16進)</returns>
        public string ToString(int startIndex, int length, bool isLittleEndian, string format)
        {
            if (format.ToUpper() == "X")
            {
                return ToString(startIndex, length, isLittleEndian);
            }
            
            if (format.ToUpper() == "D")
            {
                UInt64 v = Convert.ToUInt64(ToString(startIndex, length, isLittleEndian), 16);

                return v.ToString();
            }

            return "";
        }

        /// <summary>
        /// UInt64型に変換する(BigEndian)
        /// 
        /// 例外:
        ///       System.ArgumentOutOfRangeException
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <returns></returns>
        public UInt64 ToUInt64(int startIndex)
        {
            return ToUInt64(startIndex, false);
        }

        /// <summary>
        /// UInt64型に変換する(BigEndian, LiitleEndian指定可能)
        /// 
        /// 例外:
        ///       System.ArgumentOutOfRangeException
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        /// <returns></returns>
        public UInt64 ToUInt64(int startIndex, bool isLittleEndian)
        {
            if (startIndex + 7 >= this.Count) throw new ArgumentOutOfRangeException();

            UInt64 ret = 0;

            if (isLittleEndian)
            {
                for (int i = 0; i < 8; i++)
                {
                    ret = ret << 8;
                    ret += this[startIndex + (7 - i)];
                }
                return ret;
            }
            else
            {
                for (int i = 0; i < 8; i++)
                {
                    ret = ret << 8;
                    ret += this[startIndex + i];
                }
                return ret;
            }
        }

        /// <summary>
        /// UInt32型に変換する(BigEndian)
        /// 
        /// 例外:
        ///       System.ArgumentOutOfRangeException
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <returns></returns>
        public UInt32 ToUInt32(int startIndex)
        {
            return ToUInt32(startIndex, false);
        }

        /// <summary>
        /// UInt32型に変換する(BigEndian, LiitleEndian指定可能)
        /// 
        /// 例外:
        ///       System.ArgumentOutOfRangeException
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        /// <returns></returns>
        public UInt32 ToUInt32(int startIndex, bool isLittleEndian)
        {
            if (startIndex + 3 >= this.Count) throw new ArgumentOutOfRangeException();

            UInt32 ret = 0;

            if (isLittleEndian)
            {
                for (int i = 0; i < 4; i++)
                {
                    ret = ret << 8;
                    ret += this[startIndex + (3 - i)];
                }
                return ret;
            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    ret = ret << 8;
                    ret += this[startIndex + i];
                }
                return ret;
            }
        }

        /// <summary>
        /// UInt16型に変換する(BigEndian)
        /// 
        /// 例外:
        ///       System.ArgumentOutOfRangeException
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <returns></returns>
        public UInt16 ToUInt16(int startIndex)
        {
            return ToUInt16(startIndex, false);
        }

        /// <summary>
        /// UInt16型に変換する(BigEndian, LiitleEndian指定可能)
        /// 
        /// 例外:
        ///       System.ArgumentOutOfRangeException
        /// </summary>
        /// <param name="startIndex">0から始まる変換対象の開始要素インデックス</param>
        /// <param name="isLittleEndian">true:LittleEndian false:BigEndian</param>
        /// <returns></returns>
        public UInt16 ToUInt16(int startIndex, bool isLittleEndian)
        {
            if (startIndex + 1 >= this.Count) throw new ArgumentOutOfRangeException();

            if (isLittleEndian)
            {
                return (UInt16)(this[startIndex + 1] * 0x100 + this[startIndex]);
            }
            else
            {
                return (UInt16)(this[startIndex] * 0x100 + this[startIndex + 1]);
            }            
        }

        /// <summary>
        /// byte型に変換する
        /// 
        /// 例外:
        ///       System.ArgumentOutOfRangeException
        /// </summary>
        /// <param name="index">0から始まる変換対象の要素インデックス</param>
        /// <returns></returns>
        public byte ToByte(int index)
        {
            if (index >= this.Count) throw new ArgumentOutOfRangeException();

            return this[index];
        }

        /// <summary>
        /// バイナリファイルに書き出す(領域指定可能、上書きモード)
        /// </summary>
        /// <param name="filepath">ファイルパス</param>
        /// <param name="startIndex">0からの開始インデックス</param>
        /// <param name="length">書き出すサイズ</param>
        public void Write(string filepath, int startIndex, int length)
        {
            if (this.Count <= 0) return;
            if (string.IsNullOrEmpty(filepath)) return;

            using (var fs = new System.IO.FileStream(filepath, System.IO.FileMode.Create,
                                                               System.IO.FileAccess.Write))
            {
                var w = this.ToArray();
                fs.Write(w, startIndex, length);
                fs.Close();
            }
        }

        /// <summary>
        /// バイナリファイルに書き出す(全領域、上書きモード)
        /// </summary>
        /// <param name="filepath">ファイルパス</param>
        public void Write(string filepath)
        {
            Write(filepath, 0, this.Count);
        }

        /// <summary>
        /// バイナリファイルを読み込んでリストの最後に追加する
        /// 存在しないファイルパスを指定した場合は何もしない
        /// </summary>
        /// <param name="filepath">ファイルパス</param>
        public void Read(string filepath)
        {
            if (!System.IO.File.Exists(filepath)) return;

            using (var fs = new System.IO.FileStream(filepath, System.IO.FileMode.Open,
                                                               System.IO.FileAccess.Read))
            {
                var r = new byte[fs.Length];
                fs.Read(r, 0, r.Length);
                fs.Close();

                this.Add(r);
            }
        }
    }
}
