﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Compression;

namespace Lecip
{
    /// <summary>
    /// Gzip圧縮・展開クラス
    /// </summary>
    public static class Gzip
    {
        /// <summary>
        /// Gzip圧縮する(単体ファイルのみ、複数ファイルは未対応)
        /// </summary>
        /// <param name="infile">入力ファイル</param>
        /// <param name="outfile">出力ファイル</param>
        public static void Compress(string infile, string outfile)
        {
            using (var infs = new FileStream(infile, FileMode.Open, FileAccess.Read))
            {
                byte[] compData = new byte[infs.Length];
                infs.Read(compData, 0, compData.Length);

                using (var outfs = new FileStream(outfile, FileMode.Create))
                {
                    using (var zips = new GZipStream(outfs, CompressionMode.Compress))
                    {
                        zips.Write(compData, 0, compData.Length);
                        zips.Close();
                    }
                    outfs.Close();                    
                }
                infs.Close();
            }
        }

        /// <summary>
        /// Gzip解凍する(単体ファイルのみ、複数ファイルは未対応)
        /// </summary>
        /// <param name="infile">入力ファイル</param>
        /// <param name="outfile">出力ファイル</param>
        public static void Decompress(string infile, string outfile)
        {
            using (var infs = new FileStream(infile, FileMode.Open, FileAccess.Read))
            {
                byte[] compData = new byte[1024];
                int len = 0;

                using (var outfs = new FileStream(outfile, FileMode.Create))
                {
                    using (var zips = new GZipStream(infs, CompressionMode.Decompress))
                    {
                        while (true)
                        {
                            len = zips.Read(compData, 0, compData.Length);
                            if (len <= 0) break;

                            outfs.Write(compData, 0, len);
                        }
                        zips.Close();
                    }
                    outfs.Close();
                }
                infs.Close();
            }
        }
    }
}
