﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Security.Cryptography;

namespace Lecip
{
    /// <summary>
    /// AES暗号化・復号化をサポートするクラス
    /// </summary>
    public static class Aes
    {
        #region IV
        readonly static byte[] AES_IV = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
        #endregion

        #region ファイル暗号化・復号化
        /// <summary>
        /// ファイルをAES暗号化する(パディングモード=PKCS#7)
        /// </summary>
        /// <param name="infile">入力ファイル</param>
        /// <param name="outfile">出力ファイル</param>
        /// <param name="password">AES鍵</param>
        public static void Encrypt(string infile, string outfile, string password)
        {
            if (!File.Exists(infile)) throw new FileNotFoundException("ファイルが存在しません", infile);

            encryptFile(password, infile, outfile, PaddingMode.PKCS7);
        }

        /// <summary>
        /// ファイルをAES復号化する(パディングモード=PKCS#7)
        /// </summary>
        /// <param name="infile">入力ファイル</param>
        /// <param name="outfile">出力ファイル</param>
        /// <param name="password">AES鍵</param>
        public static void Decrypt(string infile, string outfile, string password)
        {
            if (!File.Exists(infile)) throw new FileNotFoundException("ファイルが存在しません", infile);

            try
            {
                decryptFile(password, infile, outfile, PaddingMode.PKCS7);
            }
            catch (Exception)
            {
                var finfo = new FileInfo(infile);
                if (finfo.Length % 16 == 0)
                {
                    //16Byte区切りの場合、パディング無しの可能性があるので無しに設定して再度復号化をトライする
                    decryptFile(password, infile, outfile, PaddingMode.None);
                }
                else
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// ファイルをAES暗号化する(パディングモード指定可能)
        /// </summary>
        /// <param name="infile">入力ファイル</param>
        /// <param name="outfile">出力ファイル</param>
        /// <param name="password">AES鍵</param>
        /// <param name="mode">AES暗号化時のパディングモード</param>
        public static void Encrypt(string infile, string outfile, string password, PaddingMode mode)
        {
            if (!File.Exists(infile)) throw new FileNotFoundException("ファイルが存在しません", infile);

            encryptFile(password, infile, outfile, mode);
        }

        /// <summary>
        /// ファイルをAES復号化する(パディングモード指定可能)
        /// </summary>
        /// <param name="infile">入力ファイル</param>
        /// <param name="outfile">出力ファイル</param>
        /// <param name="password">AES鍵</param>
        /// <param name="mode">AES復号化時のパディングモード</param>
        public static void Decrypt(string infile, string outfile, string password, PaddingMode mode)
        {
            if (!File.Exists(infile)) throw new FileNotFoundException("ファイルが存在しません", infile);

            decryptFile(password, infile, outfile, mode);
        }
        #endregion

        #region 16進文字列 暗号化・復号化
        /// <summary>
        /// 16進数文字列をAES暗号化する(AES鍵は文字列)
        /// 16進数文字列で返す
        /// </summary>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="inTxt">入力文字列</param>
        /// <returns>暗号化後16進数文字列</returns>
        public static string Encrypt(string aesKey, string inTxt)
        {
            byte[] dst = Encrypt(Util.ToByteArray(aesKey), Util.ToByteArray(inTxt));

            return Util.ToString(dst);
        }

        /// <summary>
        /// 16進数文字列をAES復号化する(AES鍵は文字列)
        /// 16進数文字列で返す
        /// </summary>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="inTxt">入力文字列</param>
        /// <returns>復号化後16進数文字列</returns>
        public static string Decrypt(string aesKey, string inTxt)
        {
            byte[] dst = Decrypt(Util.ToByteArray(aesKey), Util.ToByteArray(inTxt));

            return Util.ToString(dst);
        }
        #endregion

        #region byte配列 暗号化・復号化
        /// <summary>
        /// byte配列をAES暗号化する(AES鍵は文字列)
        /// </summary>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="src">入力byte配列</param>
        /// <returns>暗号化後byte配列</returns>
        public static byte[] Encrypt(string aesKey, byte[] src)
        {
            return Encrypt(Util.ToByteArray(aesKey), src);
        }

        /// <summary>
        /// byte配列をAES復号化する(AES鍵は文字列)
        /// </summary>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="src">入力byte配列</param>
        /// <returns>復号化後byte配列</returns>
        public static byte[] Decrypt(string aesKey, byte[] src)
        {
            return Decrypt(Util.ToByteArray(aesKey), src);
        }

        /// <summary>
        /// byte配列をAES暗号化する(AES鍵はbyte配列)
        /// パディングモードは入力データが128bit単位の場合、None
        ///                               128bit単位で無い場合、PKCS7
        /// ※PKCS7で128bit単位の時、0x10をパディングしてしまうための回避策
        /// </summary>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="src">入力byte配列</param>
        /// <returns>暗号化後byte配列</returns>
        public static byte[] Encrypt(byte[] aesKey, byte[] src)
        {
            PaddingMode mode;

            if (src.Length % 16 == 0)
            {
                mode = PaddingMode.None;
            }
            else
            {
                mode = PaddingMode.PKCS7;
            }

            return encrypt(AES_IV, aesKey, src, mode);
        }

        /// <summary>
        /// byte配列をAES復号化する(AES鍵はbyte配列)
        /// パディングモードは入力データが128bit単位の場合、None
        ///                               128bit単位で無い場合、PKCS7
        /// ※PKCS7で128bit単位の時、0x10がパディングされていないと例外が発生するための回避策
        /// </summary>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="src">入力byte配列</param>
        /// <returns>復号化後byte配列</returns>
        public static byte[] Decrypt(byte[] aesKey, byte[] src)
        {
            PaddingMode mode;

            if (src.Length % 16 == 0)
            {
                mode = PaddingMode.None;
            }
            else
            {
                mode = PaddingMode.PKCS7;
            }

            return decrypt(AES_IV, aesKey, src, mode);
        }

        /// <summary>
        /// byte配列をAES暗号化する(IV指定可能)
        /// (IV, AES鍵はbyte配列)
        /// </summary>
        /// <param name="aesIV">AES IV</param>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="src">入力byte配列</param>
        /// <returns>暗号化後byte配列</returns>
        public static byte[] Encrypt(byte[] aesIV, byte[] aesKey, byte[] src)
        {
            PaddingMode mode;

            if (src.Length % 16 == 0)
            {
                mode = PaddingMode.None;
            }
            else
            {
                mode = PaddingMode.PKCS7;
            }

            return encrypt(aesIV, aesKey, src, mode);
        }

        /// <summary>
        /// byte配列をAES復号化する(IV指定可能)
        /// (IV, AES鍵はbyte配列)
        /// </summary>
        /// <param name="aesIV">AES IV</param>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="src">入力byte配列</param>
        /// <returns>復号化後byte配列</returns>
        public static byte[] Decrypt(byte[] aesIV, byte[] aesKey, byte[] src)
        {
            PaddingMode mode;

            if (src.Length % 16 == 0)
            {
                mode = PaddingMode.None;
            }
            else
            {
                mode = PaddingMode.PKCS7;
            }

            return decrypt(aesIV, aesKey, src, mode);
        }
        #endregion

        #region Privte Method
        /// <summary>
        /// byte配列をAES暗号化する
        /// </summary>
        /// <param name="aesIV">AES IV</param>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="src">入力byte配列</param>
        /// <param name="pMode">パディングモード</param>
        /// <returns>暗号化後byte配列</returns>
        private static byte[] encrypt(byte[] aesIV, byte[] aesKey, byte[] src, PaddingMode pMode)
        {
            var aes = new AesCryptoServiceProvider();

            aes.BlockSize = 128;
            aes.KeySize   = (aesKey.Length >= 32) ? 256 : 128;
            aes.Mode      = CipherMode.CBC;
            aes.Padding   = pMode;
            aes.IV        = aesIV;
            aes.Key       = aesKey;

            byte[] dest;

            using (ICryptoTransform encrypt = aes.CreateEncryptor())
            {
                dest = encrypt.TransformFinalBlock(src, 0, src.Length);
            }

            return dest;
        }

        /// <summary>
        /// byte配列をAES復号化する
        /// </summary>
        /// <param name="aesIV">AES IV</param>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="src">入力byte配列</param>
        /// <param name="pMode">パディングモード</param>
        /// <returns>復号化後byte配列</returns>
        private static byte[] decrypt(byte[] aesIV, byte[] aesKey, byte[] src, PaddingMode pMode)
        {
            var aes = new AesCryptoServiceProvider();

            aes.BlockSize = 128;
            aes.KeySize   = (aesKey.Length >= 32) ? 256 : 128;
            aes.Mode      = CipherMode.CBC;
            aes.Padding   = pMode;
            aes.IV        = aesIV;
            aes.Key       = aesKey;

            byte[] dest;

            using (ICryptoTransform encrypt = aes.CreateDecryptor())
            {
                dest = encrypt.TransformFinalBlock(src, 0, src.Length);
            }

            return dest;
        }

        /// <summary>
        /// ファイルを暗号化する
        /// </summary>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="infile">入力ファイルパス</param>
        /// <param name="outfile">出力ファイルパス</param>
        /// <param name="pMode">パディングモード</param>
        private static void encryptFile(string aesKey, string infile, string outfile, PaddingMode pMode)
        {
            var aes = new AesCryptoServiceProvider();

            aes.BlockSize = 128;
            aes.KeySize   = (aesKey.Length >= 64) ? 256 : 128;
            aes.Mode      = CipherMode.CBC;
            aes.Padding   = pMode;
            aes.IV        = AES_IV;
            aes.Key       = Util.ToByteArray(aesKey);

            if (!File.Exists(infile)) throw new FileNotFoundException("ファイルが存在しません", infile);

            using (var infs = new FileStream(infile, FileMode.Open, FileAccess.Read))
            {
                using (var outfs = new FileStream(outfile, System.IO.FileMode.Create, System.IO.FileAccess.Write))
                {
                    ICryptoTransform encrypt = aes.CreateEncryptor();

                    using (var cs = new CryptoStream(outfs, encrypt, CryptoStreamMode.Write))
                    {
                        byte[] buffer = new byte[1024];

                        int len;
                        while ((len = infs.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            cs.Write(buffer, 0, len);
                        }
                        cs.Close();
                    }
                    encrypt.Dispose();
                    outfs.Close();
                }
                infs.Close();
            }
        }

        /// <summary>
        /// ファイルを復号化する
        /// </summary>
        /// <param name="aesKey">AES鍵</param>
        /// <param name="infile">入力ファイルパス</param>
        /// <param name="outfile">出力ファイルパス</param>
        /// <param name="pMode">パディングモード</param>
        private static void decryptFile(string aesKey, string infile, string outfile, PaddingMode pMode)
        {
            var aes = new AesCryptoServiceProvider();

            aes.BlockSize = 128;
            aes.KeySize   = (aesKey.Length >= 64) ? 256 : 128;
            aes.Mode      = CipherMode.CBC;
            aes.Padding   = pMode;
            aes.IV        = AES_IV;
            aes.Key       = Util.ToByteArray(aesKey);

            if (!File.Exists(infile)) throw new FileNotFoundException("ファイルが存在しません", infile);

            using (var infs = new FileStream(infile, FileMode.Open, FileAccess.Read))
            {
                using (var outfs = new FileStream(outfile, FileMode.Create, FileAccess.Write))
                {
                    ICryptoTransform encrypt = aes.CreateDecryptor();

                    using (var cs = new CryptoStream(outfs, encrypt, CryptoStreamMode.Write))
                    {
                        byte[] buffer = new byte[1024];

                        int len;
                        while ((len = infs.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            cs.Write(buffer, 0, len);
                        }
                        cs.Close();
                    }
                    encrypt.Dispose();
                    outfs.Close();
                }
                infs.Close();
            }
        }
        #endregion
    }
}
