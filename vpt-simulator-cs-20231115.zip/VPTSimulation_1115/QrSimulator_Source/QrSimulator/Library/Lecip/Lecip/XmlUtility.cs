﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Lecip
{
    /// <summary>
    /// XmlUtilityクラス
    /// </summary>
    public static class XmlUtility
    {
        /// <summary>
        /// 対象クラスをxmlシリアライズし、xmlファイルに保存する
        /// 例) Lecip.XmlUtility.Serialize&lt;Target&gt;(this, filePath);
        /// </summary>
        /// <typeparam name="T">クラス</typeparam>
        /// <param name="obj">保存する対象データ</param>
        /// <param name="filePath">保存先ファイルパス</param>
        public static void Serialize<T>(T obj, string filePath)
        {
            using (var sw = new StreamWriter(filePath, false, new UTF8Encoding(false)))
                new System.Xml.Serialization.XmlSerializer(typeof(T)).Serialize(sw, obj);
        }

        /// <summary>
        /// xmlファイルをデシリアライズし、クラスを返す
        /// 例) return Lecip.XmlUtility.Deserialize&lt;Target&gt;(filePath);
        /// </summary>
        /// <typeparam name="T">クラス</typeparam>
        /// <param name="filePath">保存元ファイルパス</param>
        /// <returns>デシリアライズされたクラスインスタンス</returns>
        public static T Deserialize<T>(string filePath)
        {
            var returnValue = default(T);
            using (var sr = new StreamReader(filePath, new UTF8Encoding(false)))
                returnValue = (T)new System.Xml.Serialization.XmlSerializer(typeof(T)).Deserialize(sr);
            return returnValue;
        }
    }
}
