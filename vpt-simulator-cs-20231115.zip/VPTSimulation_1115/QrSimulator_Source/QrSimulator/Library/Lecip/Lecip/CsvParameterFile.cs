﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip
{
    /// <summary>
    /// CSV設定ファイルをRead/Writeするクラス
    /// Category設定後、Addで設定追加 / Get...系で設定取得
    /// ReadFileで設定ファイル読み込み
    /// WriteFileで設定ファイル上書き
    /// </summary>
    public class CsvParameterFile
    {
        #region Property
        /// <summary>カテゴリ名</summary>
        public string Category { get; set; }
        #endregion

        #region Field
        private Dictionary<bool, string> btos;
        private Dictionary<string, bool> stob;
        private Encoding SJIS;
        private StringBuilder sb;
        private Dictionary<string, string> dic;
        private string lastCategory = "";
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public CsvParameterFile()
	    {
            this.btos = new Dictionary<bool, string>() { { false, "0" }, { true, "1" } };
            this.stob = new Dictionary<string, bool>() { { "0", false }, { "1", true } };
            this.SJIS = Encoding.GetEncoding("shift_jis");
            this.sb = new StringBuilder();

            this.Category = string.Empty;
        }
        #endregion

        #region Public Method
        /// <summary>
        /// bool値を追加
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void Add(string key, bool value)
        {
            this.Add(key, this.btos[value]);
        }

        /// <summary>
        /// byte値を追加
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void Add(string key, byte value)
        {
            this.Add(key, value.ToString("X2"));
        }

        /// <summary>
        /// objectを追加
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void Add(string key, object value)
        {
            if (value == null) value = ""; 

            this.Add(key, value.ToString());
        }

        /// <summary>
        /// 文字列を追加
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void Add(string key, string value)
        {
            if (this.Category != this.lastCategory)
            {
                if (this.lastCategory != "") this.sb.AppendLine("");    //カテゴリが変化したら空行
                this.lastCategory = this.Category;

                var cate = Category;
                this.RegulateText(ref cate);
                this.sb.AppendLine("[" + cate + "]");
            }
            
            this.RegulateText(ref key);
            this.RegulateText(ref value);

            this.sb.AppendLine(key + "," + value);
        }
        
        /// <summary>
        /// ファイルに保存
        /// </summary>
        /// <param name="path"></param>
        public void SaveFile(string path)
        {
            File.WriteAllText(path, this.sb.ToString(), this.SJIS);

            this.sb = new StringBuilder();
        }
        
        /// <summary>
        /// ファイルから読み出す
        /// </summary>
        /// <param name="path"></param>
        public void ReadFile(string path)
        {
            var parser = new CSVParser();
            var csv = parser.ParseFile(path);

            dic = new Dictionary<string, string>();

            var cate = "";
            foreach (var csvrow in csv)
            {
                var cell = csvrow[0];
                
                if (string.IsNullOrEmpty(cell)) continue; //データ無し

                if (cell.StartsWith("["))
                {
                    cate = cell.Substring(1, cell.Length - 2); //カテゴリー
                }
                else
                {
                    //Key,Value型
                    if (csvrow.Count < 2) continue; //Value無し

                    var key = csvrow[0];
                    string value = csvrow[1];

                    for (int i = 2; i < csvrow.Count; i++)
                    {
                        if (string.IsNullOrEmpty(csvrow[i])) break;

                        value += ",";
                        value += csvrow[i];
                    }

                    if (cate != "") key = cate + "_" + key;

                    if (!this.dic.Keys.Contains(key))
                    {
                        this.dic.Add(key, value);
                    }
                    else
                    {
                        Util.MessageErr(Path.GetFileName(path) + "\r\n設定値が重複しています[" + key + "]", "CSVファイル読込み");
                    }
                }
            }
        }
        
        /// <summary>
        /// bool値を取得
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool GetBool(string key)
        {
            var value = this.GetString(key);

            if (this.stob.ContainsKey(value) == false) return false;

            return this.stob[value];
        }
        
        /// <summary>
        /// byte値を取得
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public byte GetByte(string key)
        {
            var value = this.GetString(key); if (value == "") return 0;

            return Convert.ToByte(value, 16);
        }
        
        /// <summary>
        /// 文字列値を取得
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetString(string key)
        {
            if (this.Category != "") key = this.Category + "_" + key;

            if (this.dic.ContainsKey(key) == false) return string.Empty;

            return this.dic[key];
        }
        #endregion

        #region Private Method
        private void RegulateText(ref string s)
        {
            var quote = false;
            if (s.Contains("\"") == true) { s = s.Replace("\"", "\"\""); quote = true; }
            //if (s.Contains(",") == true) quote = true;
            if (quote == true) s = "\"" + s + "\"";
        }
        #endregion
    }
}
