﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lecip.IO
{
    /// <summary>
    /// 伊予鉄精算機通信を行うコントロールクラス
    /// SerialIOSeisanki()使用
    /// </summary>
    public class SerialIOSeisankiControl : SerialIOControlBase
    {
        #region Property
        /// <summary>送信データのI/F種別</summary>
        public byte TxIFType { get { return ((SerialIOSeisanki)this.Serial).TxIFType; } }

        /// <summary>受信データのI/F種別</summary>
        public byte RxIFType { get { return ((SerialIOSeisanki)this.Serial).RxIFType; } }

        /// <summary>受信データのデータ部</summary>
        public byte[] RxData { get { return ((SerialIOSeisanki)this.Serial).RxData; } }

        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return ((SerialIOSeisanki)this.Serial).DebugList; } }

        /// <summary>デバッグモードを設定するプロパティ</summary>
        public int DebugMode { set { ((SerialIOSeisanki)this.Serial).DebugMode = value; } }
        #endregion

        #region Constructor
        /// <summary>
        /// SerialIOSeisankiControlクラスの新しいインスタンスを初期化します
        /// </summary>
        /// <param name="multiline"></param>
        public SerialIOSeisankiControl(TextBoxLog.MulitlineMode multiline) : base(new SerialIOSeisanki(), multiline)
        {

        }
        #endregion

        #region Public Method
        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="ifType">IF種別</param>
        /// <param name="data">送信コマンドデータ部</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(byte ifType, byte[] data, int receiveTimeout = 0)
        {
            ((SerialIOSeisanki)this.Serial).Send(ifType, data, receiveTimeout);
        }
        #endregion
    }
}
