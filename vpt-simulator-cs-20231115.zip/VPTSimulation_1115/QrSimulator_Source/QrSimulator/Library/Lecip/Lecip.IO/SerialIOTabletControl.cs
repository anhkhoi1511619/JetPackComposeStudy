﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lecip.IO
{
    /// <summary>
    /// シリアル通信を行うコントロールクラス
    /// SerialIOTablet()使用
    /// </summary>
    public class SerialIOTabletControl : SerialIOControlBase
    {
        #region Property
        /// <summary>送信コマンド</summary>
        public byte TxCommand { get { return ((SerialIOTablet)this.Serial).TxCommand; } }

        /// <summary>受信コマンド</summary>
        public byte RxCommand { get { return ((SerialIOTablet)this.Serial).RxCommand; } }

        /// <summary>受信固有ID(受信時にセット)</summary>
        public List<byte> RxUniqueID { get { return ((SerialIOTablet)this.Serial).RxUniqueID; } }

        /// <summary>受信データ部</summary>
        public List<byte> RxData { get { return ((SerialIOTablet)this.Serial).RxData; } }

        /// <summary>送信通番更新フラグ true:送信通番更新された false:送信通番同一のまま</summary>
        public bool SeqUpdated { get { return ((SerialIOTablet)this.Serial).SeqUpdated; } }

        /// <summary>
        /// サイズ項目のエンディアン指定
        /// Lecip.Endian.Little or Lecip.Endian.Bigで指定
        /// true:リトルエンディアン(デフォルト) false:ビッグエンディアン
        /// </summary>
        public bool SzEndiain
        {
            get { return ((SerialIOTablet)this.Serial).SzEndiain; }
            set { ((SerialIOTablet)this.Serial).SzEndiain = value; }
        }

        /// <summary>デバッグモード I/F種別 ( 0x00以外:デバッグモード。コマンド送信時にこちらの値に置き換える)</summary>
        public byte DebugCommand
        {
            get { return ((SerialIOTablet)this.Serial).DebugCommand; }
            set { ((SerialIOTablet)this.Serial).DebugCommand = value; }
        }

        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return ((SerialIOTablet)this.Serial).DebugList; } }

        /// <summary>デバッグモードを設定するプロパティ</summary>
        public int DebugMode { set { ((SerialIOTablet)this.Serial).DebugMode = value; } }
        #endregion

        #region Constructor
        /// <summary>
        /// SerialIOTabletControlクラスの新しいインスタンスを初期化します
        /// </summary>
        /// <param name="multiline">通信表示を複数行モードで行うか単行で行うかの設定</param>
        public SerialIOTabletControl(TextBoxLog.MulitlineMode multiline) : base(new SerialIOTablet(), multiline)
        {

        }
        #endregion

        #region Public Method
        /// <summary>
        /// コマンド送信
        /// </summary>
        /// <param name="txCommand">送信コマンド</param>
        /// <param name="uniqueID">送信固有ID</param>
        /// <param name="data">データ</param>
        /// <param name="useReceiveTimeout">受信タイムアウト処理の実施可否 true:する false:しない</param>
        public void Send(byte txCommand, List<byte> uniqueID, List<byte> data, bool useReceiveTimeout = true)
        {
            ((SerialIOTablet)this.Serial).Send(txCommand, uniqueID, data, useReceiveTimeout);
        }
        #endregion
    }
}
