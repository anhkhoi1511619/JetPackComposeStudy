﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Lecip.IO
{
    /// <summary>
    /// シリアル通信クラス(バイナリ/アスキー)(フォーマットなし)
    /// </summary>
    public class SerialIOBasic : SerialIO
    {
        #region Field
        /// <summary>通信モード</summary>
        public enum Connection
        {
            /// <summary>バイナリ通信モード</summary>
            Binary,
            /// <summary>アスキー通信モード</summary>
            Ascii,
        }
        #endregion

        #region Property
        /// <summary>通信モード</summary>
        public Connection ConnectionMode { get; set; }
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SerialIOBasic()
        {
            this.Encoding = Encoding.GetEncoding("Shift_JIS");
            this.ConnectionMode = Connection.Binary;
        }
        #endregion
        
        #region Override
        /// <summary>
        /// シリアル通信受信イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void OnDataReceived(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            string errorMessage = string.Empty;

            if (!this.IsOpen) return;
            if (this.BytesToRead <= 0) return;

            sw.Start();
            try
            {
                while (true)
                {
                    if (sw.ElapsedMilliseconds > this.Timeout)
                    {
                        errorMessage = "タイムアウトしました";
                        SetError(MsgType.RxMsg, errorMessage);
                        return;
                    }
                    if (!this.IsOpen)
                    {
                        errorMessage = "ポートが閉じられました";
                        SetError(MsgType.RxMsg, errorMessage);
                        return;
                    }

                    int bytesToRead = this.BytesToRead;
                    if (bytesToRead <= 0) continue;

                    if (this.ConnectionMode == Connection.Binary)
                    {
                        byte[] buff = null;
                        if (this.RecvBinary(ref buff, bytesToRead, this.Timeout) > 0)
                        {
                            this.RxRawData = buff;
                            SetReceive();
                            break;
                        }
                    }
                    else
                    {
                        byte[] buff = null;
                        if (this.RecvBinary(ref buff, bytesToRead, this.Timeout) > 0)
                        {
                            this.RxRawData = buff;
                            var enc = Encoding.GetEncoding("Shift_JIS");
                            SetReceiveAscii(enc.GetString(this.RxRawData));
                            break;
                        }
                    }
                }
            }
            catch (IOException ioex)
            {
                SetError(MsgType.RxMsg, ioex.Message);
            }
        }
        #endregion
    }
}
