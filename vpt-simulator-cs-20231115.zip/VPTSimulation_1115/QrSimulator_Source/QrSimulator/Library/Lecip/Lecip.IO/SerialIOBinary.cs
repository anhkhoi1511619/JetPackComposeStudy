﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Lecip.IO
{
    /// <summary>
    /// <para>上位機器通信シリアル通信クラス(バイナリフォーマット)</para>
    /// <para>+---------+------+-------------+----------+----------+--------+------+-----+-----+---------+</para>
    /// <para>|STX(0x02)|IF種別|サイズ(2Byte)|サイズサム|(機器番号)|送信通番|データ|サム1|サム2|ETX(0x03)|</para>
    /// <para>+---------+------+-------------+----------+----------+--------+------+-----+-----+---------+</para>
    /// </summary>
    public class SerialIOBinary : SerialIO
    {
        #region Field
        private const byte   Stx = 0x02;
        private const byte   Etx = 0x03;
        private readonly int StxSize = 1;
        private          int HeaderSize = 5;
        private readonly int FooterSize = 3;

        private enum rcvSts
        {
            Stx,
            Header,
            Data,
            Footer,
            Success,
            Fail,
        }

        /// <summary>
        /// 送信通番
        /// </summary>
        private byte sq;

        /// <summary>
        /// 機器番号を使うか使わないかの設定(地域連携対応)
        /// true:使う false:使わない
        /// </summary>
        private bool useKikiNo;
        #endregion

        #region Property
        /// <summary>送信データのI/F種別</summary>
        public byte TxIFType { get; private set; }
        /// <summary>受信データのI/F種別</summary>
        public byte RxIFType { get; set; }
        /// <summary>受信データのデータ部</summary>
        public List<byte> RxData { get; set; }

        /// <summary>
        /// サイズ項目のエンディアン指定
        /// Lecip.Endian.Little or Lecip.Endian.Bigで指定
        /// true:リトルエンディアン(デフォルト) false:ビッグエンディアン
        /// </summary>
        public bool SzEndiain { get; set; }

        /// <summary>
        /// 機器番号を使うか使わないかの設定(地域連携のみ使う(予約項目)
        /// true:使う false:使わない
        /// </summary>
        public bool UseKikiNo
        {
            get
            {
                return this.useKikiNo;
            }
            set
            {
                this.useKikiNo = value;
                if (!this.useKikiNo)
                    HeaderSize = 5;
                else
                    HeaderSize = 6;
            }
        }
        /// <summary>機器番号(地域連携対応) デフォルト00H</summary>
        public byte KikiNo { get; set; }

        #region Debug Property
        /// <summary>デバッグモード I/F種別 ( 0x00以外:デバッグモード。コマンド送信時にこちらの値に置き換える)</summary>
        public byte DebugIFType { get; set; }
        /// <summary>デバッグモード サイズ算出 0:通常モード 1:デバッグモード(正しいサイズ+1にする) 2:デバッグモード(正しいサイズ-1にする)</summary>
        public int DebugLen { get; set; }
        /// <summary>デバッグモード サイズサム算出 false:通常モード true:デバッグモード(正しいサム+1にする)</summary>
        public bool DebugLenSum { get; set; }
        /// <summary>デバッグモード サム算出 false:通常モード true:デバッグモード(正しいサム+1にする)</summary>
        public bool DebugSum { get; set; }
        /// <summary>デバッグモード 送信通番固定 false:通常モード true:デバッグモード(送信通番を固定にする)</summary>
        public bool DebugFixSeq { get; set; }

        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return new string[] { "通常", "LEN異常", "LENサム異常", "チェックサム異常", "送信通番固定" }; } }

        /// <summary>
        /// デバッグモードを設定するプロパティ
        /// 0:通常(デバッグモード解除)
        /// 1:LEN異常
        /// 2:チェックサム異常
        /// </summary>
        public int DebugMode
        {
            set
            {
                this.DebugLen = 0;
                this.DebugLenSum = false;
                this.DebugSum = false;
                this.DebugFixSeq = false;

                switch (value)
                {
                    case 0: break; //通常
                    case 1: this.DebugLen = 1; break; //データ長異常
                    case 2: this.DebugLenSum = true; break; //データ長サム異常
                    case 3: this.DebugSum = true; break; //サム異常
                    case 4: this.DebugFixSeq = true; break; //送信通番固定
                }
            }
        }
        #endregion
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SerialIOBinary()
        {
            this.sq = 0;
            this.DebugIFType = 0x00;
            this.DebugLen = 0;
            this.DebugLenSum = false;
            this.DebugSum = false;

            this.RxIFType = 0x00;
            this.RxData = new List<byte>();
            this.SzEndiain = Endian.Little;

            this.UseKikiNo = false;
            this.KikiNo = 0x00;
        }
        #endregion

        #region Public Method
        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="ifType">IF種別</param>
        /// <param name="data">データ</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(byte ifType, List<byte> data, int receiveTimeout = 0)
        {
            List<byte> sendData = new List<byte>();

            //IF種別セット
            if (this.DebugIFType != 0x00) ifType = this.DebugIFType;
            this.TxIFType = ifType;

            sendData.Add(ifType);
            //サイズセット
            UInt16 size = (UInt16)data.Count;
            if (this.DebugLen == 1) size++;
            if (this.DebugLen == 2) size--;
            if (this.SzEndiain == Lecip.Endian.Little)
            {
                sendData.Add((byte)(size & 0xFF));
                sendData.Add((byte)(size >> 8 & 0xFF));
            }
            else
            {
                sendData.Add((byte)(size >> 8 & 0xFF));
                sendData.Add((byte)(size & 0xFF));
            }
            //サイズサムセット
            byte lensum = calcSzSum(sendData);
            if (this.DebugLenSum) lensum++;
            sendData.Add(lensum);
            //機器番号セット
            if (this.UseKikiNo) sendData.Add(this.KikiNo);
            //送信通番セット
            sendData.Add(this.sq);
            //データセット
            sendData.AddRange(data);
            //チェックサム
            byte sum1 = 0, sum2 = 0;
            calcCheckSum(sendData, ref sum1, ref sum2);
            if (this.DebugSum) sum1++;
            sendData.Add(sum1);
            sendData.Add(sum2);

            //STX ETX
            sendData.Insert(0, Stx);
            sendData.Add(Etx);

            // 応答が必要なコマンドの場合、タイムアウト処理を開始(recevieTimeoutが0未満の場合、タイムアウト処理を行わない)
            if (receiveTimeout >= 0) base.StartReceiveTimeout();

            //送信
            base.Send(sendData);
        }

        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="ifType">IF種別</param>
        /// <param name="data">データ</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(byte ifType, byte[] data, int receiveTimeout = 0)
        {
            int index = 0;
            int sendSize = ((this.UseKikiNo) ? 10 : 9) + data.Length;
            byte[] sendData = new byte[sendSize];

            //STX
            sendData[index++] = Stx;

            //IF種別セット
            if (this.DebugIFType != 0x00) ifType = this.DebugIFType;
            this.TxIFType = ifType;
            sendData[index++] = ifType;

            //サイズセット
            UInt16 size = (UInt16)data.Length;
            if (this.DebugLen == 1) size++;
            if (this.DebugLen == 2) size--;
            if (this.SzEndiain == Endian.Little)
            {
                sendData[index++] = ((byte)(size & 0xFF));
                sendData[index++] = ((byte)(size >> 8 & 0xFF));
            }
            else
            {
                sendData[index++] = ((byte)(size >> 8 & 0xFF));
                sendData[index++] = ((byte)(size & 0xFF));
            }
            //サイズサムセット
            byte lensum = calcSzSum(sendData);
            if (this.DebugLenSum) lensum++;
            sendData[index++] = lensum;
            //機器番号セット
            if (this.UseKikiNo) sendData[index++] = this.KikiNo;
            //送信通番セット
            sendData[index++] = this.sq;
            //データセット
            Array.Copy(data, 0, sendData, index, data.Length);
            index += data.Length;
            //チェックサム
            byte sum1 = 0, sum2 = 0;
            calcCheckSum(sendData, 1, index - 1, ref sum1, ref sum2);
            if (this.DebugSum) sum1++;
            sendData[index++] = sum1;
            sendData[index++] = sum2;

            //ETX
            sendData[index++] = Etx;

            // 応答が必要なコマンドの場合、タイムアウト処理を開始(recevieTimeoutが0未満の場合、タイムアウト処理を行わない)
            if (receiveTimeout >= 0) base.StartReceiveTimeout();

            //送信
            base.Send(sendData);
        }
        #endregion

        #region Override
        /// <summary>
        /// シリアル通信受信イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void OnDataReceived(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            List<byte> recv = new List<byte>();
            rcvSts sts = rcvSts.Stx; //受信ステータス
            int reqSize = 0; //受信要求サイズ
            int datSize = 0; //データ部サイズ
            string errorMessage = string.Empty;

            if (!this.IsOpen) return;
            if (this.BytesToRead <= 0) return;

            //タイムアウト処理を停止
            base.StopReceiveTimeout();

            sw.Start();
            try
            {
                while (true)
                {
                    if (sw.ElapsedMilliseconds > this.Timeout)
                    {
                        errorMessage = "タイムアウトしました";
                        sts = rcvSts.Fail;
                        break;
                    }
                    if (!this.IsOpen)
                    {
                        errorMessage = "ポートが閉じられました";
                        sts = rcvSts.Fail;
                        break;
                    }

                    //受信データ数セット
                    switch (sts)
                    {
                        case rcvSts.Stx: reqSize = StxSize; break; //Stx      1Byte
                        case rcvSts.Header: reqSize = HeaderSize; break; //ヘッダ部 5 or 6Byte (IF～SQ)
                        case rcvSts.Data: reqSize = datSize; break; //データ部 可変(ヘッダデータから算出)
                        case rcvSts.Footer: reqSize = FooterSize; break; //フッタ部 3Byte (SUM1～ETX)
                    }
                    int bytesToRead = this.BytesToRead;
                    if (bytesToRead < reqSize) continue;

                    var buff = new List<byte>();
                    if (this.RecvBinary(buff, reqSize, this.Timeout))
                    {
                        switch (sts)
                        {
                            case rcvSts.Stx:
                                //STX
                                if (buff[0] == Stx)
                                {
                                    sts = rcvSts.Header;
                                }
                                break;

                            case rcvSts.Header:
                                //IF種別
                                this.RxIFType = buff[0];

                                //データ部のサイズを算出
                                if (this.SzEndiain == Endian.Little)
                                {
                                    datSize = buff[1] + buff[2] * 0x100;
                                }
                                else
                                {
                                    datSize = buff[1] * 0x100 + buff[2];
                                }
                                //Szsum
                                if (buff[3] != this.calcSzSum(buff.GetRange(0, 3)))
                                {
                                    errorMessage = "SZSUMエラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //機器番号は何もしない
                                //送信通番更新
                                if (!this.DebugFixSeq) this.sq = buff[HeaderSize - 1];
                                sts = rcvSts.Data;
                                break;

                            case rcvSts.Data:
                                //データ部
                                this.RxData = buff;
                                sts = rcvSts.Footer;
                                break;

                            case rcvSts.Footer:
                                //チェックサム
                                byte sum1 = 0, sum2 = 0;
                                this.calcCheckSum(recv, 1, recv.Count - 1, ref sum1, ref sum2);
                                if (buff[0] != sum1 || buff[1] != sum2)
                                {
                                    errorMessage = "チェックサムエラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //ETX
                                if (buff[2] != Etx)
                                {
                                    errorMessage = "ETX受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //受信OKのためここで送信通番をインクリメントする
                                if (!this.DebugFixSeq) this.sq++;

                                sts = rcvSts.Success;
                                break;
                        }
                    }

                    if (sts != rcvSts.Stx) recv.AddRange(buff);
                    if (sts == rcvSts.Success || sts == rcvSts.Fail)
                    {
                        break;
                    }
                }

                
                if (sts == rcvSts.Fail)
                {
                    SetError(MsgType.RxMsg, errorMessage);
                }
                else if (sts == rcvSts.Success)
                {
                    this.RxRawData = recv.ToArray();
                    SetReceive();
                }
            }
            catch (IOException ioex)
            {
                SetError(MsgType.RxMsg, ioex.Message);
            }
        }
        #endregion

        #region Private Method
        /// <summary>
        /// SZSUMを計算する
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private byte calcSzSum(List<byte> data)
        {
            return (byte)((0x100 - data[0] - data[1] - data[2]) & 0xFF);
        }

        private byte calcSzSum(byte[] data)
        {
            return (byte)((0x100 - data[1] - data[2] - data[3]) & 0xFF);
        }

        /// <summary>
        /// チェックサムを計算してSUM1,SUM2を求める
        /// </summary>
        /// <param name="data"></param>
        /// <param name="sum1"></param>
        /// <param name="sum2"></param>
        private void calcCheckSum(List<byte> data, ref byte sum1, ref byte sum2)
        {
            int sum = 0;
            foreach (byte d in data)
            {
                sum += d;
            }

            sum1 = Convert.ToByte(sum & 0xFF);
            sum2 = Convert.ToByte((~sum1) & 0xFF);
        }

        /// <summary>
        /// チェックサムを計算してSUM1,SUM2を求める
        /// </summary>
        /// <param name="data"></param>
        /// <param name="start"></param>
        /// <param name="length"></param>
        /// <param name="sum1"></param>
        /// <param name="sum2"></param>
        private void calcCheckSum(List<byte> data, int start, int length, ref byte sum1, ref byte sum2)
        {
            int sum = 0;
            for (int i = 0; i < length; i++)
            {
                sum += data[start + i];
            }

            sum1 = Convert.ToByte(sum & 0xFF);
            sum2 = Convert.ToByte((~sum1) & 0xFF);
        }
        /// <summary>
        /// チェックサムを計算してSUM1,SUM2を求める
        /// </summary>
        /// <param name="data"></param>
        /// <param name="start"></param>
        /// <param name="length"></param>
        /// <param name="sum1"></param>
        /// <param name="sum2"></param>
        private void calcCheckSum(byte[] data, int start, int length, ref byte sum1, ref byte sum2)
        {
            int sum = 0;
            for (int i = 0; i < length; i++)
            {
                sum += data[start + i];
            }

            sum1 = Convert.ToByte(sum & 0xFF);
            sum2 = Convert.ToByte((~sum1) & 0xFF);
        }
        #endregion
    }
}
