﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.IO
{
    /// <summary> 通信ログ画面表示コントロール </summary>
    public class TextBoxLog : Control
    {
        #region enum
        /// <summary> 通信ログ行表示モード </summary>
        public enum MulitlineMode
        {
            /// <summary>複数行表示モード(複数行表示させたい時はこちら。ただし遅い) </summary>
            Multi,
            /// <summary>単行表示モード(通常はこちら。早い)</summary>
            Single,
        }
        #endregion

        #region Property
        /// <summary> 通信ログ画面表示ONOFFフラグ </summary>
        public new bool Visible
        {
            get { return this.visible; }

            set
            {
                this.visible = value;
                if (!value)
                {
                    ClearLog();
                }
            }
        }
        #endregion

        #region Field
        /// <summary> TXRX表示用リッチテキストボックス </summary>
        private RichTextBox rtx;
        /// <summary> リッチテキストボックス表示行数 </summary>
        private int lines;
        /// <summary> TX表示用テキストボックス </summary>
        private TextBox tx;
        /// <summary> RX表示用テキストボックス </summary>
        private TextBox rx;
        /// <summary> 通信ログ画面表示ONOFFフラグ </summary>
        private bool visible;
        #endregion

        #region Constructor
        /// <summary> コンストラクタ </summary>
        public TextBoxLog(MulitlineMode multiline = MulitlineMode.Single)
        {
            //コントロールの初期サイズを50x50にする
            this.Size = new System.Drawing.Size(50, 50);

            if (multiline == MulitlineMode.Multi)
            {
                //通信ログ表示用のTextBoxを生成(複数行)
                this.rtx = new RichTextBox();
                this.rtx.Multiline = true;
                this.rtx.ScrollBars = RichTextBoxScrollBars.Vertical;
                this.rtx.WordWrap = false;
                this.rtx.Dock = DockStyle.Fill;
                this.rtx.Visible = true;
                this.rtx.ReadOnly = true;
                this.rtx.HideSelection = false;
                this.rtx.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
                this.rtx.Enabled = true;
                this.Controls.Add(rtx);
                this.tx = null;
                this.rx = null;
                this.lines = 0;
            }
            else
            {
                //通信ログ表示用のTextBoxを生成(単行)
                this.rtx = null;
                this.lines = 0;
                this.tx = new TextBox();
                this.tx.BorderStyle = BorderStyle.None;
                this.tx.WordWrap = false;
                this.tx.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                this.tx.ReadOnly = true;
                this.tx.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
                this.tx.Margin = new Padding(0);
                this.tx.Location = new System.Drawing.Point(3, 3);
                this.tx.Width = this.Width - 6;

                this.rx = new TextBox();
                this.rx.BorderStyle = BorderStyle.None;
                this.rx.WordWrap = false;
                this.rx.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                this.rx.ReadOnly = true;
                this.rx.Font = new System.Drawing.Font("ＭＳ ゴシック", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
                this.rx.Margin = new Padding(0);
                this.rx.Location = new System.Drawing.Point(3, this.tx.Height + 3);
                this.rx.Width = this.Width - 6;
                this.Controls.Add(tx);
                this.Controls.Add(rx);
            }

            this.visible = true;
        }
        #endregion

        #region Public Method
        /// <summary>通信ログ表示をクリアする</summary>
        public void ClearLog()
        {
            if (this.InvokeRequired)
                this.Invoke(new Action(clearLog));
            else
                clearLog();
        }

        /// <summary>通信ログ更新する</summary>
        public void UpdateLog(MsgType type, string log)
        {
            if (this.InvokeRequired)
                this.Invoke(new Action<MsgType, string>(updateLog), type, log);
            else
                updateLog(type, log);
        }
        #endregion

        #region Private Method
        /// <summary>通信ログ表示をクリアする</summary>
        private void clearLog()
        {
            this.rtx?.Clear();
            this.tx?.Clear();
            this.rx?.Clear();
        }
        /// <summary>
        /// 通信ログを更新する
        /// </summary>
        /// <param name="type">ログタイプ</param>
        /// <param name="log">ログ</param>
        private void updateLog(MsgType type, string log)
        {
            if (!this.visible) return;

            if (this.rtx != null)
            {
                if (this.lines > 10)
                {
                    this.rtx.Clear();
                    this.lines = 0;
                }

                this.rtx.AppendText($"{log}\r\n");
                this.lines++;
            }
            else
            {
                switch (type)
                {
                    case MsgType.Tx:
                    case MsgType.TxMsg:
                        this.tx.Text = log;
                        break;
                    case MsgType.Rx:
                    case MsgType.RxMsg:
                        this.rx.Text = log;
                        break;
                }
            }
        }
        #endregion
    }
}
