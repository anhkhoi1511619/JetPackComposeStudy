﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Lecip.IO
{
    /// <summary>
    /// <para>上位機器通信シリアル通信クラス(アスキーフォーマット)</para>
    /// <para>+------------+--------+--------+------+------+---------+</para>
    /// <para>| STX(0x2A)  |機器番号|コマンド|データ|サム  |ETX(0x0D)|</para>
    /// <para>|    "*"     |  ○○  |  ○○  | ○○ | ○○ |    ○   |</para>
    /// <para>+------------+--------+--------+------+------+---------+</para>
    /// </summary>
    public class SerialIOAscii : SerialIO
    {
        #region Field
        private const char Stx = (char)0x2A;
        private const char Etx = (char)0x0D;
        private const int StxSize = 1; //Stx
        private const int HeaderSize = 4; //機器番号 ～ コマンドまでのサイズ
        private const int FooterSize = 1; //ETXのサイズ

        private enum rcvSts
        {
            Stx,
            Header,
            Data,
            Success,
            Fail,
        }
        #endregion

        #region Property
        /// <summary>サム計算モード</summary>
        public enum Sum
        {
            /// <summary>単純加算</summary>
            Normal,
            /// <summary>インテル方式(合計して0x00になる)</summary>
            Intel,
        }

        /// <summary>機器番号</summary>
        public string KikiNo { get; set; }
        /// <summary>送信データのコマンド部</summary>
        public string TxCommand { get; private set; }
        /// <summary>受信データのコマンド部</summary>
        public string RxCommand { get; set; }
        /// <summary>受信データのデータ部(コマンドは除く)</summary>
        public string RxData { get; set; }
        /// <summary>サム計算のモード</summary>
        public Sum SumMode { get; set; }

        #region Debug Property
        /// <summary>デバッグモード コマンド ( string.Empty以外:デバッグモード。コマンド送信時にこちらの値に置き換える)</summary>
        public string DebugCommand { get; set; }
        /// <summary>デバッグモード サム算出 true:通常モード false:デバッグモード(正しいサム+1にする)</summary>
        public bool DebugSum { get; set; }
        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return new string[] { "通常", "チェックサム異常" }; } }

        /// <summary>
        /// デバッグモードを設定するプロパティ
        /// 0:通常(デバッグモード解除)
        /// 1:チェックサム異常
        /// </summary>
        public int DebugMode
        {
            set
            {
                this.DebugSum = false;

                switch (value)
                {
                    case 0: break; //通常
                    case 1: this.DebugSum = true; break; //サム異常
                }
            }
        }
        #endregion
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SerialIOAscii()
        {
            this.DebugCommand = string.Empty;
            this.DebugSum = false;

            this.RxCommand = string.Empty;
            this.RxData = string.Empty;
            this.SumMode = Sum.Normal;
        }
        #endregion

        #region Public Method
        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <param name="data">データ</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(string command, string data, int receiveTimeout = 0)
        {
            string sendData;
            if (this.DebugCommand != string.Empty) command = this.DebugCommand;
            this.TxCommand = command;

            sendData = this.KikiNo + command + data; //機器番号 + コマンド + データ部
            if (!this.DebugSum)
            {
                sendData += calcCheckSum(sendData);      //サム計算
            }
            else
            {
                sendData += calcCheckSum(sendData + "01"); //サム計算(デバッグモード)
            }
            sendData = Stx + sendData + Etx; //Stx Etx

            //応答が必要なコマンドの場合、タイムアウト処理を開始(recevieTimeoutが0未満の場合、タイムアウト処理を行わない)
            if (receiveTimeout >= 0) base.StartReceiveTimeout();

            try
            {
                this.Send(sendData);
            }
            catch (IOException ex)
            {
                SetError(MsgType.TxMsg, ex.Message);
            }
        }
        #endregion

        #region Override
        /// <summary>
        /// シリアル通信受信イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void OnDataReceived(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            string recv = string.Empty;
            rcvSts sts = rcvSts.Stx;      //受信ステータス
            int reqSize = 0;                 //受信要求サイズ
            string errorMessage = string.Empty;


            if (!this.IsOpen) return;
            if (this.BytesToRead <= 0) return;

            sw.Start();
            try
            {
                while (true)
                {
                    if (sw.ElapsedMilliseconds > this.Timeout)
                    {
                        errorMessage = "タイムアウトしました";
                        sts = rcvSts.Fail;
                        break;
                    }
                    if (!this.IsOpen)
                    {
                        errorMessage = "ポートが閉じられました";
                        sts = rcvSts.Fail;
                        break;
                    }

                    //受信データ数セット
                    switch (sts)
                    {
                        case rcvSts.Stx: reqSize = StxSize; break; //Stx      1Byte
                        case rcvSts.Header: reqSize = HeaderSize; break; //ヘッダ部 4Byte
                        case rcvSts.Data: reqSize = 1; break; //データ部 1Byteずつ受信
                    }
                    int bytesToRead = this.BytesToRead;
                    if (bytesToRead < reqSize) continue;

                    string buff = string.Empty;
                    if (this.RecvAscii(ref buff, reqSize, this.Timeout))
                    {
                        switch (sts)
                        {
                            case rcvSts.Stx:
                                if (buff[0] == Stx) //Stx以外は無視(読み飛ばす)
                                {
                                    sts = rcvSts.Header;
                                }
                                break;

                            case rcvSts.Header:
                                //機器番号～コマンドまで受信
                                sts = rcvSts.Data;
                                break;

                            case rcvSts.Data:
                                //データ部
                                if (buff[buff.Length - 1] == Etx)
                                {
                                    //チェックサム
                                    string sumData = recv + buff;
                                    string sum = calcCheckSum(sumData.Substring(1, sumData.Length - 4));
                                    if (sumData.Substring(sumData.Length - 3, 2) != sum)
                                    {
                                        errorMessage = "チェックサムエラー";
                                        sts = rcvSts.Fail;
                                        break;
                                    }

                                    sts = rcvSts.Success;
                                }
                                break;
                        }
                    }

                    if (sts != rcvSts.Stx) recv += buff;
                    if (sts == rcvSts.Success || sts == rcvSts.Fail)
                    {
                        break;
                    }
                }

                if (sts == rcvSts.Success)
                {
                    this.RxCommand = recv.Substring(3, 2);
                    this.RxData = recv.Substring(5, recv.Length - 8);
                }

                if (recv.Length > 0)
                {
                    SetReceive(recv);
                }
                if (sts == rcvSts.Fail)
                {
                    SetError(MsgType.RxMsg, errorMessage);
                }
            }
            catch (IOException ioex)
            {
                SetError(MsgType.RxMsg, ioex.Message);
            }
        }
        #endregion

        #region Private Method
        /// <summary>
        /// チェックサムを計算する
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private string calcCheckSum(string data)
        {
            ByteList sumData = new ByteList();

            sumData.Add(data, false);
            int sum = 0;

            foreach (byte d in sumData)
            {
                sum += d;
            }

            sum = sum & 0xFF;
            if (this.SumMode == Sum.Intel)
            {
                sum = (0x100 - sum) & 0xFF;
            }

            return sum.ToString("X2");
        }
        #endregion
    }
}
