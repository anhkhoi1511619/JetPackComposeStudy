﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lecip.IO
{
    /// <summary>
    /// シリアル通信を行うコントロールクラス
    /// SerialIOBinary()使用
    /// </summary>
    public class SerialIOBinaryControl : SerialIOControlBase
    {
        #region Property
        /// <summary>送信データのI/F種別</summary>
        public byte TxIFType { get { return ((SerialIOBinary)this.Serial).TxIFType; } }

        /// <summary>受信データのI/F種別</summary>
        public byte RxIFType { get { return ((SerialIOBinary)this.Serial).RxIFType; } }

        /// <summary>受信データのデータ部</summary>
        public List<byte> RxData { get { return ((SerialIOBinary)this.Serial).RxData; } }

        /// <summary>
        /// サイズ項目のエンディアン指定
        /// Lecip.Endian.Little or Lecip.Endian.Bigで指定
        /// true:リトルエンディアン(デフォルト) false:ビッグエンディアン
        /// </summary>
        public bool SzEndiain
        {
            get { return ((SerialIOBinary)this.Serial).SzEndiain; }
            set { ((SerialIOBinary)this.Serial).SzEndiain = value; }
        }

        /// <summary>
        /// 機器番号を使うか使わないかの設定(地域連携のみ使う(予約項目)
        /// true:使う false:使わない
        /// </summary>
        public bool UseKikiNo
        {
            get { return ((SerialIOBinary)this.Serial).UseKikiNo; }
            set { ((SerialIOBinary)this.Serial).UseKikiNo = value; }
        }

        /// <summary>
        /// 機器番号(地域連携対応)
        /// デフォルト00H
        /// </summary>
        public byte KikiNo
        {
            get { return ((SerialIOBinary)this.Serial).KikiNo; }
            set { ((SerialIOBinary)this.Serial).KikiNo = value; }
        }

        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return ((SerialIOBinary)this.Serial).DebugList; } }

        /// <summary>デバッグモードを設定するプロパティ</summary>
        public int DebugMode { set { ((SerialIOBinary)this.Serial).DebugMode = value; } }
        #endregion

        #region Constructor
        /// <summary>
        /// SerialIOBinaryControlクラスの新しいインスタンスを初期化します
        /// </summary>
        /// <param name="multiline">通信表示を複数行モードで行うか単行で行うかの設定</param>
        public SerialIOBinaryControl(TextBoxLog.MulitlineMode multiline) : base(new SerialIOBinary(), multiline)
        {

        }
        #endregion

        #region Public Method
        /// <summary>
        /// コマンド送信
        /// </summary>
        /// <param name="ifType">IF種別</param>
        /// <param name="data">データ部</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(byte ifType, List<byte> data, int receiveTimeout = 0)
        {
            ((SerialIOBinary)this.Serial).Send(ifType, data, receiveTimeout);
        }

        /// <summary>
        /// コマンド送信
        /// </summary>
        /// <param name="ifType">IF種別</param>
        /// <param name="data">データ部</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(byte ifType, byte[] data, int receiveTimeout = 0)
        {
            ((SerialIOBinary)this.Serial).Send(ifType, data, receiveTimeout);
        }
        #endregion
    }
}
