﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lecip.IO
{
    /// <summary>
    /// シリアル通信を行うコントロールクラス
    /// SerialIOAscii()使用
    /// </summary>
    public class SerialIOAsciiControl : SerialIOControlBase
    {
        #region Property
        /// <summary>機器番号</summary>
        public string KikiNo
        {
            get { return ((SerialIOAscii)this.Serial).KikiNo; }
            set { ((SerialIOAscii)this.Serial).KikiNo = value; }
        }

        /// <summary>送信データのコマンド部</summary>
        public string TxCommand
        {
            get { return ((SerialIOAscii)this.Serial).TxCommand; }
        }

        /// <summary>受信データのコマンド部</summary>
        public string RxCommand
        {
            get { return ((SerialIOAscii)this.Serial).RxCommand; }
        }

        /// <summary>受信データのデータ部(コマンドは除く)</summary>
        public string RxData
        {
            get { return ((SerialIOAscii)this.Serial).RxData; }
        }

        /// <summary>サム計算のモード</summary>
        public SerialIOAscii.Sum SumMode
        {
            get { return ((SerialIOAscii)this.Serial).SumMode; }
            set { ((SerialIOAscii)this.Serial).SumMode = value; }
        }

        /// <summary>デバッグモード コマンド ( string.Empty以外:デバッグモード。コマンド送信時にこちらの値に置き換える)</summary>
        public string DebugCommand
        {
            get { return ((SerialIOAscii)this.Serial).DebugCommand; }
            set { ((SerialIOAscii)this.Serial).DebugCommand = value; }
        }
        
        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return ((SerialIOAscii)this.Serial).DebugList; } }

        /// <summary>デバッグモードを設定するプロパティ</summary>
        public int DebugMode { set { ((SerialIOAscii)this.Serial).DebugMode = value; } }
        #endregion

        #region Constructor
        /// <summary>
        /// SerialIOAsciiControlクラスの新しいインスタンスを初期化します
        /// </summary>
        /// <param name="multiline">通信表示を複数行モードで行うか単行で行うかの設定</param>
        public SerialIOAsciiControl(TextBoxLog.MulitlineMode multiline) : base(new SerialIOAscii(), multiline)
        {

        }
        #endregion

        #region Public Method
        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <param name="data">データ</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(string command, string data, int receiveTimeout = 0)
        {
            ((SerialIOAscii)this.Serial).Send(command, data, receiveTimeout);
        }
        #endregion
    }
}
