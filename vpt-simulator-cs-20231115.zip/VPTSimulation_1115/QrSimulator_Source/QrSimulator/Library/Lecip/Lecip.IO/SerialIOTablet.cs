﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Lecip.IO
{
    /// <summary>
    /// <para>タブレット通信シリアル通信クラス(バイナリフォーマット)</para>
    /// <para>+---------+--------+-------------+----------+--------+------+------+-----+-----+---------+</para>
    /// <para>|STX(0x02)|コマンド|サイズ(2Byte)|サイズサム|送信通番|固有ID|データ|サム1|サム2|ETX(0x03)|</para>
    /// <para>+---------+--------+-------------+----------+--------+------+------+-----+-----+---------+</para>
    /// <para>サイズ=データ部のサイズ(ビッグエンディアン)(固有ID含まず)</para>
    /// <para>サイズサム=コマンド+サイズ+サイズサム=0x00となる値</para>
    /// <para>サム1=コマンド～データまでの単純加算</para>
    /// <para>サム2=サム1のビット反転</para>
    /// </summary>
    public class SerialIOTablet : SerialIO
    {
        #region Field
        private const byte Stx = 0x02;
        private const byte Etx = 0x03;
        private const int StxSize = 1; //Stx
        private const int HeaderSize = 5; //コマンド～送信通番
        private const int UniqueIDSize = 6; //固有ID
        private const int FooterSize = 3; //サム1～Etx

        private enum rcvSts
        {
            Stx,
            Header,
            UniqueID,
            Data,
            Footer,
            Success,
            Fail,
        }
        /// <summary>送信通番</summary>
        private byte sq;
        /// <summary>前回送信通番</summary>
        private byte baksq;
        #endregion

        #region Property
        /// <summary>送信コマンド</summary>
        public byte TxCommand { get; private set; }

        /// <summary>受信コマンド</summary>
        public byte RxCommand { get; private set; }

        /// <summary>受信固有ID(受信時にセット)</summary>
        public List<byte> RxUniqueID { get; private set; }

        /// <summary>受信データ部</summary>
        public List<byte> RxData { get; private set; }

        /// <summary>送信通番更新フラグ true:送信通番更新された false:送信通番同一のまま</summary>
        public bool SeqUpdated { get { return (this.sq != this.baksq); } }

        /// <summary>
        /// サイズ項目のエンディアン指定
        /// Lecip.Endian.Little or Lecip.Endian.Bigで指定
        /// true:リトルエンディアン(デフォルト) false:ビッグエンディアン
        /// </summary>
        public bool SzEndiain { get; set; }

        #region Debug Property
        /// <summary>
        /// デバッグモード I/F種別 ( 0x00以外:デバッグモード。コマンド送信時にこちらの値に置き換える)
        /// </summary>
        public byte DebugCommand { get; set; }
        /// <summary>
        /// デバッグモード サイズ算出
        /// 0:通常モード 1:デバッグモード(正しいサイズ+1にする) 2:デバッグモード(正しいサイズ-1にする)
        /// </summary>
        public int DebugLen { get; set; }
        /// <summary>
        /// デバッグモード サイズサム算出
        /// false:通常モード true:デバッグモード(正しいサム+1にする)
        /// </summary>
        public bool DebugLenSum { get; set; }
        /// <summary>
        /// デバッグモード サム算出
        /// false:通常モード true:デバッグモード(正しいサム+1にする)
        /// </summary>
        public bool DebugSum { get; set; }

        /// <summary>
        /// デバッグモード 送信通番固定
        /// false:通常モード true:デバッグモード(送信通番を固定にする)
        /// </summary>
        public bool DebugFixSeq { get; set; }

        /// <summary>
        /// 設定可能なデバッグモードを文字列配列で返すプロパティ
        /// </summary>
        public string[] DebugList
        {
            get
            {
                return new string[] { "通常", "LEN異常", "LENサム異常", "チェックサム異常", "送信通番固定" };
            }
        }

        /// <summary>
        /// デバッグモードを設定するプロパティ
        /// 0:通常(デバッグモード解除)
        /// 1:LEN異常
        /// 2:チェックサム異常
        /// </summary>
        public int DebugMode
        {
            set
            {
                this.DebugLen = 0;
                this.DebugLenSum = false;
                this.DebugSum = false;
                this.DebugFixSeq = false;

                switch (value)
                {
                    case 0: break; //通常
                    case 1: this.DebugLen = 1; break; //データ長異常
                    case 2: this.DebugLenSum = true; break; //データ長サム異常
                    case 3: this.DebugSum = true; break; //サム異常
                    case 4: this.DebugFixSeq = true; break; //送信通番固定
                }
            }
        }
        #endregion
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SerialIOTablet()
        {
            this.sq = 0;
            this.baksq = 0xFF;
            this.DebugCommand = 0x00;
            this.DebugLen = 0;
            this.DebugLenSum = false;
            this.DebugSum = false;

            this.RxCommand = 0x00;
            this.RxData = new List<byte>();
            this.SzEndiain = Lecip.Endian.Little;
        }
        #endregion

        #region 送信処理
        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="txCommand">送信コマンド</param>
        /// <param name="uniqueID">送信固有ID</param>
        /// <param name="data">データ</param>
        /// <param name="useReceiveTimeout">受信タイムアウト処理の実施可否 true:する false:しない</param>
        public void Send(byte txCommand, List<byte> uniqueID, List<byte> data, bool useReceiveTimeout = true)
        {
            List<byte> sendData = new List<byte>();

            //Stxセット
            sendData.Add(Stx);
            //送信コマンドセット
            if (this.DebugCommand != 0x00) txCommand = this.DebugCommand;
            this.TxCommand = txCommand;
            sendData.Add(txCommand);
            //サイズセット
            UInt16 size = (UInt16)data.Count;
            if (this.DebugLen == 1) size++;
            if (this.DebugLen == 2) size--;
            if (this.SzEndiain == Lecip.Endian.Little)
            {
                sendData.Add((byte)(size & 0xFF));
                sendData.Add((byte)(size >> 8 & 0xFF));
            }
            else
            {
                sendData.Add((byte)(size >> 8 & 0xFF));
                sendData.Add((byte)(size & 0xFF));
            }
            //サイズサムセット
            byte lensum = calcSzSum(sendData, 1, 3);
            if (this.DebugLenSum) lensum++;
            sendData.Add(lensum);
            //送信通番セット
            sendData.Add(this.sq);
            //固有IDセット
            sendData.AddRange(uniqueID);
            //データセット
            sendData.AddRange(data);
            //チェックサム
            byte sum1 = 0, sum2 = 0;
            calcCheckSum(sendData, 1, sendData.Count - 1, ref sum1, ref sum2);
            if (this.DebugSum) sum1++;
            sendData.Add(sum1);
            sendData.Add(sum2);
            //STX ETX
            sendData.Add(Etx);

            //タイムアウト処理を開始
            if (useReceiveTimeout) base.StartReceiveTimeout();

            //送信
            base.Send(sendData);
        }
        #endregion

        #region Override
        /// <summary>
        /// シリアル通信受信イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void OnDataReceived(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();
            List<byte> recv = new List<byte>();
            rcvSts sts = rcvSts.Stx; //受信ステータス
            int reqSize = 0; //受信要求サイズ
            int datSize = 0; //データ部サイズ
            string errorMessage = string.Empty;

            if (!this.IsOpen) return;
            if (this.BytesToRead <= 0) return;

            //タイムアウト処理を停止
            base.StopReceiveTimeout();

            sw.Start();
            try
            {
                while (true)
                {
                    if (sw.ElapsedMilliseconds > this.Timeout)
                    {
                        errorMessage = "タイムアウトしました";
                        sts = rcvSts.Fail;
                        break;
                    }
                    if (!this.IsOpen)
                    {
                        errorMessage = "ポートが閉じられました";
                        sts = rcvSts.Fail;
                        break;
                    }

                    //受信データ数セット
                    switch (sts)
                    {
                        case rcvSts.Stx: reqSize = StxSize; break; //Stx
                        case rcvSts.Header: reqSize = HeaderSize; break; //ヘッダ
                        case rcvSts.UniqueID: reqSize = UniqueIDSize; break; //固有ID
                        case rcvSts.Data: reqSize = datSize; break; //データ部 可変(ヘッダデータから算出)
                        case rcvSts.Footer: reqSize = FooterSize; break; //フッタ部 3Byte
                    }
                    int bytesToRead = this.BytesToRead;
                    if (bytesToRead < reqSize) continue;

                    var buff = new List<byte>();
                    if (this.RecvBinary(buff, reqSize, this.Timeout))
                    {
                        switch (sts)
                        {
                            case rcvSts.Stx:
                                //STX
                                if (buff[0] != Stx)
                                {
                                    errorMessage = "STX受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                sts = rcvSts.Header;
                                break;

                            case rcvSts.Header:
                                //コマンド
                                this.RxCommand = buff[0];

                                //データ部のサイズを算出
                                if (this.SzEndiain == Lecip.Endian.Little)
                                {
                                    datSize = buff[1] + buff[2] * 0x100;
                                }
                                else
                                {
                                    datSize = buff[1] * 0x100 + buff[2];
                                }
                                //Szsum
                                if (buff[3] != this.calcSzSum(buff, 0, 3))
                                {
                                    errorMessage = "SZSUMエラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //送信通番更新
                                this.baksq = this.sq;
                                if (!this.DebugFixSeq) this.sq = buff[4];
                                sts = rcvSts.UniqueID;
                                break;

                            case rcvSts.UniqueID:
                                //固有ID
                                this.RxUniqueID = buff;
                                sts = rcvSts.Data;
                                break;

                            case rcvSts.Data:
                                //データ部
                                this.RxData = buff;
                                sts = rcvSts.Footer;
                                break;

                            case rcvSts.Footer:
                                //チェックサム
                                byte sum1 = 0, sum2 = 0;
                                this.calcCheckSum(recv, 1, recv.Count - 1, ref sum1, ref sum2);
                                if (buff[0] != sum1 || buff[1] != sum2)
                                {
                                    errorMessage = "チェックサムエラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //ETX
                                if (buff[2] != Etx)
                                {
                                    errorMessage = "ETX受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //受信OKのためここで送信通番をインクリメントする
                                if (!this.DebugFixSeq) this.sq++;

                                sts = rcvSts.Success;
                                break;
                        }
                    }

                    recv.AddRange(buff);
                    if (sts == rcvSts.Success || sts == rcvSts.Fail)
                    {
                        break;
                    }
                }

                if (sts == rcvSts.Fail)
                {
                    SetError(MsgType.RxMsg, errorMessage);
                }
                else if (sts == rcvSts.Success)
                {
                    this.RxRawData = recv.ToArray();
                    SetReceive();
                }
            }
            catch (IOException ioex)
            {
                SetError(MsgType.RxMsg, ioex.Message);
            }
        }
        #endregion

        #region チェックサム処理
        /// <summary>
        /// SZSUMを計算する
        /// SZSUM:合計して0x00になる値
        /// </summary>
        /// <param name="data">サム対象データ</param>
        /// <param name="start">開始位置</param>
        /// <param name="length">サム対象バイトサイズ</param>
        /// <returns>SZSUM</returns>
        private byte calcSzSum(List<byte> data, int start, int length)
        {
            byte sum = 0;

            for (int i = 0; (i < length) && (i + start < data.Count); i++)
            {
                sum += data[i + start];
            }

            return (byte)((0x100 - sum) & 0xFF);
        }

        /// <summary>
        /// チェックサムを計算してSUM1,SUM2を求める
        /// SUM1:1byte単位の単純加算
        /// SUM2:SUM1のビット反転
        /// </summary>
        /// <param name="data">サム対象データ</param>
        /// <param name="start">開始位置</param>
        /// <param name="length">サム対象バイトサイズ</param>
        /// <param name="sum1">SUM1</param>
        /// <param name="sum2">SUM2</param>
        private void calcCheckSum(List<byte> data, int start, int length, ref byte sum1, ref byte sum2)
        {
            byte sum = 0;
            for (int i = 0; (i < length) && (i + start < data.Count); i++)
            {
                sum += data[i + start];
            }

            sum1 = sum;
            sum2 = (byte)((~sum1) & 0xFF);
        }
        #endregion
    }
}
