﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Diagnostics;

namespace Lecip.IO
{
    /// <summary>
    /// シリアル通信するためのクラス。SerialPortから派生
    /// </summary>
    public class SerialIOBase : SerialPort
    {
        #region Property
        /// <summary>Settingsプロパティ MSCOMMコントロールのSettingsと同じ手法で設定する</summary>
        /// <remarks></remarks>
        public string Settings
        {
            get
            {
                //Settingsパラメータを返す
                string ret = "";
                ret = this.BaudRate.ToString();
                ret += ",";
                switch (this.Parity)
                {
                    case Parity.None:  ret += "N,"; break;
                    case Parity.Even:  ret += "E,"; break;
                    case Parity.Odd:   ret += "O,"; break;
                    case Parity.Mark:  ret += "M,"; break;
                    case Parity.Space: ret += "S,"; break;
                }
                ret += this.DataBits.ToString();
                ret += ",";
                switch (this.StopBits)
                {
                    case StopBits.One:          ret += "1";   break;
                    case StopBits.OnePointFive: ret += "1.5"; break;
                    case StopBits.Two:          ret += "2";   break;
                }

                return ret;
            }

            set
            {
                //Settingsパラメータから通信設定をする
                int result;
                string[] s = value.Split(',');

                if (s.Length < 4)
                {
                    return; //パラメータ長が足りないので何もしない
                }
                //ボーレート設定(数値に変換できない時は何もしない
                if (int.TryParse(s[0], out result))
                {
                    this.BaudRate = Convert.ToInt32(s[0]);
                }

                //パリティ設定(該当するパラメータが無い場合は何もしない)
                switch (s[1].ToUpper())
                {
                    case "N": this.Parity = Parity.None; break;
                    case "E": this.Parity = Parity.Even; break;
                    case "O": this.Parity = Parity.Odd; break;
                    case "M": this.Parity = Parity.Mark; break;
                    case "S": this.Parity = Parity.Space; break;
                    default: break;
                }
                //データビット設定(数値に変換できない時は何もしない
                if (int.TryParse(s[2], out result))
                {
                    this.DataBits = Convert.ToInt32(s[2]);
                }
                //ストップビット設定(該当するパラメータが無い場合は何もしない)
                switch (s[3])
                {
                    case "1": this.StopBits = StopBits.One; break;
                    case "1.5": this.StopBits = StopBits.OnePointFive; break;
                    case "2": this.StopBits = StopBits.Two; break;
                    default: break;
                }
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SerialIOBase()
        {
            //通信パラメータ初期設定値
            this.Settings = "38400,N,8,1";
        }
        #endregion

        #region Public Method
        /// <summary>
        /// ポートオープンします
        /// </summary>
        public new void Open()
        {
            try
            {
                base.Open();
            }
            catch (IOException ex)
            {
                throw new IOException("シリアルポートオープンエラー" + "\r\n" + ex.Message);
            }
            catch (UnauthorizedAccessException uex)
            {
                throw new IOException("シリアルポートオープンエラー" + "\r\n" + uex.Message);
            }
        }

        /// <summary>
        /// byte配列データを送信します
        /// </summary>
        /// <param name="data">送信データ</param>
        public void SendBinary(byte[] data)
        {
            if (!this.IsOpen)
            {
                throw new IOException("シリアルポートが開いていません");
            }

            this.Reset();
            this.Write(data, 0, data.Length);
        }

        /// <summary>
        /// byte配列データを送信します
        /// </summary>
        /// <param name="data">送信データ</param>
        /// <param name="length">送信データサイズ</param>
        public void SendBinary(byte[] data, int length)
        {
            if (!this.IsOpen)
            {
                throw new IOException("シリアルポートが開いていません");
            }

            this.Reset();
            this.Write(data, 0, length);
        }

        /// <summary>
        /// byte Listオブジェクトデータを送信します
        /// </summary>
        /// <param name="data">送信データ</param>
        public void SendBinary(List<byte> data)
        {
            this.SendBinary(data.ToArray());
        }

        /// <summary>
        /// Ascii文字列を送信します
        /// </summary>
        /// <param name="data">送信データ</param>
        public void SendAscii(string data)
        {
            if (!this.IsOpen)
            {
                throw new IOException("シリアルポートが開いていません");
            }
            this.Reset();
            this.Write(data);
        }

        /// <summary>
        /// 受信処理を行い、byte Listオブジェクト変数に格納します
        /// </summary>
        /// <param name="data">受信データ</param>
        /// <param name="reqSize">受信要求サイズ</param>
        /// <param name="timeout">ミリ秒タイムアウト</param>
        /// <returns>true:受信成功 false:タイムアウトエラー</returns>
        public bool RecvBinary(List<byte> data, int reqSize, int timeout)
        {
            var sw = new Stopwatch();    //タイムアウト計算用StopWatch
            byte recv = 0;

            sw.Start();
            while (true)
            {
                if (reqSize <= 0)
                {
                    break;
                }
                if (sw.ElapsedMilliseconds >= timeout)
                {
                    return false;
                }

                if (this.RecvByte(ref recv))
                {
                    data.Add(recv);
                    reqSize--;
                }
            }
            sw.Stop();

            return true;
        }

        /// <summary>
        /// byte[]配列に指定バイト数受信します
        /// </summary>
        /// <param name="recvData">受信データ</param>
        /// <param name="reqSize">要求バイト数</param>
        /// <param name="timeout">ミリ秒タイムアウト</param>
        /// <returns>受信バイト数</returns>
        public int RecvBinary(ref byte[]recvData, int reqSize, int timeout)
        {
            int  recvSize = 0;
            byte recv = 0;
            var  sw = new Stopwatch();    //タイムアウト計算用StopWatch

            recvData = new byte[reqSize];

            sw.Start();
            while (true)
            {
                if (recvSize == reqSize) break;

                if (sw.ElapsedMilliseconds >= timeout) break;

                if (this.RecvByte(ref recv))
                {
                    recvData[recvSize] = recv;
                    recvSize++;
                }
            }
            sw.Stop();

            return recvSize;
        }

        /// <summary>
        /// 受信処理を行い、string型に格納します
        /// 文字列型に変換して返します (0x2A, 0x31, 0x32 -> "*12")
        /// </summary>
        /// <param name="data">受信データ</param>
        /// <param name="reqSize">受信要求サイズ</param>
        /// <param name="timeout">ミリ秒タイムアウト</param>
        /// <returns>true:受信成功 false:タイムアウトエラー</returns>
        public bool RecvAscii(ref string data, int reqSize, int timeout)
        {
            var sw = new Stopwatch();    //タイムアウト計算用StopWatch
            byte recv = 0;

            sw.Start();
            while (true)
            {
                if (reqSize <= 0)
                {
                    break;
                }
                if (sw.ElapsedMilliseconds >= timeout)
                {
                    return false;
                }

                if (this.RecvByte(ref recv))
                {
                    data += (char)recv;
                    reqSize--;
                }
            }
            sw.Stop();

            return true;
        }

        /// <summary>
        /// 1byteだけ受信します
        /// </summary>
        /// <param name="data">受信データ</param>
        /// <returns>true:成功 false:失敗</returns>
        public bool RecvByte(ref byte data)
        {
            data = 0x00;
            if (!this.IsOpen)
            {
                throw new IOException("シリアルポートが開いていません");
            }

            if (this.BytesToRead > 0)
            {
                data = (byte)this.ReadByte();
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 受信バッファ、送信バッファをクリアします
        /// </summary>
        public void Reset()
        {
            if (!this.IsOpen) return;

            this.DiscardInBuffer();
            this.DiscardOutBuffer();
        }
        #endregion
    }
}