﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lecip.IO
{
    /// <summary>
    /// シリアル通信を行うコントロールクラス
    /// SerialIONishitetsuOnsei()使用
    /// </summary>
    public class SerialIONishitetsuOnseiControl : SerialIOControlBase
    {
        #region Property
        /// <summary>送信元機器番号</summary>
        public char SrcKikiNo
        {
            get { return ((SerialIONishitetsuOnsei)this.Serial).SrcKikiNo; }
            set { ((SerialIONishitetsuOnsei)this.Serial).SrcKikiNo = value; }
        }

        /// <summary>送信先機器番号</summary>
        public char DstKikiNo
        {
            get { return ((SerialIONishitetsuOnsei)this.Serial).DstKikiNo; }
            set { ((SerialIONishitetsuOnsei)this.Serial).DstKikiNo = value; }
        }

        /// <summary>送信データのコマンド部</summary>
        public string TxCommand
        {
            get { return ((SerialIONishitetsuOnsei)this.Serial).TxCommand; }
        }

        /// <summary>受信データのコマンド部</summary>
        public string RxCommand
        {
            get { return ((SerialIONishitetsuOnsei)this.Serial).RxCommand; }
            set { ((SerialIONishitetsuOnsei)this.Serial).RxCommand = value; }
        }

        /// <summary>受信データのデータ部(コマンドは除く)</summary>
        public string RxData
        {
            get { return ((SerialIONishitetsuOnsei)this.Serial).RxData; }
            set { ((SerialIONishitetsuOnsei)this.Serial).RxData = value; }
        }

        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return ((SerialIONishitetsuOnsei)this.Serial).DebugList; } }

        /// <summary>デバッグモードを設定するプロパティ</summary>
        public int DebugMode { set { ((SerialIONishitetsuOnsei)this.Serial).DebugMode = value; } }
        #endregion

        #region Constructor
        /// <summary>
        /// SerialIONishitetsuOnseiControlクラスの新しいインスタンスを初期化します
        /// </summary>
        /// <param name="multiline">通信表示を複数行モードで行うか単行で行うかの設定</param>
        public SerialIONishitetsuOnseiControl(TextBoxLog.MulitlineMode multiline) : base(new SerialIONishitetsuOnsei(), multiline)
        {

        }
        #endregion

        #region Public Method
        /// <summary>
        /// コマンド送信
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <param name="data">データ</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(string command, string data, int receiveTimeout = 0)
        {
            ((SerialIONishitetsuOnsei)this.Serial).Send(command, data, receiveTimeout);
        }
        #endregion
    }
}
