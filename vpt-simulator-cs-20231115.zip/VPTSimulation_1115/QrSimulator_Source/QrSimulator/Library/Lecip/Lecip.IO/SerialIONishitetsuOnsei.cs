﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Lecip.IO
{
    /// <summary>
    /// <para>西鉄音声合成シリアル通信クラス(アスキーフォーマット)</para>
    /// <para>+------------+----+-----+-----+-----+------+----+-----------+</para>
    /// <para>| STX(0x10)  |SRC | DST | CMD |SZ   |DT    |SUM |ETX(0x0D0A)|</para>
    /// <para>|    ○      | ○ | ○  | ○  |○○ | ○   |○○|○○       |</para>
    /// <para>+------------+----+-----+-----+-----+------+----+-----------+</para>
    /// </summary>
    public class SerialIONishitetsuOnsei : SerialIO
    {
        #region Field
        private const char Stx        = (char)0x10;
        private const char Etx1       = (char)0x0D;
        private const char Etx2       = (char)0x0A;
        private const int  StxSize    = 1; //STX
        private const int  HeaderSize = 5; //SRC - SZまでのサイズ
        private const int  SumSize    = 2; //SUMのサイズ
        private const int  EtxSize    = 2; //ETXのサイズ

        private enum rcvSts
        {
            Stx,
            Header,
            Data,
            Sum,
            Etx,
            Success,
            Fail,
        }
        #endregion

        #region Property
        /// <summary>送信元機器番号</summary>
        public char SrcKikiNo { get; set; }
        /// <summary>送信先機器番号</summary>
        public char DstKikiNo { get; set; }
        /// <summary>送信データのコマンド部</summary>
        public string TxCommand { get; private set; }
        /// <summary>受信データのコマンド部</summary>
        public string RxCommand { get; set; }
        /// <summary>受信データのデータ部(コマンドは除く)</summary>
        public string RxData { get; set; }

        #region Debug Property
        /// <summary>デバッグモード コマンド ( string.Empty以外:デバッグモード。コマンド送信時にこちらの値に置き換える)</summary>
        public string DebugCommand { get; set; }
        /// <summary>デバッグモード サイズ算出 true:通常モード false:デバッグモード(正しいサイズ+1にする)</summary>
        public bool DebugSz { get; set; }
        /// <summary>デバッグモード サム算出 true:通常モード false:デバッグモード(正しいサム+1にする)</summary>
        public bool DebugSum { get; set; }
        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return new string[] { "通常", "LEN異常", "チェックサム異常" }; } }

        /// <summary>
        /// デバッグモードを設定するプロパティ
        /// 0:通常(デバッグモード解除)
        /// 1:サイズ異常
        /// 2:チェックサム異常
        /// </summary>
        public int DebugMode
        {
            set
            {
                this.DebugSz = this.DebugSum = false;

                switch (value)
                {
                    case 0: break; //通常
                    case 1: this.DebugSz  = true; break; //サイズ異常
                    case 2: this.DebugSum = true; break; //サム異常
                }
            }
        }
        #endregion
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SerialIONishitetsuOnsei()
        {
            this.DebugCommand = string.Empty;
            this.DebugSz      = false;
            this.DebugSum     = false;

            this.RxCommand    = string.Empty;
            this.RxData       = string.Empty;

            this.SrcKikiNo = 'a';
            this.DstKikiNo = 'W';
        }
        #endregion

        #region Public Method
        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <param name="data">データ</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(string command, string data, int receiveTimeout = 0)
        {
            string sendData;
            string sz;
            string sum;

            //CMD算出
            if (this.DebugCommand != string.Empty) command = this.DebugCommand;
            this.TxCommand = command;

            //SZ算出
            if ((data.Length <= 255) && command != "M")
            {
                if (command == "a") command = "A";
                sz = (data.Length + ((this.DebugSz) ? 1 : 0)).ToString("X2");
            }
            else
            {
                if (command == "A") command = "a";
                sz = (data.Length + ((this.DebugSz) ? 1 : 0)).ToString("X4");
            }

            //SRC - DT算出
            sendData = $"{this.SrcKikiNo}{this.DstKikiNo}{command}{sz}{data}";

            //SUM算出
            sum = calcCheckSum(sendData + ((this.DebugSum) ? "01" : string.Empty));

            //Stx付与
            sendData = $"{Stx}{sendData}{sum}";

            //応答が必要なコマンドの場合、タイムアウト処理を開始(recevieTimeoutが0未満の場合、タイムアウト処理を行わない)
            if (receiveTimeout >= 0) base.StartReceiveTimeout();

            try
            {
                this.Send($"{sendData}{Etx1}{Etx2}");
            }
            catch (IOException ex)
            {
                SetError(MsgType.TxMsg, ex.Message);
            }
        }
        #endregion

        #region Override
        /// <summary>
        /// シリアル通信受信イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void OnDataReceived(object sender, EventArgs e)
        {
            Stopwatch sw    = new Stopwatch();
            string recvData = string.Empty;
            rcvSts sts      = rcvSts.Stx;    //受信ステータス
            int reqSize     = 0;            //受信要求サイズ
            int datSize     = 0;
            string errorMessage = string.Empty;

            if (!this.IsOpen) return;
            if (this.BytesToRead <= 0) return;

            //タイムアウト処理を停止
            base.StopReceiveTimeout();

            sw.Start();
            try
            {
                while (true)
                {
                    if (sw.ElapsedMilliseconds > this.Timeout)
                    {
                        errorMessage = "タイムアウトしました";
                        sts = rcvSts.Fail;
                        break;
                    }
                    if (!this.IsOpen)
                    {
                        errorMessage = "ポートが閉じられました";
                        sts = rcvSts.Fail;
                        break;
                    }

                    //受信データ数セット
                    switch (sts)
                    {
                        case rcvSts.Stx:    reqSize = StxSize; break; //Stx      1Byte
                        case rcvSts.Header: reqSize = HeaderSize; break; //ヘッダ部 5Byte
                        case rcvSts.Data:   reqSize = datSize; break; //データ部 可変
                        case rcvSts.Sum:    reqSize = SumSize; break; //サム部   2Byte
                        case rcvSts.Etx:    reqSize = EtxSize; break; //Etx      2Byte
                    }
                    int bytesToRead = this.BytesToRead;
                    if (bytesToRead < reqSize) continue;

                    string buff = string.Empty;
                    if (this.RecvAscii(ref buff, reqSize, this.Timeout))
                    {
                        switch (sts)
                        {
                            case rcvSts.Stx:
                                //STX
                                if (buff[0] != Stx)
                                {
                                    errorMessage = "STX受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                sts = rcvSts.Header;
                                break;

                            case rcvSts.Header:
                                //SRC
                                if (buff[0] != this.DstKikiNo)
                                {
                                    errorMessage = "SRC受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //DST
                                if (buff[1] != this.SrcKikiNo)
                                {
                                    errorMessage = "DST受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //CMD
                                this.RxCommand = $"{buff[2]}";
                                //SZ
                                if (!('0' <= buff[3] && buff[3] <= '9') && !('A' <= buff[3] && buff[3] <= 'F'))
                                {
                                    errorMessage = "SZ受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                if (!('0' <= buff[4] && buff[4] <= '9') && !('A' <= buff[4] && buff[4] <= 'F'))
                                {
                                    errorMessage = "SZ受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                datSize = Convert.ToInt32(buff.Substring(3, 2), 16); //データのサイズ
                                sts = rcvSts.Data;
                                break;

                            case rcvSts.Data:
                                this.RxData = buff;
                                sts = rcvSts.Sum;
                                break;

                            case rcvSts.Sum:
                                if (calcCheckSum(recvData.Substring(1)) != buff)
                                {
                                    errorMessage = "チェックサムエラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                sts = rcvSts.Etx;
                                break;

                            case rcvSts.Etx:
                                //データ部
                                if (buff[0] != Etx1)
                                {
                                    errorMessage = "Etxエラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                if (buff[1] != Etx2)
                                {
                                    errorMessage = "Etxエラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                sts = rcvSts.Success;
                                break;
                        }
                    }

                    if (sts != rcvSts.Success) recvData += buff;
                    if (sts == rcvSts.Success || sts == rcvSts.Fail) break;
                }

                if (sts == rcvSts.Success)
                {
                    SetReceive(recvData);
                }
                else if (sts == rcvSts.Fail)
                {
                    SetError(MsgType.RxMsg, errorMessage);
                }
            }
            catch (IOException ioex)
            {
                SetError(MsgType.RxMsg, ioex.Message);
            }
        }
        #endregion

        #region Private Method
        /// <summary>
        /// チェックサムを計算する
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private string calcCheckSum(string data)
        {
            int sum = 0;

            for (int i = 0; i < data.Length; i++)
            {
                sum += data[i];
            }

            sum = sum & 0xFF;

            return sum.ToString("X2");
        }
        #endregion
    }
}
