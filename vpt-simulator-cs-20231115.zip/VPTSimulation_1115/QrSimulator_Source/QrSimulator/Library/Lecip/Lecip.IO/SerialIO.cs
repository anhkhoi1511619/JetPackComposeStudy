﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Diagnostics;

namespace Lecip.IO
{
    #region MsgType
    /// <summary> 通信メッセージ種別 </summary>
    public enum MsgType
    {
        /// <summary> Tx:送信 </summary>
        Tx,
        /// <summary> Rx:受信 </summary>
        Rx,
        /// <summary> TxMsg:送信メッセージ </summary>
        TxMsg,
        /// <summary> RxMsg:受信メッセージ </summary>
        RxMsg,
    }
    #endregion

    /// <summary>
    /// シリアル通信をするためのクラス。SerialIOBaseから派生
    /// </summary>
    public class SerialIO : SerialIOBase
    {
        #region Event Handler
        /// <summary> データ受信時のイベントハンドラ </summary>
        public event EventHandler SerialIODataReceived;
        /// <summary> エラー発生時のイベントハンドラ </summary>
        public event EventHandler SerialIOErrorReceived;
        /// <summary> 受信タイムアウト発生時のイベントハンドラ </summary>
        public event EventHandler SerialIOTimeoutReceived;
        /// <summary> 通信ログ保存コールバック </summary>
        public delegate void WriteLogEventHandler(object sender, MsgType type, string log);
        /// <summary> 通信ログ保存イベントハンドラ </summary>
        public event WriteLogEventHandler SerialIOWriteLog;
        #endregion

        #region Property
        /// <summary> 受信タイムアウト(msec) </summary>
        public int Timeout { get; set; }

        /// <summary> エラーメッセージ </summary>
        public string ErrorMessage { get; set; }

        /// <summary> シリアル受信時の受信データ </summary>
        public byte[] RxRawData { get; set; }

        /// <summary> 通信ログファイル出力ONOFFフラグ </summary>
        public bool EnableWriteLog
        {
            get { return this.enableWriteLog; }

            set
            {
                this.enableWriteLog = value;
                if (this.fileLog != null) this.fileLog.Enabled = value;
            }
        }

        /// <summary> 通信ログのファイルパス </summary>
        public string FileLogPath { get; set; }

        /// <summary> シミュレータの状態を文字列で返す </summary>
        public string PortStatus
        {
            get
            {
                return string.Format("{0}:{1} ({2})", this.PortName, this.IsOpen ? "Open" : "Close", this.Settings);
            }
        }
        #endregion

        #region Field
        /// <summary> 通信ログファイル書込みONOFFフラグ </summary>
        private bool enableWriteLog;
        /// <summary> 通信ログファイル書込みクラス </summary>
        private FileLog fileLog;
        /// <summary> 受信タイムアウトタイマー </summary>
        private System.Timers.Timer recvTimeoutTimer;
        #endregion

        #region Constructor
        /// <summary>
        /// SerialIOクラスの新しいインスタンスを初期化します
        /// </summary>
        public SerialIO()
        {
            this.RtsEnable = true;
            this.Timeout = 2000;
            this.EnableWriteLog = false;
            this.DataReceived += (sender, e) => { OnDataReceived(sender, e); };

            this.fileLog = new FileLog();
        }
        #endregion

        #region Public Method
        /// <summary>
        /// ポートをオープンする
        /// </summary>
        public new void Open()
        {
            try
            {
                base.Open();

                //受信タイムアウトタイマー初期化
                if (this.Timeout > 0)
                {
                    this.recvTimeoutTimer = new System.Timers.Timer(this.Timeout);
                    this.recvTimeoutTimer.Stop();
                    this.recvTimeoutTimer.Elapsed += elapsedTimeout;
                }
            }
            catch (IOException ex)
            {
                SetError(MsgType.TxMsg, ex.Message);
            }
        }

        /// <summary>
        /// ポートをクローズする
        /// </summary>
        public new void Close()
        {
            if (this.recvTimeoutTimer != null)
            {
                this.recvTimeoutTimer.Elapsed -= elapsedTimeout;
                this.recvTimeoutTimer.Dispose();
                this.recvTimeoutTimer = null;
            }

            base.Close();

            this.fileLog.Close();
        }

        /// <summary>
        /// データを送信する
        /// </summary>
        /// <param name="data">送信データ</param>
        public void Send(List<byte> data)
        {
            Send(data.ToArray());
        }

        /// <summary>
        /// データを送信する
        /// </summary>
        /// <param name="data">送信データ</param>
        public void Send(byte[] data)
        {
            try
            {
                writeLog(MsgType.Tx, data);
                this.SendBinary(data);
            }
            catch (IOException ex)
            {
                SetError(MsgType.TxMsg, ex.Message);
            }
        }

        /// <summary>
        /// データを送信する
        /// </summary>
        /// <param name="data">送信データ</param>
        /// <param name="length">送信サイズ</param>
        public void Send(byte[] data, int length)
        {
            try
            {
                writeLog(MsgType.Tx, data, length);
                this.SendBinary(data, length);
            }
            catch (IOException ex)
            {
                SetError(MsgType.TxMsg, ex.Message);
            }
        }

        /// <summary>
        /// 文字列データを送信する
        /// </summary>
        /// <param name="data">送信データ</param>
        public void Send(string data)
        {
            try
            {
                writeLog(MsgType.Tx, data);
                this.SendAscii(data);
            }
            catch (IOException ex)
            {
                SetError(MsgType.TxMsg, ex.Message);
            }
        }

        /// <summary>
        /// 受信タイムアウト処理を開始する
        /// </summary>
        public void StartReceiveTimeout()
        {
            if (this.recvTimeoutTimer == null) return;

            this.recvTimeoutTimer.Stop();
            this.recvTimeoutTimer.Start();
        }

        /// <summary>
        /// 受信タイムアウト処理を停止する
        /// </summary>
        public void StopReceiveTimeout()
        {
            if (this.recvTimeoutTimer == null) return;

            this.recvTimeoutTimer.Stop();
        }
        #endregion

        #region Callback
        /// <summary>
        /// 受信イベント発生時の処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected virtual void OnDataReceived(object sender, EventArgs e)
        {
            dataReceive();
        }

        /// <summary>
        /// 受信処理
        /// </summary>
        private void dataReceive()
        {
            Stopwatch sw = new Stopwatch();

            if (!this.IsOpen) return;
            if (this.BytesToRead <= 0) return;

            sw.Start();
            try
            {
                while (true)
                {
                    if (sw.ElapsedMilliseconds > this.Timeout)
                    {
                        SetError(MsgType.RxMsg, "タイムアウトしました");
                        return;
                    }
                    if (!this.IsOpen)
                    {
                        SetError(MsgType.RxMsg, "ポートが閉じられました");
                        return;
                    }

                    int bytesToRead = this.BytesToRead;
                    if (bytesToRead <= 0) continue;

                    byte[] data = null;
                    if (this.RecvBinary(ref data, bytesToRead, this.Timeout) >= bytesToRead)
                    {
                        this.RxRawData = data;
                        break;
                    }
                }

                SetReceive();
            }
            catch (IOException ioex)
            {
                SetError(MsgType.RxMsg, ioex.Message);
            }
        }
        /// <summary>
        /// 受信タイムアウト発生イベント処理(タイマー起動)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void elapsedTimeout(object sender, System.Timers.ElapsedEventArgs e)
        {
            System.Timers.Timer timer = (System.Timers.Timer)sender;
            timer.Stop();

            setTimeout();
        }
        #endregion

        #region Event Handler
        /// <summary>受信イベントを起こす</summary>
        protected void SetReceive()
        {
            writeLog(MsgType.Rx, this.RxRawData);

            this.SerialIODataReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>受信イベントを起こす</summary>
        protected void SetReceive(int length)
        {
            writeLog(MsgType.Rx, this.RxRawData, length);

            this.SerialIODataReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>受信イベントを起こす</summary>
        protected void SetReceive(string recvData)
        {
            writeLog(MsgType.Rx, recvData.Substring(0, recvData.Length - 1));

            this.RxRawData = Encoding.ASCII.GetBytes(recvData);

            this.SerialIODataReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>受信イベントを起こす</summary>
        protected void SetReceiveAscii(string recvData)
        {
            writeLog(recvData);

            this.SerialIODataReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>エラーイベントを起こす</summary>
        protected void SetError(MsgType type, string errorMessage)
        {
            StopReceiveTimeout();

            this.ErrorMessage = errorMessage;

            writeLog(type, errorMessage);

            this.SerialIOErrorReceived?.Invoke(this, new EventArgs());
        }

        /// <summary>受信タイムアウトイベントを起こす</summary>
        private void setTimeout()
        {
            this.ErrorMessage = "受信タイムアウト";

            writeLog(MsgType.RxMsg, this.ErrorMessage);

            this.SerialIOTimeoutReceived?.Invoke(this, new EventArgs());
        }
        #endregion

        #region WriteLog
        /// <summary>
        /// 通信ログにbyte配列データを16進表記で保存する
        /// </summary>
        /// <param name="type">MsgType</param>
        /// <param name="data">byte配列</param>
        /// <param name="length">通信ログ長(byte)指定無しはbyte配列長</param>
        private void writeLog(MsgType type, byte[] data, int length = -1)
        {
            if (length < 0) length = data.Length;
            string log = Util.ToString(data, 0, length);
            writeLog(type, log);
        }

        /// <summary>
        /// 通信ログに文字列を保存する
        /// </summary>
        /// <param name="type"></param>
        /// <param name="log"></param>
        private void writeLog(MsgType type, string log)
        {
            if (log.Last() == '\r')
            {
                log = log.Substring(0, log.Length - 1);
            }
            else if (log.Last() == '\n')
            {
                if (log[log.Length - 2] == '\r') log = log.Substring(0, log.Length - 2);
            }

            string writelog = $"{DateTime.Now:HH:mm:ss.fff} {type} {log}";

            if (this.enableWriteLog) this.fileLog.Write(this.FileLogPath, writelog); //ファイルに通信ログを書き込む

            this.SerialIOWriteLog?.Invoke(this, type, writelog);
        }

        /// <summary>
        /// 通信ログに文字列を保存する
        /// </summary>
        /// <param name="log"></param>
        private void writeLog(string log)
        {
            if (log.Last() == '\r')
            {
                log = log.Substring(0, log.Length - 1);
            }
            else if (log.Last() == '\n')
            {
                if (log[log.Length - 2] == '\r') log = log.Substring(0, log.Length - 2);
            }

            if (this.enableWriteLog) this.fileLog.Write(this.FileLogPath, log); //ファイルに通信ログを書き込む

            this.SerialIOWriteLog?.Invoke(this, MsgType.RxMsg, log);
        }
        #endregion
    }
}
