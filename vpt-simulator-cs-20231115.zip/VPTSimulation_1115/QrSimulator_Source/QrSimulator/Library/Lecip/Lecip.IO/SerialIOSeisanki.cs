﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace Lecip.IO
{
    /// <summary>
    /// <para>伊予鉄道精算機通信クラス(バイナリフォーマット)</para>
    /// <para>+---------+------+--------+-------------+---------+----------+------+-----+-----+---------+</para>
    /// <para>|STX(0x02)|IF種別|送信通番(2Byte Little)|サイズ(2Byte Little)|データ|サム1|サム2|ETX(0x03)|</para>
    /// <para>+---------+------+--------+-------------+---------+----------+------+-----+-----+---------+</para>
    /// </summary>
    public class SerialIOSeisanki : SerialIO
    {
        #region Field
        /// <summary>STX</summary>
        private readonly byte Stx = 0x02;
        /// <summary>ETX</summary>
        private readonly byte Etx = 0x03;
        /// <summary>STXサイズ</summary>
        private readonly int  StxSize    = 1;
        /// <summary>IF～SZサイズ</summary>
        private int           HeaderSize = 5;
        /// <summary>SUM1～ETXサイズ</summary>
        private readonly int  FooterSize = 3;
        /// <summary>最小サイズ(STX,IF,SQ,SQ,SZ,SZ,SUM1,SUM2,ETX)</summary>
        private readonly int  MinSize = 9;
        /// <summary>受信ステータス</summary>
        private enum rcvSts
        {
            Stx,
            Header,
            Data,
            Footer,
            Success,
            Fail,
        }
        /// <summary>送信コマンドバッファ</summary>
        private byte[] sendBuffer;
        #endregion

        #region Property
        /// <summary>送信データのI/F種別</summary>
        public byte TxIFType { get; private set; }
        /// <summary>受信データのI/F種別</summary>
        public byte RxIFType { get; private set; }
        /// <summary>受信データのデータ部</summary>
        public byte[] RxData { get; private set; }
        /// <summary>シーケンス番号</summary>
        public UInt16 SeqNo  { get; set; }

        #region Debug Property
        /// <summary>デバッグモード データサイズ異常</summary>
        public bool DebugSize { get; set; }
        /// <summary>デバッグモード シーケンス番号固定</summary>
        public bool DebugSeqNo { get; set; }
        /// <summary>デバッグモード データ部サム異常</summary>
        public bool DebugDataSum { get; set; }
        /// <summary>設定可能なデバッグモードを文字列配列で返すプロパティ</summary>
        public string[] DebugList { get { return new string[] { "通常", "データサイズ異常", "シーケンス番号固定", "データ部サム異常" }; } }
        /// <summary>
        /// デバッグモードを設定するプロパティ
        /// 0:通常(デバッグモード解除) / 1:データサイズ項目異常 / 2:シーケンス番号固定 / 3:データ部サム異常 </summary>
        public int DebugMode
        {
            set
            {
                this.DebugSize = this.DebugSeqNo = this.DebugDataSum = false;

                switch (value)
                {
                    case 0: break; //通常
                    case 1: this.DebugSize    = true; break; //データサイズ異常
                    case 2: this.DebugSeqNo   = true; break; //シーケンス番号固定
                    case 3: this.DebugDataSum = true; break; //データ部サム異常
                    default: break;
                }
            }
        }
        #endregion
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SerialIOSeisanki()
        {
            this.SeqNo = 0;
            this.DebugMode = 0;

            this.sendBuffer = new byte[65535];
        }
        #endregion

        #region Public Method
        /// <summary>
        /// 送信処理
        /// </summary>
        /// <param name="ifType">IF種別</param>
        /// <param name="data">送信コマンドデータ部</param>
        /// <param name="receiveTimeout">受信タイムアウト(指定無し時はReceiveTimeoutプロパティ)。-1の時はタイムアウト処理を行わない</param>
        public void Send(byte ifType, byte[] data, int receiveTimeout = 0)
        {
            UInt16 size     = (UInt16)((data != null) ? data.Length : 0);
            UInt16 dataSize = size;                     //データサイズ項目(データ部のサイズ)
            UInt16 sendSize = (UInt16)(MinSize + size); //データ送信総サイズ

            //STX
            sendBuffer[0] = Stx;
            //IF種別セット
            this.TxIFType = ifType;
            sendBuffer[1] = ifType;
            //SQセット(Little)
            sendBuffer[2] = (byte)(this.SeqNo & 0xFF);
            sendBuffer[3] = (byte)(this.SeqNo >> 8 & 0xFF);
            //サイズセット(Little)
            if (this.DebugSize) dataSize++;
            sendBuffer[4] = ((byte)(dataSize & 0xFF));
            sendBuffer[5] = ((byte)(dataSize >> 8 & 0xFF));
            //データセット
            if (size > 0) Array.Copy(data, 0, sendBuffer, 6, data.Length);
            //チェックサム(IF～データ部)
            byte sum1 = 0, sum2 = 0;
            calcCheckSum(sendBuffer, 1, sendSize - 4, ref sum1, ref sum2);
            if (this.DebugDataSum) sum1++;
            sendBuffer[6 + size] = sum1;
            sendBuffer[7 + size] = sum2;
            //ETX
            sendBuffer[8 + size] = Etx;

            //応答が必要なコマンドの場合、タイムアウト処理を開始(recevieTimeoutが0未満の場合、タイムアウト処理を行わない)
            if (receiveTimeout >= 0) base.StartReceiveTimeout();

            //送信
            base.Send(sendBuffer, sendSize);
        }
        #endregion

        #region Override
        /// <summary>
        /// シリアル通信受信イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void OnDataReceived(object sender, EventArgs e)
        {
            Stopwatch sw           = new Stopwatch();
            rcvSts    sts          = rcvSts.Stx; //受信ステータス
            int       reqSize      = 0;          //受信要求サイズ
            int       datSize      = 0;          //データ部サイズ
            string    errorMessage = string.Empty;

            if (!this.IsOpen) return;
            if (this.BytesToRead <= 0) return;

            //タイムアウト処理を停止
            base.StopReceiveTimeout();

            sw.Start();
            try
            {
                while (true)
                {
                    if (sw.ElapsedMilliseconds > this.Timeout)
                    {
                        errorMessage = "タイムアウトしました";
                        sts = rcvSts.Fail;
                        break;
                    }
                    if (!this.IsOpen)
                    {
                        errorMessage = "ポートが閉じられました";
                        sts = rcvSts.Fail;
                        break;
                    }

                    //受信データ数セット
                    switch (sts)
                    {
                        case rcvSts.Stx:    reqSize = StxSize;    break; //Stx      1Byte
                        case rcvSts.Header: reqSize = HeaderSize; break; //ヘッダ部 5Byte (IF～SZ)
                        case rcvSts.Data:   reqSize = datSize;    break; //データ部 可変(ヘッダデータから算出)
                        case rcvSts.Footer: reqSize = FooterSize; break; //フッタ部 3Byte (SUM1～ETX)
                    }
                    int bytesToRead = this.BytesToRead;
                    if (bytesToRead < reqSize) continue;

                    byte[] buff = null;
                    if (this.RecvBinary(ref buff, reqSize, this.Timeout) >= reqSize)
                    {
                        switch (sts)
                        {
                            case rcvSts.Stx:
                                //STX
                                if (buff[0] == Stx) sts = rcvSts.Header;
                                break;

                            case rcvSts.Header:
                                //IF種別
                                this.RxIFType = buff[0];
                                //送信通番
                                if (!this.DebugSeqNo) this.SeqNo = (UInt16)(buff[1] + buff[2] * 0x100);
                                //データ部サイズ取得
                                datSize = buff[3] + buff[4] * 0x100;
                                //受信データ格納
                                this.RxRawData = new byte[MinSize + datSize];
                                this.RxRawData[0] = Stx;
                                Array.Copy(buff, 0, this.RxRawData, 1, buff.Length);
                                sts = rcvSts.Data;
                                break;

                            case rcvSts.Data:
                                //データ部
                                this.RxData = buff;
                                //データ部格納
                                Array.Copy(buff, 0, this.RxRawData, 6, buff.Length);
                                sts = rcvSts.Footer;
                                break;

                            case rcvSts.Footer:
                                //チェックサム
                                Array.Copy(buff, 0, this.RxRawData, 6 + datSize, buff.Length);
                                byte sum1 = 0, sum2 = 0;
                                this.calcCheckSum(this.RxRawData, 1, this.RxRawData.Length - 4, ref sum1, ref sum2);
                                if (buff[0] != sum1 || buff[1] != sum2)
                                {
                                    errorMessage = "チェックサムエラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //ETX
                                if (buff[2] != Etx)
                                {
                                    errorMessage = "ETX受信エラー";
                                    sts = rcvSts.Fail;
                                    break;
                                }
                                //受信OKのためここで送信通番をインクリメントする
                                if (!this.DebugSeqNo) if (this.SeqNo == 0xFFFF) this.SeqNo = 0; else this.SeqNo++;

                                sts = rcvSts.Success;
                                break;
                        }
                    }

                    if (sts == rcvSts.Success || sts == rcvSts.Fail)
                    {
                        break;
                    }
                }

                if (sts == rcvSts.Fail)
                {
                    SetError(MsgType.RxMsg, errorMessage);
                }
                else if (sts == rcvSts.Success)
                {
                    SetReceive();
                }
            }
            catch (IOException ioex)
            {
                SetError(MsgType.RxMsg, ioex.Message);
            }
        }
        #endregion

        #region Private Method
        /// <summary>
        /// SZSUMを計算する
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private byte calcSzSum(List<byte> data)
        {
            return (byte)((0x100 - data[0] - data[1] - data[2]) & 0xFF);
        }

        private byte calcSzSum(byte[] data)
        {
            return (byte)((0x100 - data[1] - data[2] - data[3]) & 0xFF);
        }
        /// <summary>
        /// チェックサムを計算してSUM1,SUM2を求める
        /// </summary>
        /// <param name="data"></param>
        /// <param name="sum1"></param>
        /// <param name="sum2"></param>
        private void calcCheckSum(byte[] data, ref byte sum1, ref byte sum2)
        {
            int sum = 0;
            foreach (byte d in data)
            {
                sum += d;
            }

            sum1 = (byte)(sum & 0xFF);
            sum2 = (byte)((~sum1) & 0xFF);
        }
        /// <summary>
        /// チェックサムを計算してSUM1,SUM2を求める
        /// </summary>
        /// <param name="data"></param>
        /// <param name="start"></param>
        /// <param name="length"></param>
        /// <param name="sum1"></param>
        /// <param name="sum2"></param>
        private void calcCheckSum(List<byte> data, int start, int length, ref byte sum1, ref byte sum2)
        {
            int sum = 0;
            for (int i = 0; i < length; i++)
            {
                sum += data[start + i];
            }

            sum1 = (byte)(sum & 0xFF);
            sum2 = (byte)((~sum1) & 0xFF);
        }
        /// <summary>
        /// チェックサムを計算してSUM1,SUM2を求める
        /// </summary>
        /// <param name="data"></param>
        /// <param name="start"></param>
        /// <param name="length"></param>
        /// <param name="sum1"></param>
        /// <param name="sum2"></param>
        private void calcCheckSum(byte[] data, int start, int length, ref byte sum1, ref byte sum2)
        {
            int sum = 0;
            for (int i = 0; i < length; i++)
            {
                sum += data[start + i];
            }

            sum1 = (byte)(sum & 0xFF);
            sum2 = (byte)((~sum1) & 0xFF);
        }
        #endregion
    }
}
