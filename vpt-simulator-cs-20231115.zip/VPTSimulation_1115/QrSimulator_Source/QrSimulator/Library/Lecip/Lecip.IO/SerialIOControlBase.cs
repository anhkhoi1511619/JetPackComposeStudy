﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.IO
{
    /// <summary>
    /// シリアル通信を行うコントロールクラス
    /// </summary>
    public class SerialIOControlBase : Control
    {
        #region Event Handler
        /// <summary> データ受信時のイベントハンドラー </summary>
        public event EventHandler DataReceived;

        /// <summary> エラー発生時のイベントハンドラー </summary>
        public event EventHandler ErrorReceived;

        /// <summary> 受信タイムアウト発生時のイベントハンドラー </summary>
        public event EventHandler TimeoutReceived;
        #endregion

        #region Property
        /// <summary> True: ポートオープン中 False:ポートクローズ中 </summary>
        public bool IsOpen { get { return this.serial.IsOpen; } }

        /// <summary> Settingsプロパティ MSCOMMコントロールのSettingsと同じ手法で設定する </summary>
        public string Settings
        {
            get { return this.serial.Settings;  }
            set { this.serial.Settings = value; }
        }

        /// <summary> ポート番号を設定・取得する </summary>
        public string PortName
        {
            get { return this.serial.PortName;  }
            set { this.serial.PortName = value; }
        }

        /// <summary> 受信タイムアウト(msec) </summary>
        public int Timeout
        {
            get { return this.serial.Timeout;  }
            set { this.serial.Timeout = value; }
        }

        /// <summary> 通信ログをテキストファイルに保存するかしないかの設定 </summary>
        public bool EnableWriteLog
        {
            get { return this.serial.EnableWriteLog; }
            set { this.serial.EnableWriteLog = value; }
        }
        /// <summary> 通信ログのファイルパス </summary>
        public string FileLogPath
        {
            get { return this.serial.FileLogPath; }
            set { this.serial.FileLogPath = value; }
        }

        /// <summary> シミュレータの状態を文字列で返す </summary>
        public string PortStatus { get { return string.Format("{0}:{1} ({2})", this.PortName, this.IsOpen ? "Open" : "Close", this.Settings); } }

        /// <summary> エラーメッセージを返す </summary>
        public string ErrorMessage
        {
            get
            {
                return this.serial.ErrorMessage;
            }
        }
        /// <summary> シリアル通信コンポーネント </summary>
        public SerialIO Serial
        {
            get { return this.serial; }
        }
        #endregion

        #region Field
        private SerialIO serial;
        #endregion

        #region Constructor
        /// <summary>
        /// SerialIOControlBaseクラスの新しいインスタンスを初期化します
        /// </summary>
        /// <param name="serialIO">シリアル通信クラス</param>
        /// <param name="multiline">通信表示を複数行モードで行うか単行で行うかの設定</param>
        public SerialIOControlBase(SerialIO serialIO, TextBoxLog.MulitlineMode multiline = TextBoxLog.MulitlineMode.Single)
        {
            TextBoxLog textLog = new TextBoxLog(multiline) { Dock = DockStyle.Fill };
            this.Controls.Add(textLog);

            this.serial = serialIO;
            this.serial.SerialIOWriteLog        += (sender, type, log) => { textLog.UpdateLog(type, log); };
            this.serial.SerialIODataReceived    += (sender, e) => { if (this.DataReceived != null) base.Invoke(this.DataReceived, sender, e); };
            this.serial.SerialIOErrorReceived   += (sender, e) => { if (this.ErrorReceived != null) base.Invoke(this.ErrorReceived, sender, e); };
            this.serial.SerialIOTimeoutReceived += (sender, e) => { if (this.TimeoutReceived != null) base.Invoke(this.TimeoutReceived, sender, e); };
        }
        #endregion

        #region Public Method
        /// <summary>
        /// ポートをオープンする
        /// </summary>
        public void Open()
        {
            this.serial.Open();
        }

        /// <summary>
        /// ポートをクローズする
        /// </summary>
        public void Close()
        {
            this.serial.Close();
        }
        
        /// <summary>
        /// 受信タイムアウト処理を開始する
        /// </summary>
        public void StartReceiveTimeout()
        {
            this.serial.StartReceiveTimeout();
        }

        /// <summary>
        /// 受信タイムアウト処理を停止する
        /// </summary>
        public void StopReceiveTimeout()
        {
            this.serial.StopReceiveTimeout();
        }
        #endregion
    }
}
