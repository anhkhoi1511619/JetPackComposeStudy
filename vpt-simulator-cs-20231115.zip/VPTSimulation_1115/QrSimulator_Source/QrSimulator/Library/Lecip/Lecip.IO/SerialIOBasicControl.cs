﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lecip.IO
{
    /// <summary>
    /// シリアル通信を行うコントロールクラス
    /// SerialIOBasic()使用
    /// </summary>
    public class SerialIOBasicControl : SerialIOControlBase
    {
        #region Property
        /// <summary>通信モード</summary>
        public SerialIOBasic.Connection ConnectionMode
        {
            get { return ((SerialIOBasic)this.Serial).ConnectionMode; }
            set { ((SerialIOBasic)this.Serial).ConnectionMode = value; }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// SerialIOBinaryControlクラスの新しいインスタンスを初期化します
        /// </summary>
        /// <param name="multiline">通信表示を複数行モードで行うか単行で行うかの設定</param>
        public SerialIOBasicControl(TextBoxLog.MulitlineMode multiline) : base(new SerialIOBasic(), multiline)
        {

        }
        #endregion

        #region Public Method
        /// <summary>
        /// コマンド送信
        /// </summary>
        /// <param name="data">送信データ</param>
        public void Send(byte[] data)
        {
            ((SerialIOBasic)this.Serial).Send(data);
        }

        /// <summary>
        /// コマンド送信
        /// </summary>
        /// <param name="data">送信データ</param>
        public void Send(string data)
        {
            ((SerialIOBasic)this.Serial).Send(data);
        }
        #endregion
    }
}
