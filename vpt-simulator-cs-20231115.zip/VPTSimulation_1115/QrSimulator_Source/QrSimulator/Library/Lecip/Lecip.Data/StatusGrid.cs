﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;

namespace Lecip.Data
{
    /// <summary>
    /// ステータス(1byte)の各ビットの状態を表示・設定可能なDataGridView
    /// 対象のステータスオブジェクトをInit()の引数で指定する
    /// StatusGridとステータスオブジェクトがバインドされているので
    /// ステータスオブジェクトにアクセスすればOK
    /// 
    /// 高さ:19pixel x 行数 + 2 + 20
    /// </summary>
    public class StatusGrid : DataGridView
    {
        /// <summary>
        /// 初期化処理
        /// </summary>
        /// <param name="status">対象ステータスオブジェクト</param>
        public void Init(StatusBase status)
        {
            this.ColumnHeadersVisible = true;
            this.RowHeadersVisible = false;
            this.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.RowTemplate.Height = 19;
            this.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            this.AutoGenerateColumns = false;

            this.AllowUserToAddRows = false;
            this.AllowUserToDeleteRows = false;
            this.AllowUserToOrderColumns = false;
            this.AllowUserToResizeColumns = false;
            this.AllowUserToResizeRows = false;
            
            var col = new DataGridViewTextBoxColumn();
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            col.DefaultCellStyle.BackColor = SystemColors.Control;
            col.SortMode = DataGridViewColumnSortMode.NotSortable;
            col.DataPropertyName = "Name";
            col.ReadOnly = true;
            this.Columns.Add(col);

            var chk = new DataGridViewCheckBoxColumn();
            chk.DataPropertyName = "OnOff";
            chk.Width = 20;
            chk.TrueValue = true;
            chk.FalseValue = false;
            chk.ReadOnly = status.ReadOnly;
            this.Columns.Add(chk);

            col = new DataGridViewTextBoxColumn();
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            col.SortMode = DataGridViewColumnSortMode.NotSortable;
            col.DataPropertyName = "Text";
            col.ReadOnly = true;
            this.Columns.Add(col);

            setStatusName(status);

            this.CurrentCellDirtyStateChanged += this.currentCellDirtyStateChanged;
            this.CellPainting += cellPainting;
            status.ListChanged += new ListChangedEventHandler(listChanged);

            this.DataSource = status;
            //this.Enabled = !status.ReadOnly;
        }

        /// <summary>
        /// ステータスが更新されたらステータスの16進値を更新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listChanged(object sender, ListChangedEventArgs e)
        {
            if (e.PropertyDescriptor.Name == "OnOff")
            {
                setStatusValue((StatusBase)sender);
            }
        }

        /// <summary>
        /// セルを即更新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void currentCellDirtyStateChanged(object sender, EventArgs e)
        {
            StatusGrid dgv = (StatusGrid)sender;

            if (dgv.CurrentCellAddress.X == 1 && dgv.IsCurrentCellDirty)
            {
                dgv.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        /// <summary>
        /// チェックボックスがONOFFされたときに1行選択の切り替え
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            StatusGrid dgv = (StatusGrid)sender;
            var row = e.RowIndex;
            var col = e.ColumnIndex;

            if (col == 1 && row >= 0)
            {
                var cell = dgv[col, row] as DataGridViewCheckBoxCell;

                dgv.Rows[row].Selected = (bool)cell.Value;
            }
        }

        /// <summary>
        /// ステータスの名称と現在の値を列ヘッダーに表示
        /// </summary>
        private void setStatusName(StatusBase status)
        {
            this.Columns[0].HeaderCell.Value = status.Name;
            setStatusValue(status);
        }

        /// <summary>
        /// ステータスの現在の値を列ヘッダーに表示
        /// </summary>
        /// <param name="status"></param>
        private void setStatusValue(StatusBase status)
        {
            this.Columns[2].HeaderCell.Value = status.GetString() + "h";
        }
    }
}
