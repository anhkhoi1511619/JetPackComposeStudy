﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;
using System.Data;
using System.ComponentModel;

namespace Lecip.Data
{
    /// <summary>
    /// データアイテムの状態を表示・設定可能なDataGridView
    /// 対象のデータアイテムリストをInit()の引数で指定する
    /// DataItemGridとデータアイテムオブジェクトがバインドされているので
    /// データアイテムオブジェクトにアクセスすればOK
    /// 
    /// 高さ:17pixel x 行数 + 3pixel
    /// </summary>
    public class DataItemGrid : DataGridView
    {
        /// <summary>コンボボックスセル使用不使用フラグ</summary>
        private bool useCombo = true;

        /// <summary>
        /// 処理化処理
        /// データソース(データアイテムリスト)を渡す
        /// useCombo=trueにするとコンボボックスセルに切替わるがコンボリストの値しか入力できない
        /// 任意の値を入力したい場合はuseCombo=falseにする
        /// </summary>
        /// <param name="dataSource">対象のデータソース(DataItemListBase)</param>
        /// <param name="useCombo">コンボボックスセル使用不使用フラグ(指定なし=使用)</param>
        public void Init(DataItemListBase dataSource, bool useCombo = true)
        {
            this.ColumnHeadersVisible = false;
            this.RowHeadersVisible = false;
            this.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.RowTemplate.Height = 17;
            //this.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            this.AutoGenerateColumns = false;
            this.DefaultCellStyle.NullValue = string.Empty;
            this.DefaultCellStyle.DataSourceNullValue = string.Empty;

            this.AllowUserToAddRows = false;
            this.AllowUserToDeleteRows = false;
            this.AllowUserToOrderColumns = false;
            //this.AllowUserToResizeColumns = false;
            this.AllowUserToResizeRows = false;

            var col = new DataGridViewTextBoxColumn();
            //col.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            col.DefaultCellStyle.BackColor = SystemColors.Control;
            col.SortMode = DataGridViewColumnSortMode.NotSortable;
            col.DataPropertyName = "Name";

            col.Width = 135;

            col.ReadOnly = true;
            this.Columns.Add(col);

            col = new DataGridViewTextBoxColumn();
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            col.SortMode = DataGridViewColumnSortMode.NotSortable;
            col.DataPropertyName = "Text";
            col.ReadOnly = dataSource.ReadOnly;
            this.Columns.Add(col);

            this.useCombo = useCombo;
            this.DataMember = null;
            this.DataSource = dataSource;
            dataSource.ListChanged += dataSource_ListChanged;

            if (useCombo)
            {
                dataSource.MatchItem = false; //コンボを使うときはマッチングをさせない
            }
        }

        /// <summary>
        /// 1Bitタイプのデータアイテムが切り替わったときに選択状態を切り替える
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataSource_ListChanged(object sender, ListChangedEventArgs e)
        {
            if (e.ListChangedType == ListChangedType.ItemChanged && e.PropertyDescriptor.Name == "Text")
            {
                DataItemListBase bindingList = (DataItemListBase)sender;

                var dataItem = bindingList[e.NewIndex] as DataItem;

                if (dataItem.Bit != BIT.NO && dataItem.BitLength == 1)
                {
                    if (!string.IsNullOrEmpty(dataItem.Text))
                    {
                        if (dataItem.Text[0] == '1')
                        {
                            foreach (DataGridViewCell cell in this.Rows[e.NewIndex].Cells)
                            {
                                cell.Style.ForeColor = this.DefaultCellStyle.SelectionForeColor;
                                cell.Style.BackColor = this.DefaultCellStyle.SelectionBackColor;
                            }
                        }
                        else if (dataItem.Text[0] == '0')
                        {
                            for (int i = 0; i < this.Columns.Count; i++)
                            {
                                DataGridViewCell cell = this.Rows[e.NewIndex].Cells[i];
                                cell.Style.ForeColor = this.Columns[i].DefaultCellStyle.ForeColor;
                                cell.Style.BackColor = this.Columns[i].DefaultCellStyle.BackColor;
                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < this.Columns.Count; i++)
                        {
                            DataGridViewCell cell = this.Rows[e.NewIndex].Cells[i];
                            cell.Style.ForeColor = this.Columns[i].DefaultCellStyle.ForeColor;
                            cell.Style.BackColor = this.Columns[i].DefaultCellStyle.BackColor;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// バインドがリセットされたら、コンボセルに切り替える
        /// コンボセル不使用モード時は切り替えない
        /// セル入力可  : ReadOnly=falseの時のみコンボセルに切り替える
        /// セル入力不可: ReadOnly=trueの時は通常セル
        /// </summary>
        /// <param name="e"></param>
        protected override void OnDataBindingComplete(DataGridViewBindingCompleteEventArgs e)
        {
            if (e.ListChangedType == ListChangedType.Reset)
            {
                if (!this.useCombo) return;

                DataItemListBase dataSource = (DataItemListBase)this.DataSource;
                if (dataSource.ReadOnly) return;

                for (int i = 0; i < dataSource.Count; i++)
                {
                    setComboBoxCell(i, dataSource[i]);
                }
            }
        }
        
        /// <summary>
        /// コンボセルに一覧に無い値がセットされたらエラーが発生するため、一覧に追加しエラーを回避
        /// </summary>
        /// <param name="displayErrorDialogIfNoHandler"></param>
        /// <param name="e"></param>
        protected override void OnDataError(bool displayErrorDialogIfNoHandler, DataGridViewDataErrorEventArgs e)
        {
            if (e.Exception != null)
            {
                //MessageBox.Show(this,
                //    string.Format("({0}列, {1}行) のセルでエラーが発生しました。\n\n説明: {2}",
                //    e.ColumnIndex, e.RowIndex, e.Exception.Message),
                //    "エラーが発生しました",
                //    MessageBoxButtons.OK, MessageBoxIcon.Error);
                addCboItem(e.RowIndex, e.ColumnIndex);
                e.Cancel = true;
            }
        }
        
        /// <summary>
        /// 表示文字列リストがある項目についてはコンボボックスセルに切り替える
        /// </summary>
        /// <param name="rowIndex"></param>
        /// <param name="item"></param>
        private void setComboBoxCell(int rowIndex, DataItem item)
        {
            //表示リストが無い場合は終了
            if (item.ItemTable == null) return;

            //元々のセル文字列が一覧に無い場合、追加(エラー発生防止)
            string v = (string)this[1, rowIndex].Value;
            addCboItem(item.ItemTable, "Value", v);

            //コンボボックスセルを生成して該当セルに設定
            DataGridViewComboBoxCell cbo = new DataGridViewComboBoxCell();
            cbo.DisplayStyle  = DataGridViewComboBoxDisplayStyle.Nothing;
            cbo.ValueMember   = "Value";
            cbo.DisplayMember = "Display";
            cbo.DataSource    = item.ItemTable;
            this[1, rowIndex] = cbo;
        }

        /// <summary>
        /// コンボボックスセルのリスト一覧に引数の文字列が無い場合、追加する
        /// </summary>
        /// <param name="rowIndex"></param>
        /// <param name="colIndex"></param>
        private void addCboItem(int rowIndex, int colIndex)
        {
            DataGridViewCell cell = this[colIndex, rowIndex];
            if (!(cell is DataGridViewComboBoxCell)) return;

            var cbo = (DataGridViewComboBoxCell)cell;
            string v = (string)cbo.Value;

            addCboItem((DataTable)cbo.DataSource, "Display", v);
            this.UpdateCellValue(colIndex, rowIndex);
        }

        /// <summary>
        /// コンボボックスセルのリスト一覧に引数の文字列が無い場合、追加する
        /// </summary>
        /// <param name="dt">DataTable</param>
        /// <param name="colName">カラム名称</param>
        /// <param name="v">対象文字列</param>
        private void addCboItem(DataTable dt, string colName, string v)
        {
            if (dt == null) return;
            if (string.IsNullOrEmpty(v)) return;

            var selected = dt.Select(colName + " = '" + v + "'");
            if (selected.Length <= 0) dt.Rows.Add(v, v);
        }
    }
}
