﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lecip.Data
{
    /// <summary>
    /// DataGridViewのRowHeaderに三角マークを表示させないための処理
    /// </summary>
    class DataGridViewRowHeaderCellEx : DataGridViewRowHeaderCell
    {
        protected override void Paint(System.Drawing.Graphics graphics, System.Drawing.Rectangle clipBounds, System.Drawing.Rectangle cellBounds, int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue, string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle advancedBorderStyle, DataGridViewPaintParts paintParts)
        {
            base.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue, errorText, cellStyle, advancedBorderStyle, 
                paintParts & ~DataGridViewPaintParts.ContentBackground);
        }
    }
}
