﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Data;
using Lecip.Utility;

namespace Lecip.Data
{
    #region enum DataType
    /// <summary>
    /// データタイプの定義
    /// </summary>
    public enum DataType
    {
        /// <summary>
        /// 10進
        /// </summary>
        Dec,
        /// <summary>
        /// 16進
        /// </summary>
        Hex,
        /// <summary>
        /// BCD
        /// </summary>
        Bcd,
        /// <summary>
        /// 文字列(SJIS変換)
        /// </summary>
        Str,
        /// <summary>
        /// アスキーコード(未使用)
        /// </summary>
        ///Ascii,
        /// <summary>
        /// 1ビット
        /// </summary>
        Bit,
        /// <summary>
        /// 複数ビット(4ビットなど)
        /// </summary>
        ///Bits,
        /// <summary>
        /// 日付
        /// </summary>
        CJRCDate,
        /// <summary>
        /// 符号付 10進
        /// </summary>
        SDec,
        /// <summary>
        /// 文字列(変換なし)
        /// </summary>
        Text,
        /// <summary>
        /// サム計算
        /// </summary>
        Sum,
    }
    #endregion

    #region enum BIT
    /// <summary>
    /// BITの列挙型
    ///     数値にcastする場合は(byte)BIT.B0 または(UInt16)BIT.B15とする
    ///     文字列にする場合はBIT.B0.ToString()とする
    /// </summary>
    public enum BIT : uint
    {
        /// <summary>
        /// Bit31 = 0x80000000
        /// </summary>
        B31 = 0x80000000,
        /// <summary>
        /// Bit30 = 0x40000000
        /// </summary>
        B30 = 0x40000000,
        /// <summary>
        /// Bit29 = 0x20000000
        /// </summary>
        B29 = 0x20000000,
        /// <summary>
        /// Bit28 = 0x10000000
        /// </summary>
        B28 = 0x10000000,
        /// <summary>
        /// Bit27 = 0x8000000
        /// </summary>
        B27 = 0x8000000,
        /// <summary>
        /// Bit26 = 0x4000000
        /// </summary>
        B26 = 0x4000000,
        /// <summary>
        /// Bit25 = 0x2000000
        /// </summary>
        B25 = 0x2000000,
        /// <summary>
        /// Bit24 = 0x1000000
        /// </summary>
        B24 = 0x1000000,
        /// <summary>
        /// Bit23 = 0x800000
        /// </summary>
        B23 = 0x800000,
        /// <summary>
        /// Bit22 = 0x400000
        /// </summary>
        B22 = 0x400000,
        /// <summary>
        /// Bit21 = 0x200000
        /// </summary>
        B21 = 0x200000,
        /// <summary>
        /// Bit20 = 0x100000
        /// </summary>
        B20 = 0x100000,
        /// <summary>
        /// Bit19 = 0x80000
        /// </summary>
        B19 = 0x80000,
        /// <summary>
        /// Bit18 = 0x40000
        /// </summary>
        B18 = 0x40000,
        /// <summary>
        /// Bit17 = 0x20000
        /// </summary>
        B17 = 0x20000,
        /// <summary>
        /// Bit16 = 0x10000
        /// </summary>
        B16 = 0x10000,
        /// <summary>
        /// Bit15=0x8000
        /// </summary>
        B15 = 0x8000,
        /// <summary>
        /// Bit14=0x4000
        /// </summary>
        B14 = 0x4000,
        /// <summary>
        /// Bit13=0x2000
        /// </summary>
        B13 = 0x2000,
        /// <summary>
        /// Bit12=0x1000
        /// </summary>
        B12 = 0x1000,
        /// <summary>
        /// Bit11=0x0800
        /// </summary>
        B11 = 0x0800,
        /// <summary>
        /// Bit10=0x0400
        /// </summary>
        B10 = 0x0400,
        /// <summary>
        /// Bit9=0x0200
        /// </summary>
        B9 = 0x0200,
        /// <summary>
        /// Bit8=0x0100
        /// </summary>
        B8 = 0x0100,
        /// <summary>
        /// Bit7=0x80
        /// </summary>
        B7 = 0x80,
        /// <summary>
        /// Bit6=0x40
        /// </summary>
        B6 = 0x40,
        /// <summary>
        /// Bit5=0x20
        /// </summary>
        B5 = 0x20,
        /// <summary>
        /// Bit4=0x10
        /// </summary>
        B4 = 0x10,
        /// <summary>
        /// Bit3=0x08
        /// </summary>
        B3 = 0x08,
        /// <summary>
        /// Bit2=0x04
        /// </summary>
        B2 = 0x04,
        /// <summary>
        /// Bit1=0x02
        /// </summary>
        B1 = 0x02,
        /// <summary>
        /// Bit0=0x01
        /// </summary>
        B0 = 0x01,
        /// <summary>
        /// BITでは無い
        /// </summary>
        NO = 0x00,
    };
    #endregion

    #region Endian
    /// <summary>
    /// エンディアン指定
    /// </summary>
    public static class Endian
    {
        /// <summary>
        /// リトルエンディアン
        /// </summary>
        public static readonly bool Little = true;
        /// <summary>
        /// ビッグエンディアン
        /// </summary>
        public static readonly bool Big = false;
    }
    #endregion

    #region DataItem
    /// <summary>
    /// データアイテムクラス
    /// Lecip.Data, Lecip, Lecip.Utilityを参照に追加してください
    /// </summary>
    public class DataItem : NotifyPropertyChange
    {
        #region プロパティ
        /// <summary>データアイテムの項目名称</summary>
        public string Name { get; private set; }

        /// <summary>通信時のデータ種別(Dec,Hex,Str)</summary>
        public DataType DataType { get; private set; }

        /// <summary>エンディアン</summary>
        public bool Endian { get; private set; }

        /// <summary>データ長(バイトサイズ)</summary>
        public int DataLength { get; private set; }

        /// <summary>アドレス</summary>
        public int Index { get; private set; }

        /// <summary>ビット長</summary>
        public int BitLength { get; private set; }
        
        /// <summary>ビット設定時の先頭ビット(バイト単位の時はNOを設定)</summary>
        public BIT Bit { get; private set; }

        /// <summary>表示文字列リスト(「値:表示文字列」の書式</summary>
        public string[] Items { get; private set; }

        /// <summary>
        /// データアイテムの表示データ
        /// </summary>
        public string Text
        {   
            get
            {
                return this.text;
            }
            set
            {
                if (this.text != value)
                {
                    //this.text = value;
                    //if (!string.IsNullOrEmpty(this.text) && (Util.IsNumeric(this.text) || Util.IsHexadecimal(this.text)))
                    //{
                    //    if ((this.DataType == DataType.Hex || this.DataType == DataType.Bcd) && this.Bit == BIT.NO && this.DataLength > 0)
                    //    {
                    //        //Byte単位でのHex,Bcdのときはゼロパディングする
                    //        this.text = Util.FmtStr(this.text, this.DataLength * 2);
                    //        if (this.text.Length > this.DataLength * 2) this.text = this.text.Substring(0, this.DataLength * 2);
                    //    }
                    //    else if (this.DataType == DataType.Bit)
                    //    {
                    //        //BitのときはBit長でゼロパディングする(Bit長以上のときは長さを合わせる)
                    //        int bitLength = (this.BitLength > 0) ? this.BitLength : this.DataLength * 8;
                    //        this.text = Util.FmtStr(this.text, bitLength);
                    //        if (this.text.Length > bitLength) this.text = this.text.Substring(0, bitLength);
                    //    }
                    //}
                    if (string.IsNullOrEmpty(value))
                    {
                        this.text = value;
                    }
                    else if (value.IndexOf(':') > 0)
                    {
                        this.text = value;
                    }
                    else
                    {
                        //入力チェック
                        if ((this.DataType == DataType.Hex || this.DataType == DataType.Bcd || this.DataType == DataType.Bit) && !Util.IsHexadecimal(value))
                        {
                            return; //Hex,Bcd,Bitで16進文字列で無い時は更新しない
                        }
                        if ((this.DataType == DataType.Dec) && !Util.IsNumeric(value))
                        {
                            return; //Decで10進文字列で無い時は更新しない
                        }
                        if ((this.DataType == DataType.Dec) && Util.IsNumeric(value))
                        {
                            long max = (long)Math.Pow(0x100, this.DataLength) - 1;

                            if (Convert.ToInt64(value) > max) return; //Decで指定数値以上の値の時は更新しない
                        }
                        if ((this.DataType == DataType.Str) && this.DataLength > 0)
                        {
                            byte[] sjisCode = Encoding.GetEncoding("Shift_JIS").GetBytes(value);

                            if (sjisCode.Length > this.DataLength)
                            {
                                return; //Str(SJISコード変換)で指定サイズ以上の時は更新しない
                            }
                        }

                        this.text = value;

                        if ((this.DataType == DataType.Hex || this.DataType == DataType.Bcd) && (this.Bit == BIT.NO) && (this.DataLength > 0))
                        {
                            //16進数表示
                            //Byte単位でのHex,Bcdのときはゼロパディングする
                            this.text = Util.FmtStr(this.text, this.DataLength * 2);
                            if (this.text.Length > this.DataLength * 2) this.text = this.text.Substring(0, this.DataLength * 2);
                        }
                        else if ((this.DataType == DataType.Hex && this.Bit != BIT.NO))
                        {
                            //16進数表示(8bitに満たない場合)
                            int padLength = (this.BitLength + 3) / 4;
                            this.text = Util.FmtStr(this.text, padLength);
                        }
                        else if (this.DataType == DataType.Bit)
                        {
                            //2進数表示
                            //BitのときはBit長でゼロパディングする(Bit長以上のときは長さを合わせる)
                            int bitLength = (this.BitLength > 0) ? this.BitLength : this.DataLength * 8;
                            this.text = Util.FmtStr(this.text, bitLength);
                            if (this.text.Length > bitLength) this.text = this.text.Substring(0, bitLength);
                        }
                    }
                    NotifyPropertyChanged("Text"); //更新イベントを起こす
                }
            }
        }

        /// <summary>
        /// コメント
        /// </summary>
        public string Comment
        {
            get
            {
                return this.comment;
            }
            set
            {
                if (this.comment != value)
                {
                    this.comment = value;
                    NotifyPropertyChanged("Comment"); //更新イベントを起こす
                }
            }
        }

        /// <summary>
        /// SetStringメソッドでセットされた16進文字列
        /// </summary>
        public string SetValue
        {
            get
            {
                return this.setValue;
            }
            set
            {
                if (this.setValue != value)
                {
                    this.setValue = value;
                    NotifyPropertyChanged("SetValue"); //更新イベントを起こす
                }
            }
        }

        /// <summary>
        /// 表示文字列リストのデータテーブル(取得のみ、設定不可)
        /// コンボボックスセル使用時にDataSourceとなる
        /// 無ければnullを返す
        /// </summary>
        public DataTable ItemTable { get { return this.itemTable; } }

        /// <summary>
        /// 表示文字列リストとマッチングの実行フラグ(true:実行する false:実行しない)
        /// </summary>
        public bool MatchItem { get; set; }

        /// <summary>
        /// 表示文字列リストとのマッチング結果表示
        /// </summary>
        public string MatchText { get { return this.matchText; }  set { this.matchText = value; } }

        #endregion

        #region フィールド
        /// <summary>データアイテムの表示データ</summary>
        private string text;

        /// <summary>コメント</summary>
        private string comment;

        /// <summary>SetStringメソッドでセットされた16進文字列</summary>
        private string setValue;

        /// <summary>一致テキスト</summary>
        private string matchText;

        /// <summary>表示文字列リストのデータテーブル</summary>
        private DataTable      itemTable;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public DataItem()
        {
            this.Name       = string.Empty;
            this.DataType   = DataType.Hex;
            this.Endian     = Lecip.Data.Endian.Big;
            this.Index      = 0;
            this.DataLength = 0;
            this.BitLength  = 0;
            this.Bit        = BIT.NO;
            this.Items      = null;
            this.itemTable  = null;
            this.text       = string.Empty;
            this.comment    = string.Empty;
            this.setValue   = "0";
            this.matchText  = string.Empty;
            this.MatchItem  = true;
        }

        /// <summary>
        /// DataItemのコンストラクタ(Bit指定が無い場合)
        /// </summary>
        /// <param name="name">名称</param>
        /// <param name="dataType">データ種別</param>
        /// <param name="endian">エンディアン(リトル=true ビッグ=false)</param>
        /// <param name="index">データ送受信時の該当データ位置</param>
        /// <param name="length">データ長(ASCII通信の場合は「桁数/2」を指定すること)</param>
        public DataItem(string name, DataType dataType, bool endian, int index, int length) : this()
        {
            this.Name         = name;
            this.DataType     = dataType;
            this.Endian       = endian;
            this.Index        = index;
            this.DataLength   = length;
        }

        /// <summary>
        /// DataItemのコンストラクタ(Bit指定が無い場合)
        ///     表示文字列リストがある場合
        /// </summary>
        /// <param name="name">名称</param>
        /// <param name="dataType">データ種別</param>
        /// <param name="endian">エンディアン(リトル=true ビッグ=false)</param>
        /// <param name="index">データ送受信時の該当データ位置</param>
        /// <param name="length">データ長(ASCII通信の場合は「桁数/2」を指定すること)</param>
        /// <param name="items">表示文字列リスト(設定例 "00:大人", "01:小児")</param>
        public DataItem(string name, DataType dataType, bool endian, int index, int length, string[] items) : this()
        {
            this.Name         = name;
            this.DataType     = dataType;
            this.Endian       = endian;
            this.Index        = index;
            this.DataLength   = length;
            this.Items        = items;
            if (items != null) this.comment = string.Join(" ", items);

            setItemTable();
        }

        /// <summary>
        /// DataItemのコンストラクタ(1bitデータの指定の場合)
        /// </summary>
        /// <param name="name">名称</param>
        /// <param name="dataType">通信時のデータ種別=DataType.Hex固定</param>
        /// <param name="endian">エンディアン=Endian.Big固定</param>
        /// <param name="index">データ送受信時の該当データ位置</param>
        /// <param name="length">データ長(1固定)</param>
        /// <param name="bit">ビット列挙型</param>
        /// <param name="offText">OFF(=0)時の表示テキスト</param>
        /// <param name="onText">ON(=1)時の表示テキスト</param>
        public DataItem(string name, DataType dataType, bool endian, int index, int length, 
                        BIT bit, string offText, string onText) : this()
        {
            this.Name         = name;
            this.DataType     = dataType;
            this.Endian       = endian;
            this.Index        = index;
            this.DataLength   = length;
            this.BitLength    = 1;
            this.Bit          = bit;
            this.Items        = new string[] { offText, onText };
            this.comment      = offText + " " + onText;

            setItemTable();
        }

        /// <summary>
        /// DataItemのコンストラクタ(全部指定)
        /// </summary>
        /// <param name="name">名称</param>
        /// <param name="dataType">通信時のデータ種別=DataType.Hex固定</param>
        /// <param name="endian">エンディアン=Endian.Big固定</param>
        /// <param name="index">データ送受信時の該当データ位置</param>
        /// <param name="length">データ長(ASCII通信の場合は「桁数/2」を指定すること)</param>
        /// <param name="bitLength">ビット長</param>
        /// <param name="bit">ビット列挙型</param>
        /// <param name="comment">コメント</param>
        /// <param name="items">表示文字列リスト(設定例 "0:大人", "1:小児")</param>
        public DataItem(string name, DataType dataType, bool endian, int index, int length, 
                        int bitLength, BIT bit, string comment, string[] items) : this()
        {
            this.Name         = name;
            this.DataType     = dataType;
            this.Endian       = endian;
            this.Index        = index;
            this.DataLength   = length;
            this.BitLength    = bitLength; if (bit != BIT.NO && this.BitLength == 0) this.BitLength = 1;
            this.Bit          = bit;
            this.comment      = comment;
            this.Items        = items;
            if (items != null) this.comment += " " + string.Join(" ", items);

            setItemTable();
        }
        #endregion

        #region public method
        #region データ設定系
        /// <summary>
        /// 文字列型で受信データをセット
        /// </summary>
        /// <param name="value"></param>
        public void SetString(string value)
        {
            int index  = (this.DataType != DataType.Text) ? this.Index * 2 : this.Index;           //開始位置 
            int length = (this.DataType != DataType.Text) ? this.DataLength * 2 : this.DataLength; //データ長

            string setValue = value;
            if (value.Length == 0)
            {
                this.Text = ""; //受信データが無い場合は空白にする
            }
            else if (this.DataLength < 0) //データ長が0未満の時は可変長データとして全てのデータが対象となる
            {
                if (index < value.Length)
                {
                    setValue = value.Substring(index);
                    this.Text = setStringSub(setValue, value);
                }
                else
                {
                    this.Text = "";
                }
            }
            else if (this.DataLength == 0)
            {
                this.Text = string.Empty; //データ長が0の場合は空白にする
            }
            else if (value.Length >= (index + length))
            {
                setValue = value.Substring(index, length);
                this.Text = setStringSub(setValue, value);
            }
            else
            {
                this.Text = string.Empty; //受信データのサイズが足りない場合は空白にする
            }
        }

        /// <summary>
        /// byte List型で受信データをセット
        /// </summary>
        /// <param name="value"></param>
        public void SetBytes(List<byte> value)
        {
            SetString(Util.ToString(value));
        }
        #endregion

        #region データ取得系
        /// <summary>
        /// 文字列型で送信用データを返す
        /// </summary>
        /// <returns></returns>
        public string GetString()
        {
            int length = (this.DataType != DataType.Text) ? this.DataLength * 2 : this.DataLength; //データ長
            string ret = this.text;

            if (ret.IndexOf(':') > 0) ret = ret.Substring(0, ret.IndexOf(':')); //一覧表示の時、値のみ取得

            if (this.DataType == DataType.Hex)
            {
                if (!Util.IsHexadecimal(ret)) ret = "0";                
                ret = Util.FmtStr(ret, length); //16進 "03E8" -> "03E8"
            }
            else if (this.DataType == DataType.Dec)
            {
                if (!Util.IsNumeric(ret)) ret = "0";
                ret = Convert.ToUInt32(ret).ToString($"X{length}"); //10進 "1234" -> "04D2"
            }
            else if (this.DataType == DataType.SDec)
            {
                if (ret.StartsWith("-"))
                {
                    ret = Convert.ToInt32(ret).ToString($"X{length}"); //10進 "-10" -> "FFF6"
                    if (ret.Length > this.DataLength * 2) ret = ret.Substring(ret.Length - this.DataLength * 2);
                }
                else
                {
                    if (!Util.IsNumeric(ret)) ret = "0";
                    ret = Convert.ToUInt32(ret).ToString($"X{length}"); //10進 "1234" -> "04D2"
                }
            }
            else if (this.DataType == DataType.Bcd)
            {
                if (!Util.IsNumeric(ret)) ret = "0";
                ret = Util.FmtStr(ret, length); //Bcd "1234" -> "1234"
            }
            else if (this.DataType == DataType.Bit)
            {
                ret = convBitPatternToHex(ret);
            }
            else if (this.DataType == DataType.CJRCDate)
            {
                ret = convCJRCDateToHex(ret); //時計表示 -> 16進数変換
            }
            else if (this.DataType == DataType.Str)
            {
                var encoder = Encoding.GetEncoding("shift-jis");
                byte[] sjisCode = encoder.GetBytes(ret);
                byte[] hexData  = new byte[this.DataLength];
                Array.Copy(sjisCode, hexData, Math.Min(sjisCode.Length, this.DataLength));

                ret = Util.ToString(hexData);
            }

            if (this.Bit != BIT.NO) ret = convBitHexToHex(ret); //Bit範囲設定内の16進データを取得

            //エンディアン変換
            if (this.Endian == Lecip.Data.Endian.Little && this.DataLength > 1) ret = Util.SwapEndian(ret);

            return ret;
        }

        /// <summary>
        /// byte Listで送信用データを返す
        /// </summary>
        /// <returns></returns>
        public List<byte> GetBytes()
        {
            return Util.GetBytes(GetString());
        }

        /// <summary>
        /// UInt32型で返す(4byte以下のデータ限定)
        /// </summary>
        /// <returns></returns>
        public UInt32 GetUInt32()
        {
            if (this.DataLength > 4) return 0;

            string hexData = GetString();
            if (!Util.IsHexadecimal(hexData)) return 0;

            return Convert.ToUInt32(hexData, 16);
        }
        #endregion
        #endregion

        #region private method
        /// <summary>
        /// 文字列型で受信データをセット
        /// </summary>
        /// <param name="value"></param>
        /// <param name="checkSumValue"></param>
        /// <returns></returns>
        private string setStringSub(string value, string checkSumValue)
        {
            int length = (this.DataType != DataType.Text) ? this.DataLength * 2 : this.DataLength; //データ長
            this.SetValue = value;
            string ret = value;

            //エンディアン変換
            if (this.Endian == Lecip.Data.Endian.Little && this.DataLength > 1) ret = Util.SwapEndian(ret);

            if (this.Bit != BIT.NO) ret = convHexToBitHex(ret); //Bit範囲設定内の16進データを取得

            if (this.DataType == DataType.Hex || this.DataType == DataType.Bcd)
            {
                //16進 or BCD "03E8", "1234" ... 何もしない
            }
            else if (this.DataType == DataType.Dec)
            {
                ret = Convert.ToUInt32(ret, 16).ToString("D"); //10進 "03E8" -> "1000"
            }
            else if (this.DataType == DataType.SDec)
            {
                //符号付10進 "FFF6" -> "-10"
                if (ret[0] == 'F' && ret.Length == length)
                {
                    ret = "FFFFFF" + ret;
                    ret = ret.Substring(ret.Length - 8, 8);
                    ret = Convert.ToInt32(ret, 16).ToString("D");  //10進(－)
                }
                else
                {
                    //符号付きでも"FF"が先頭でない場合は符号なしとして変換
                    ret = Convert.ToUInt32(ret, 16).ToString("D"); //10進 "03E8" -> "1000"
                }
            }
            else if (this.DataType == DataType.Bit)
            {
                ret = convHexToBitPattern(ret); //2進数表示
            }
            else if (this.DataType == DataType.CJRCDate)
            {
                ret = convHexToCJRCDate(ret); //日付設定の場合->YY/MM/DD形式
            }
            else if (this.DataType == DataType.Str)
            {
                var sjis = Encoding.GetEncoding("shift-jis");
                ret = sjis.GetString(Util.GetBytes(ret).ToArray()).TrimEnd('\0'); //SJISコード→文字列変換
            }
            else if (this.DataType == DataType.Sum)
            {
                ret = checkCheckSum(ret, checkSumValue);
            }

            ////表示リストに該当するものがあればそれを表示
            if (this.Items != null)
            {
                this.matchText = string.Empty;
                foreach (string item in this.Items)
                {
                    if (item.Length > ret.Length && item.StartsWith(ret + ":", StringComparison.Ordinal))
                    {
                        if (this.MatchItem) ret = item;
                        this.matchText = "[" + item + "]";
                        break;
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Bit型(bit7-4 などの1bit～32bitのデータ)を受信データ(16進数)から取得(16進数文字列)
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string convHexToBitHex(string value)
        {
            if (this.BitLength <= 0 || this.BitLength > 63) return value;

            int startBit   = (int)Math.Log((UInt32)this.Bit, 2); //スタートビットの位置
            int bitShift   = startBit + 1 - this.BitLength;      //ビットシフトサイズ
            UInt64 maskBit = (UInt64)(Math.Pow(2, this.BitLength) - 1) << bitShift; //取得対象ビットのマスク

            UInt64 itemValue = Convert.ToUInt64(value, 16);
            itemValue = itemValue & maskBit;   //対象ビットのみマスクする
            itemValue = itemValue >> bitShift; //不要ビット分右シフトし、対象ビットのみ取得

            return itemValue.ToString("X"); //16進文字列で返す
        }

        /// <summary>
        /// Bit型(bit7-4 などの1bit～32bitのデータ)から元の16進データに変換
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string convBitHexToHex(string value)
        {
            if (this.BitLength <= 0 || this.BitLength > 63) return value;
            
            int startBit   = (int)Math.Log((UInt32)this.Bit, 2); //スタートビットの位置
            int bitShift   = startBit + 1 - this.BitLength;      //ビットシフトサイズ
            UInt64 maskBit = (UInt64)(Math.Pow(2, this.BitLength) - 1) << bitShift; //取得対象ビットのマスク
            UInt64 maskVal = UInt64.MaxValue ^ maskBit; //対象外ビットを保持するためのマスクビットを生成

            UInt64 oldHexValue  = Convert.ToUInt64(this.SetValue, 16); //更新前の16進データ
            UInt64 newItemValue = Convert.ToUInt64(value, 16);         //更新後の対象項目の16進データ
            newItemValue = newItemValue << bitShift;

            //更新後の16進データを生成(元データの対象外項目をマスクしたものと対象項目をOR演算して算出する)
            UInt64 newHexValue = (oldHexValue & maskVal) | newItemValue;
            string newHexString = newHexValue.ToString("X16").Remove(0, 16 - this.DataLength * 2);

            return newHexString;
        }

        /// <summary>
        /// CJRC準拠の2byte日付データをyy/mm/dd形式の文字列に変換
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string convHexToCJRCDate(string value)
        {
            UInt16 date = Convert.ToUInt16(value, 16);
            int year  = (date >> 9) & 0x7F;
            int month = (date >> 5) & 0x0F;
            int day   = (date >> 0) & 0x1F;

            return string.Format("{0:D2}/{1:D2}/{2:D2}", year, month, day);
        }

        /// <summary>
        /// yy/mm/dd形式の文字列からCJRC準拠の2byte日付データに変換
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string convCJRCDateToHex(string value)
        {
            string[] date = value.Split('/');

            if (date.Length != 3) return "0000";

            int y = Convert.ToInt32(date[0]);
            int m = Convert.ToInt32(date[1]);
            int d = Convert.ToInt32(date[2]);

            int hex = (y << 9) |
                      (m << 5) |
                      d;

            return hex.ToString("X4");
        }

        /// <summary>
        /// 16進文字列から2進数表記に変換
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string convHexToBitPattern(string value)
        {
            string bitPattern = string.Empty;
            UInt64 v64 = Convert.ToUInt64(value, 16);
            int bitLength = this.BitLength;
            if (bitLength == 0) bitLength = this.DataLength * 8;

            for (int i = 0; i < bitLength; i++)
            {
                UInt64 bit = v64 >> (bitLength - i - 1);

                if ((bit & 1) == 1)
                    bitPattern += "1";
                else
                    bitPattern += "0";
            }

            return bitPattern;
        }

        /// <summary>
        /// 2進数表記から16進文字列に変換
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string convBitPatternToHex(string value)
        {
            string hex = string.Empty;
            UInt64 v64 = 0;

            foreach (char c in value)
            {
                v64 = v64 << 1;
                if (c != '0') v64 += 1;
            }

            return v64.ToString("X" + (this.DataLength * 2).ToString());
        }

        /// <summary>
        /// 表示文字列リストがある場合、
        /// コンボボックスに表示するためのDataTableを生成する
        /// </summary>
        private void setItemTable()
        {
            if (this.Items == null) return;

            this.itemTable = new DataTable();
            this.itemTable.Columns.Add("Value", typeof(string));   //実際の値
            this.itemTable.Columns.Add("Display", typeof(string)); //表示値

            foreach (string s in this.Items)
            {
                this.itemTable.Rows.Add(s.Split(':')[0], s); //":"で分割した先方を実際の値とする
            }
        }

        /// <summary>
        /// チェックサム 1byte単位の単純加算を求める
        /// </summary>
        /// <param name="data">チェックサム対象データ</param>
        /// <param name="startIndex">開始インデックス</param>
        /// <param name="length">チェックサム対象バイトサイズ</param>
        /// <returns></returns>
        private UInt64 calcCheckSum(List<byte> data, int startIndex, int length)
        {
            UInt64 sum = 0;

            if (startIndex > data.Count) startIndex = 0;
            if (startIndex + length > data.Count) length = data.Count - startIndex;

            for (int i = 0; i < length; i++)
            {
                sum += data[startIndex + i];
            }

            return sum;
        }

        /// <summary>
        /// チェックサム項目(1byte単位の単純加算限定)をチェックし、OKNG判定結果を付与する
        /// </summary>
        /// <param name="value">チェックサム値</param>
        /// <param name="checkSumValue">チェックサム対象データ</param>
        /// <returns>チェックサム値+OKNG判定結果</returns>
        private string checkCheckSum(string value, string checkSumValue)
        {
            int startIndex = 0;
            int length     = this.Index;

            if (!string.IsNullOrEmpty(this.Comment))
            {
                //コメント項目に範囲パラメータがあればそれを適用する Start=X Length=Yの形式
                string[] prm = this.Comment.Split(' ');
                if (prm.Length > 0)
                {
                    startIndex = Convert.ToInt32(prm[0].Substring(6)); //Start=X
                    length     = this.Index - startIndex;
                }
                if (prm.Length > 1)
                {
                    length     = Convert.ToInt32(prm[1].Substring(7)); //Length=X
                }
            }

            //チェックサム値と計算値が一致するか判定
            UInt64 mask = (UInt64)(Math.Pow(0x100, this.DataLength) - 1);
            UInt64 sum = calcCheckSum(Util.GetBytes(checkSumValue), startIndex, length) & mask;
            if (sum != Convert.ToUInt64(value, 16))
            {
                return $"{value}:NG[{sum.ToString($"X{this.DataLength * 2}")}]";
            }

            return $"{value}:OK";
        }
        #endregion
    }
    #endregion
}
