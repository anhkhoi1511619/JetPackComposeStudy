﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Lecip.Utility;

namespace Lecip.Data
{
    /// <summary>
    /// ステータスビットクラス
    /// </summary>
    public class StatusBit : NotifyPropertyChange
    {
        #region プロパティ
        /// <summary>
        /// 名称を取得: [Bit]_[名称] 例) B7_動作モード
        /// </summary>
        public string Name
        {
            get
            {
                return this.bit.ToString() + "_" + this.name;
            }
        }

        /// <summary>
        /// ステータスビットのONOFF状態(ON=1 OFF=0)を取得・設定
        /// </summary>
        public bool OnOff
        {
            get
            {
                return this.onoff;
            }
            set
            {
                if (this.onoff != value)
                {
                    this.onoff = value;
                    NotifyPropertyChanged("OnOff"); //更新イベントを起こす
                    NotifyPropertyChanged("Text");  //更新イベントを起こす
                }
            }
        }

        /// <summary>
        /// ステータスビットの表示テキストを取得
        /// </summary>
        public string Text
        {
            get
            {
                return (this.OnOff) ? this.items[1] : this.items[0];
            }
        }

        /// <summary>
        /// ステータスビットの値を取得
        /// B7 -> 0x80を返す
        /// </summary>
        public byte BitValue
        {
            get
            {
                return (this.OnOff) ? (byte)this.bit : (byte)0;
            }
        }
        #endregion

        /// <summary>
        /// 名称
        /// </summary>
        private string    name;

        /// <summary>
        /// ビット位置
        /// </summary>
        private BIT bit;

        /// <summary>
        /// items[0]:ビット=0の時の表示テキスト
        /// items[1]:ビット=1の時の表示テキスト
        /// </summary>
        private string[] items;

        /// <summary>
        /// ビット=0:false =1:true
        /// </summary>
        private bool      onoff;

        #region コンストラクタ
        /// <summary>
        /// ステータスビットコンストラクタ
        /// </summary>
        /// <param name="bit">Bit列挙型</param>
        /// <param name="name">ビット名称</param>
        /// <param name="offText">OFF(=0)時の表示テキスト</param>
        /// <param name="onText">ON(=1)時の表示テキスト</param>
        public StatusBit(BIT bit, string name, string offText, string onText)
        {
            this.bit        = bit;
            this.name       = name;
            this.items      = new string[] { offText, onText };
            this.onoff      = false;
        }
        #endregion

        #region public method
        /// <summary>
        /// ステータスの値を元にステータスビットのONOFFを設定
        /// </summary>
        public void SetStatus(byte value)
        {
            this.OnOff = ((value & (byte)this.bit) != 0) ? true : false;
        }
        #endregion
    }
}
