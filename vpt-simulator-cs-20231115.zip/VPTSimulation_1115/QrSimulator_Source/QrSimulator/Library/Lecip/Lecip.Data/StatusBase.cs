﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Lecip.Data
{
    /// <summary>
    /// ステータスベースクラス (BindingList&lt;StatusBit&gt;を継承)
    /// 通常はこのクラスを継承して使用する(Status1クラスを参照)
    /// </summary>
    public class StatusBase : BindingList<StatusBit>
    {
        #region プロパティ
        /// <summary>
        /// ステータス名称を取得(設定はコンストラクタで行う)
        /// </summary>
        public string Name { get { return this.name; } }

        /// <summary>
        /// 読取専用フラグ
        /// </summary>
        public bool ReadOnly { get { return this.readOnly; } }

        /// <summary>
        /// ステータスの値を取得・設定
        /// </summary>
        public byte Value
        {
            get
            {
                byte ret = 0;

                foreach (StatusBit b in this)
                {
                    ret |= b.BitValue;
                }
                return ret;
            }
            set
            {
                foreach (StatusBit b in this)
                {
                    b.SetStatus(value);
                }
            }
        }

        /// <summary>
        /// ステータスビットを名称をキーに取得
        /// </summary>
        /// <param name="name">ステータスビット名称</param>
        /// <returns>ステータスビットオブジェクト</returns>
        public StatusBit this[string name]
        {
            get
            {
                return this.First(i => i.Name == name); //Nameプロパティが一致する先頭を返す
            }
        }
        #endregion

        private string name;
        private int    index;
        private bool   readOnly;

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="name">ステータス名称</param>
        /// <param name="index">データ部の先頭からの位置(送信データ時は0をセット)</param>
        /// <param name="readOnly">読取専用フラグ(画面から設定不可)</param>
        public StatusBase(string name, int index, bool readOnly)
        {
            base.RaiseListChangedEvents = true;

            this.name     = name;
            this.index    = index;
            this.readOnly = readOnly;
        }
        #endregion

        /// <summary>
        /// 文字列型で受信データをセット
        /// </summary>
        /// <param name="value"></param>
        public void SetString(string value)
        {
            if (value.Length >= this.index * 2 + 2)
            {
                this.Value = Convert.ToByte(value.Substring(this.index * 2, 2), 16);
            }
        }

        /// <summary>
        /// 文字列型(16進2文字)で送信用データを返す
        /// </summary>
        /// <returns></returns>
        public string GetString()
        {
            return this.Value.ToString("X2");
        }
    }
}
