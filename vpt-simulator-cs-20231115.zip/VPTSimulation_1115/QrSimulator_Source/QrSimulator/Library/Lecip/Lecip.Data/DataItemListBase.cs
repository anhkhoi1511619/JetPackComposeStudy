﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Lecip.Data
{
    /// <summary>
    /// データアイテムリストベースクラス (BindingList&lt;DataItem&gt;を継承)
    /// 通常はこのクラスを継承して使用する(KeitoDataクラスを参照)
    /// </summary>
    public class DataItemListBase : BindingList<DataItem>
    {
        #region Property
        /// <summary>
        /// 読取専用フラグ
        /// </summary>
        public bool ReadOnly { get; set; }

        /// <summary>
        /// 表示文字列リストとマッチングの実行フラグ(true:実行する false:実行しない)
        /// </summary>
        public bool MatchItem
        {
            get
            {
                if (base.Count >= 0) return false;
                return base[0].MatchItem;
            }
            set
            {
                foreach (DataItem item in this)
                {
                    item.MatchItem = value;
                }
            }
        }

        /// <summary>
        /// データアイテムを名称をキーに取得
        /// </summary>
        /// <param name="name">データアイテム名称</param>
        /// <returns>データアイテムオブジェクト</returns>
        public DataItem this[string name]
        {
            get
            {
                return this.FirstOrDefault(i => i.Name == name); //Nameプロパティが一致する先頭を返す
            }
        }

        /// <summary>
        /// データアイテムを列挙型をキーに取得
        /// </summary>
        /// <param name="param">列挙型</param>
        /// <returns>データアイテムオブジェクト</returns>
        public DataItem this[Enum param]
        {
            get
            {
                return this.FirstOrDefault(i => i.Name == param.ToString()); //Nameプロパティが一致する先頭を返す
            }
        }

        /// <summary>
        /// カンマ区切りのNameの一覧を取得
        /// </summary>
        public string Names
        {
            get
            {
                var nameList = this.Select(i => i.Name);
                return string.Join(",", nameList.ToArray());
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// データアイテムリストのコンストラクタ
        /// </summary>
        /// <param name="readOnly">読取専用フラグ</param>
        public DataItemListBase(bool readOnly)
        {
            this.ReadOnly = readOnly;
            base.RaiseListChangedEvents = true;
        }

        /// <summary>
        /// パラメータファイルを指定して初期化
        /// </summary>
        /// <param name="filePath">パラメータファイルパス</param>
        public DataItemListBase(string filePath) : this(true)
        {
            readFromFile(filePath);
        }

        /// <summary>
        /// リソースからパラメータファイルを読み込んで初期化
        /// </summary>
        /// <param name="stream">リソースストリーム</param>
        /// <param name="resourceName">リソース名称</param>
        public DataItemListBase(System.IO.Stream stream, string resourceName) : this(true)
        {
            LoadFromResource(stream, resourceName);
        }
        #endregion

        #region Public Method
        /// <summary>
        /// リソースから読み込む
        /// </summary>
        /// <param name="stream">リソースストリーム</param>
        /// <param name="resourceName">リソース名</param>
        public void LoadFromResource(System.IO.Stream stream, string resourceName)
        {
            if (stream == null) return;

            using (var sr = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("Shift_JIS")))
            {
                if (sr == null) throw new Exception("Stremの取得に失敗");

                CSVParser csvp = new CSVParser();
                var csv = csvp.Parse(sr);

                readParamFile(csv, resourceName);
            }
        }
        /// <summary>
        /// 受信データ(文字列)を受け取り、各アイテムにセット
        /// </summary>
        public void SetString(string value)
        {
            foreach (DataItem item in this)
            {
                item.SetString(value);
            }
        }

        /// <summary>
        /// 受信データ(byte List)を受け取り、各アイテムにセット
        /// </summary>
        public void SetBytes(List<byte> value)
        {
            foreach (DataItem item in this)
            {
                item.SetBytes(value);
            }
        }

        /// <summary>
        /// 格納データからByte配列を生成する
        /// アドレス、データ長は各DataItemでセットされた値を使用する
        /// </summary>
        /// <returns></returns>
        public byte[] GetByteArray()
        {
            DataItem last = this.Last();

            byte[] dstArray = new byte[last.Index + last.DataLength];

            foreach (var item in this)
            {
                string hex = item.GetString();

                Util.SetByteArray(hex, dstArray, item.Index);
            }

            return dstArray;
        }

        /// <summary>
        /// 格納データからByte配列を生成する
        /// アドレス、データ長は各DataItemでセットされた値を使用する
        /// </summary>
        /// <param name="lastItemName">Byte配列を生成する最後のDataItem名称。先頭からここまでを対象とする</param>
        /// <returns></returns>
        public byte[] GetByteArray(string lastItemName)
        {
            DataItem last = this[lastItemName];

            byte[] dstArray = new byte[last.Index + last.DataLength];

            foreach (var item in this)
            {
                string hex = item.GetString();

                Util.SetByteArray(hex, dstArray, item.Index);

                if (item.Name == lastItemName) break;
            }

            return dstArray;
        }
        /// <summary>
        /// データアイテムを一括で空白に初期化
        /// </summary>
        public void ClearText()
        {
            foreach (DataItem item in this)
            {
                item.Text      = string.Empty;
                item.SetValue  = string.Empty;
                item.MatchText = string.Empty;
            }
        }

        /// <summary>
        /// データアイテムをリセットして、パラメータファイルを読み直す
        /// </summary>
        /// <param name="filePath">パラメータファイルパス</param>
        public void ResetAll(string filePath)
        {
            readFromFile(filePath);
        }
        #endregion

        #region Private Method
        /// <summary>
        /// ファイルから読み込む
        /// </summary>
        /// <param name="filePath"></param>
        private void readFromFile(string filePath)
        {
            if (!System.IO.File.Exists(filePath))
            {
                throw new Exception(string.Format("{0}が見つかりません", filePath));
            }

            CSVParser csvp = new CSVParser();
            var csv = csvp.ParseFile(filePath);

            readParamFile(csv, System.IO.Path.GetFileName(filePath));
        }

        /// <summary>
        /// パラメータファイルを読み込んでデータアイテムリストを設定する
        /// </summary>
        /// <param name="csv">パラメータファイルデータ</param>
        /// <param name="filename">ファイル名</param>
        private void readParamFile(List<List<string>> csv, string filename)
        {
            base.Clear();
            this.ReadOnly = (csv[1][1].ToUpper() == "TRUE") ? true : false; //読取専用フラグ設定

            for (int i = 3; i < csv.Count; i++)
            {
                //空行や「//」で始まる(コメント)は飛ばす
                if (string.IsNullOrEmpty(csv[i][0]) || csv[i][0].StartsWith("//")) continue;

                //パラメータチェック
                if (!isParameterOK(csv[i]))
                {
                    throw new Exception(string.Format("{0}の{1}行目にエラーがあります", filename, i + 1));
                }

                //可変サイズデータは-1で登録する
                if (csv[i][4] == "VARIABLE") csv[i][4] = "-1";

                //各パラメータ取得
                string         name     = csv[i][0];
                DataType       dataType = (Lecip.Data.DataType)Util.Val2Enum(csv[i][1], typeof(Lecip.Data.DataType));
                bool           endian   = (csv[i][2].ToUpper() == "LITTLE") ? Endian.Little : Endian.Big;
                int            index    = Convert.ToInt32(csv[i][3]);
                int            length   = Convert.ToInt32(csv[i][4]);
                int            bitLen   = Convert.ToInt32(csv[i][5]);
                BIT            bit      = (Lecip.Data.BIT)Util.Val2Enum(csv[i][6], typeof(Lecip.Data.BIT));
                string         comment  = (csv[i].Count >= 8) ? csv[i][7] : string.Empty;
                List<string>   items    = new List<string>();
                string[]       item     = null;
                //表示アイテム取得
                for (int j = 8; j < csv[i].Count; j++)
                {
                    if (string.IsNullOrEmpty(csv[i][j])) break;

                    items.Add(csv[i][j]);
                }
                if (items.Count > 0) item = items.ToArray();

                Add(new DataItem(name, dataType, endian, index, length, bitLen, bit, comment, item));
            }
        }

        /// <summary>
        /// CSVパラメータ設定のパラメータチェック
        /// </summary>
        /// <param name="prm">パラメータ文字列リスト</param>
        /// <returns>true:OK false:NG</returns>
        private bool isParameterOK(List<string> prm)
        {
            if (prm.Count < 7) return false; //最低7列必要

            //DataType (1)
            if (Util.Val2Enum(prm[1], typeof(DataType)) == null) return false;
            //Endian (2)
            if (prm[2].ToUpper() != "LITTLE" && prm[2].ToUpper() != "BIG") return false;
            //Index (3)
            if (!Lecip.Util.IsNumeric(prm[3])) return false;
            //DataLength (4)
            if (!Lecip.Util.IsNumeric(prm[4]) && prm[4] != "VARIABLE") return false;
            //BitLength (5)
            if (!Lecip.Util.IsNumeric(prm[5])) return false;
            //Bit (6)
            if (Util.Val2Enum(prm[6], typeof(BIT)) == null) return false;

            return true;
        }
        #endregion
    }
}
