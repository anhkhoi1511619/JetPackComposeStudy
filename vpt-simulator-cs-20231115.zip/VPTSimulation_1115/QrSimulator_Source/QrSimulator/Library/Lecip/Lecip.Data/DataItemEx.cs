﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Lecip.Data;

namespace Lecip.Data
{
    /// <summary>
    /// DataItemの拡張クラス
    /// 通常のDataItemに対し親子関係の状態を持つ
    /// 1Byte以上のByte項目の次にその項目のBitデータがある場合、
    /// そのBitデータをByte項目の子供として登録する
    /// Hex 2Byte ... 親
    ///   Bit 1Bit  ... 子
    ///   Hex 2Bit  ... 子
    /// </summary>
    public class DataItemEx : DataItem
    {
        #region Property
        /// <summary>親データ</summary>
        public DataItem Parent { get; set; } = null;
        /// <summary>子供データ</summary>
        public DataItemListBase Children { get; set; } = new Lecip.Data.DataItemListBase(false);
        /// <summary>子供データを持っているか</summary>
        public bool HasChildren { get; set; }
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="name"></param>
        /// <param name="dataType"></param>
        /// <param name="endian"></param>
        /// <param name="index"></param>
        /// <param name="length"></param>
        /// <param name="bitLength"></param>
        /// <param name="bit"></param>
        /// <param name="comment"></param>
        /// <param name="items"></param>
        public DataItemEx(string name, Lecip.Data.DataType dataType, bool endian, int index, int length,
                        int bitLength, Lecip.Data.BIT bit, string comment, string[] items) :
            base(name, dataType, endian, index, length,
                        bitLength, bit, comment, items)
        {
        }
        #endregion
    }
}
