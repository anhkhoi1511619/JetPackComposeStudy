﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Lecip.Data
{
    /// <summary>
    /// DataItemListBaseExの拡張クラス
    /// </summary>
    public class DataItemListBaseEx : BindingList<DataItemEx>
    {
        #region Property
        /// <summary>読取専用属性</summary>
        public bool ReadOnly { get; set; }
        /// <summary>配下のDataItemExにChildrenを持っているか</summary>
        public bool HasChildren { get; private set; }
        /// <summary>アイテム数を返す(ChildrenがあるときはChildrenの数も入れる</summary>
        public int GetItemCount
        {
            get
            {
                if (!this.HasChildren) return this.Count;

                int count = this.Count;
                foreach (var item in this)
                {
                    count += item.Children.Count;
                }
                return count;
            }
        }
        /// <summary>
        /// データアイテムを名称をキーに取得
        /// </summary>
        /// <param name="name">データアイテム名称</param>
        /// <returns>データアイテムオブジェクト</returns>
        public DataItemEx this[string name]
        {
            get
            {
                return this.FirstOrDefault(i => i.Name == name); //Nameプロパティが一致する先頭を返す
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public DataItemListBaseEx()
        {
            this.ReadOnly = false;
            this.HasChildren = false;
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="filePath"></param>
        public DataItemListBaseEx(string filePath) : base()
        {
            readFromFile(filePath);
        }

        /// <summary>
        /// リソースからパラメータファイルを読み込んで初期化
        /// </summary>
        /// <param name="stream">リソースストリーム</param>
        /// <param name="resourceName">リソース名称</param>
        public DataItemListBaseEx(System.IO.Stream stream, string resourceName) : base()
        {
            LoadFromResource(stream, resourceName);
        }
        #endregion

        #region Public Method
        /// <summary>
        /// リソースから読み込む
        /// </summary>
        /// <param name="stream">リソースストリーム</param>
        /// <param name="resourceName">リソース名</param>
        public void LoadFromResource(System.IO.Stream stream, string resourceName)
        {
            if (stream == null) return;

            using (var sr = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("Shift_JIS")))
            {
                if (sr == null) throw new Exception("Stremの取得に失敗");

                CSVParser csvp = new CSVParser();
                var csv = csvp.Parse(sr);

                readParamFile(csv, resourceName);
            }
        }

        /// <summary>
        /// データをセット
        /// </summary>
        /// <param name="value"></param>
        public void SetString(string value)
        {
            foreach (var item in this)
            {
                item.SetString(value);
                if (item.Children.Count > 0) item.Children.SetString(value);
            }
        }

        /// <summary>
        /// 名称一覧を返す
        /// 子供があるときは子供も入れる
        /// </summary>
        /// <returns></returns>
        public string[] GetNameList()
        {
            if (!this.HasChildren) return this.Select(i => i.Name).ToArray();

            List<string> nameList = new List<string>();
            foreach (var item in this)
            {
                nameList.Add(item.Name);
                if (item.HasChildren) nameList.AddRange(item.Children.Select(i => i.Name));
            }
            return nameList.ToArray();
        }

        /// <summary>
        /// データアイテムを一括で空白に初期化
        /// </summary>
        public void ClearText()
        {
            foreach (var item in this)
            {
                item.Text      = string.Empty;
                item.SetValue  = string.Empty;
                item.MatchText = string.Empty;
            }
        }

        /// <summary>
        /// データアイテムをリセットして、パラメータファイルを読み直す
        /// </summary>
        /// <param name="filePath">パラメータファイルパス</param>
        public void ResetAll(string filePath)
        {
            readFromFile(filePath);
        }
        #endregion

        #region Private Method
        /// <summary>
        /// ファイルから読み込む
        /// </summary>
        /// <param name="filePath"></param>
        private void readFromFile(string filePath)
        {
            if (!System.IO.File.Exists(filePath))
            {
                throw new Exception(string.Format("{0}が見つかりません", filePath));
            }

            CSVParser csvp = new CSVParser();
            var csv = csvp.ParseFile(filePath);

            readParamFile(csv, System.IO.Path.GetFileName(filePath));
        }

        /// <summary>
        /// パラメータファイルを読み込んでデータアイテムリストを設定する
        /// </summary>
        /// <param name="csv">パラメータファイルデータ</param>
        /// <param name="filename">ファイル名</param>
        private void readParamFile(List<List<string>> csv, string filename)
        {
            this.ReadOnly = (csv[1][1].ToUpper() == "TRUE") ? true : false; //読取専用フラグ設定

            for (int i = 3; i < csv.Count; i++)
            {
                //空行や「//」で始まる(コメント)は飛ばす
                if (string.IsNullOrEmpty(csv[i][0]) || csv[i][0].StartsWith("//")) continue;

                //パラメータチェック
                if (!isParameterOK(csv[i]))
                {
                    throw new Exception(string.Format("{0}の{1}行目にエラーがあります", filename, i + 1));
                }

                if (csv[i][4] == "VARIABLE") csv[i][4] = "-1";

                //各パラメータ取得
                string name = csv[i][0];
                Lecip.Data.DataType dataType = (Lecip.Data.DataType)Util.Val2Enum(csv[i][1], typeof(Lecip.Data.DataType));
                bool endian = (csv[i][2].ToUpper() == "LITTLE") ? Lecip.Data.Endian.Little : Lecip.Data.Endian.Big;
                int index = Convert.ToInt32(csv[i][3]);
                int length = Convert.ToInt32(csv[i][4]);
                int bitLen = Convert.ToInt32(csv[i][5]);
                Lecip.Data.BIT bit = (Lecip.Data.BIT)Util.Val2Enum(csv[i][6], typeof(Lecip.Data.BIT));
                string comment = (csv[i].Count >= 8) ? csv[i][7] : string.Empty;
                List<string> items = new List<string>();
                string[] item = null;
                //表示アイテム取得
                for (int j = 8; j < csv[i].Count; j++)
                {
                    if (string.IsNullOrEmpty(csv[i][j])) break;

                    items.Add(csv[i][j]);
                }
                if (items.Count > 0) item = items.ToArray();

                if (base.Count == 0 || length <= 0)
                {
                    //先頭のデータ、データ長が0以下のものは親として登録する
                    Add(new DataItemEx(name, dataType, endian, index, length, bitLen, bit, comment, item));
                }
                else
                {
                    //直前のパラメータを取得
                    DataItemEx p = base[base.Count - 1];

                    if ((p.Bit == Lecip.Data.BIT.NO) && (p.Index <= index && index + length <= p.Index + p.DataLength))
                    {
                        //直前のパラメータがBIT項目で無い、かつ現在のパラメータの範囲を含んでいる=>現在のパラメータ=子供
                        p.Children.Add(new DataItemEx(name, dataType, endian, index, length, bitLen, bit, comment, item) { Parent = p });
                        p.HasChildren = true;
                        this.HasChildren = true;
                    }
                    else
                        //直前のパラメータが現在のパラメータの範囲外=>現在のパラメータ=親
                        Add(new DataItemEx(name, dataType, endian, index, length, bitLen, bit, comment, item));
                }
            }
        }

        /// <summary>
        /// CSVパラメータ設定のパラメータチェック
        /// </summary>
        /// <param name="prm">パラメータ文字列リスト</param>
        /// <returns>true:OK false:NG</returns>
        private bool isParameterOK(List<string> prm)
        {
            if (prm.Count < 7) return false; //最低7列必要

            //DataType (1)
            if (Util.Val2Enum(prm[1], typeof(Lecip.Data.DataType)) == null) return false;
            //Endian (2)
            if (prm[2].ToUpper() != "LITTLE" && prm[2].ToUpper() != "BIG") return false;
            //Index (3)
            if (!Lecip.Util.IsNumeric(prm[3])) return false;
            //DataLength (4)
            if (!Lecip.Util.IsNumeric(prm[4]) && prm[4] != "VARIABLE") return false;
            //BitLength (5)
            if (!Lecip.Util.IsNumeric(prm[5])) return false;
            //Bit (6)
            if (Util.Val2Enum(prm[6], typeof(Lecip.Data.BIT)) == null) return false;

            return true;
        }
        #endregion
    }
}
