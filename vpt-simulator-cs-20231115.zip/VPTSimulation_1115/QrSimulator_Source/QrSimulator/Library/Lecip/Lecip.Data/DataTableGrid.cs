﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;
using System.Data;

namespace Lecip.Data
{
    /// <summary>
    /// データテーブルアイテムの状態を表示・設定可能なDataGridView
    /// 対象のデータテーブルアイテムをInit()の引数で指定する
    /// DataItemGridとデータテーブルアイテムオブジェクトがバインドされているので
    /// データテーブルアイテムオブジェクトにアクセスすればOK
    /// </summary>
    public class DataTableGrid : DataGridViewExNumber
    {
        /// <summary>
        /// 処理化処理
        /// データソース(データテーブルアイテム)を渡す
        /// </summary>
        /// <param name="dataSource">対象のデータソース(DataTableItem)</param>
        public void Init(DataTableItem dataSource)
        {
            this.ColumnHeadersVisible = true;
            this.RowHeadersVisible = true;
            this.SelectionMode = DataGridViewSelectionMode.CellSelect;
            this.RowTemplate.Height = 17;
            this.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            this.AutoGenerateColumns = false;
            this.DefaultCellStyle.NullValue = string.Empty;
            this.DefaultCellStyle.DataSourceNullValue = string.Empty;
            this.RowNumberVisible = true;
            this.StartRowNumber = 1;
            this.TopLeftHeaderCell.Value = dataSource.Name;

            this.AllowUserToAddRows = false;
            this.AllowUserToDeleteRows = false;
            this.AllowUserToOrderColumns = false;
            this.AllowUserToResizeColumns = false;
            this.AllowUserToResizeRows = false;

            //var col = new DataGridViewTextBoxColumn();
            //col.DefaultCellStyle.BackColor = SystemColors.Control;
            //col.SortMode = DataGridViewColumnSortMode.NotSortable;
            //col.DataPropertyName = "Name";
            //col.Name = dataSource.Name;
            //col.ReadOnly = true;
            //this.Columns.Add(col);

            DataGridViewTextBoxColumn col;
            foreach (DataColumn dcol in dataSource.DataColumns)
            {
                col = new DataGridViewTextBoxColumn();
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
                col.DataPropertyName = dcol.ColumnName;
                col.Name = dcol.ColumnName;
                col.ReadOnly = dataSource.ReadOnly;
                this.Columns.Add(col);
            }
            
            int width = (this.Width - this.RowHeadersWidth - this.VerticalScrollBar.Width - 1) / this.Columns.Count;
            if (width < 40) width = 40;

            foreach (DataGridViewColumn c in this.Columns)
            {
                c.Width = width;
            }

            this.DataSource = dataSource;

            //this.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
        }
    }
}
