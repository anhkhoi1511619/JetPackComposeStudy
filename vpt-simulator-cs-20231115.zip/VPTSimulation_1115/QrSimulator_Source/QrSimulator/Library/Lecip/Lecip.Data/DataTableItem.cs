﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Data;
using Lecip;
using Lecip.Utility;

namespace Lecip.Data
{
    /// <summary>
    /// データテーブルアイテムクラス
    /// </summary>
    public class DataTableItem : DataTable
    {
        #region Property
        /// <summary>
        /// 読取専用フラグ
        /// </summary>
        public bool         ReadOnly        { get; set; }
        /// <summary>
        /// データテーブル名
        /// </summary>
        public string       Name            { get; set; }
        /// <summary>
        /// データ項目列
        /// </summary>
        public List<DataColumn> DataColumns { get; set; }

        /// <summary>
        /// 行インデックス、列インデックスを指定して値の取得、設定をする
        /// </summary>
        /// <param name="row">行インデックス</param>
        /// <param name="dataCol">列インデックス</param>
        /// <returns></returns>
        public object this[int row, int dataCol]
        {
            get
            {
                if (dataCol >= this.DataColumns.Count) return null;

                return this[row, this.DataColumns[dataCol].ColumnName];
            }

            set
            {
                if (dataCol >= this.DataColumns.Count) return;

                this[row, this.DataColumns[dataCol].ColumnName] = value;
            }
        }

        /// <summary>
        /// 行インデックス、列名称を指定して値の取得、設定をする
        /// </summary>
        /// <param name="row">行インデックス</param>
        /// <param name="dataColName">列名称</param>
        /// <returns></returns>
        public object this[int row, string dataColName]
        {
            get
            {
                if (row < this.Rows.Count && this.Columns.IndexOf(dataColName) >= 0)
                    return this.Rows[row][dataColName];
                else
                    return null;
            }

            set
            {
                if (row < this.Rows.Count && this.Columns.IndexOf(dataColName) >= 0)
                    this.Rows[row][dataColName] = value;
            }
        }

        /// <summary>
        /// 項目名称
        /// </summary>
        public string Names
        {
            get
            {
                string names = string.Empty;
                foreach (DataRow row in this.Rows)
                {
                    names += (string)row["Name"] + ",";
                }

                return names;
            }
        }

        /// <summary>
        /// 設定されているデータアイテム数
        /// </summary>
        public int Count
        {
            get
            {
                return this.Rows.Count;
            }
        }

        /// <summary>
        /// データアイテムの列数
        /// </summary>
        public int ColumnCount
        {
            get
            {
                return this.DataColumns.Count;
            }
        }

        #endregion

        #region Constructor
        /// <summary>
        /// データテーブルアイテムのコンストラクタ
        /// </summary>
        public DataTableItem()
        {
            base.Columns.Add("Name",       typeof(string));
            base.Columns.Add("DataType",   typeof(Lecip.Data.DataType));
            base.Columns.Add("Endian",     typeof(bool));
            base.Columns.Add("Dataindex",  typeof(int));
            base.Columns.Add("DataLength", typeof(int));
            base.Columns.Add("BitLength",  typeof(int));
            base.Columns.Add("Bit",        typeof(Lecip.Data.BIT));

            this.ReadOnly     = false;
            this.Name         = string.Empty;
            this.DataColumns = new List<DataColumn>();
        }

        /// <summary>
        /// パラメータファイルを指定して初期化
        /// </summary>
        /// <param name="filePath">パラメータファイルパス</param>
        public DataTableItem(string filePath) 
            : this()
        {
            readFromFile(filePath);
        }

        /// <summary>
        /// リソースからパラメータファイルを読み込んで初期化
        /// </summary>
        /// <param name="stream">リソースストリーム</param>
        /// <param name="resourceName">リソース名称</param>
        public DataTableItem(System.IO.Stream stream, string resourceName) : this()
        {
            LeadFromResource(stream, resourceName);
        }
        #endregion

        #region Public Method
        /// <summary>
        /// リソースから読み込む
        /// </summary>
        /// <param name="stream">リソースストリーム</param>
        /// <param name="resourceName">リソース名</param>
        public void LeadFromResource(System.IO.Stream stream, string resourceName)
        {
            if (stream == null) return;

            using (var sr = new System.IO.StreamReader(stream, System.Text.Encoding.GetEncoding("Shift_JIS")))
            {
                if (sr == null) throw new Exception("Stremの取得に失敗");

                CSVParser csvp = new CSVParser();
                var csv = csvp.Parse(sr);

                readParamFile(csv, resourceName);
            }
        }

        /// <summary>
        /// 文字列型で送信用データを返す
        /// 列インデックスをデータ列番号指定(0～)
        /// </summary>
        /// <param name="row">行インデックス</param>
        /// <param name="dataCol">列インデックス</param>
        /// <returns></returns>
        public string GetString(int row, int dataCol)
        {
            if (dataCol >= this.DataColumns.Count) return string.Empty;

            return this.GetString(row, this.DataColumns[dataCol].ColumnName);    
        }

        /// <summary>
        /// 文字列型で送信用データを返す
        /// 列インデックスをデータ列名称指定
        /// </summary>
        /// <param name="row">行インデックス</param>
        /// <param name="dataColName">列名称</param>
        /// <returns></returns>
        public string GetString(int row, string dataColName)
        {
            string   ret        = string.Empty;
            DataType dataType   = (DataType)this.Rows[row]["DataType"];
            bool     endian     = (bool)this.Rows[row]["Endian"];
            int      dataLength = (int)this.Rows[row]["DataLength"];

            if (row < this.Rows.Count && this.Columns.IndexOf(dataColName) >= 0)
            {
                ret = (string)this.Rows[row][dataColName];
            }

            if (dataType == DataType.Hex)
            {
                if (!Util.IsHexadecimal(ret)) ret = "0";

                //16進->16進 "03E8" -> "03E8"
                ret = Util.FmtStr(ret, dataLength * 2);
            }
            else if (dataType == DataType.Dec)
            {
                if (!Util.IsNumeric(ret)) ret = "0";

                //10進->16進に変換 "1234" -> "04D2"
                ret = Convert.ToUInt32(ret).ToString("X" + (dataLength * 2).ToString());
            }
            else if (dataType == DataType.Bcd)
            {
                if (!Util.IsNumeric(ret)) ret = "0";

                //BCD->BCD "1234" -> "1234"
                ret = Util.FmtStr(ret, dataLength * 2);
            }
            else if (dataType == DataType.Str)
            {
                var sjis = Encoding.GetEncoding("shift-jis");

                var code = sjis.GetBytes(ret);
                ret = Util.ToString(code);

                ret = Util.FmtStr(ret, dataLength * 2);
            }

            //エンディアン変換
            if (endian == Lecip.Data.Endian.Little && dataLength > 1) ret = Util.SwapEndian(ret);

            return ret;
        }
        #endregion

        #region Private Method
        /// <summary>
        /// ファイルから読み込む
        /// </summary>
        /// <param name="filePath"></param>
        private void readFromFile(string filePath)
        {
            if (!System.IO.File.Exists(filePath))
            {
                throw new Exception(string.Format("{0}が見つかりません", filePath));
            }

            CSVParser csvp = new CSVParser();
            var csv = csvp.ParseFile(filePath);

            readParamFile(csv, System.IO.Path.GetFileName(filePath));
        }

        /// <summary>
        /// パラメータファイルを読み込んでデータアイテムリストを設定する
        /// </summary>
        /// <param name="csv">パラメータファイルデータ</param>
        /// <param name="filename">ファイル名</param>
        private void readParamFile(List<List<string>> csv, string filename)
        {
            this.Name = csv[1][0];
            this.ReadOnly = (csv[1][1].ToUpper() == "TRUE") ? true : false; //読取専用フラグ設定

            if (csv[1].Count <= 2) csv[1].Add("");
            if (string.IsNullOrEmpty(csv[1][2])) csv[1][2] = " ";

            for (int i = 2; i < csv[1].Count; i++)
            {
                if (i > 2 && string.IsNullOrEmpty(csv[1][i])) break;
                DataColumn c = base.Columns.Add(csv[1][i], typeof(string));
                c.DefaultValue = string.Empty;
                this.DataColumns.Add(c);
            }

            for (int i = 3; i < csv.Count; i++)
            {
                //空行や「//」で始まる(コメント)は飛ばす
                if (string.IsNullOrEmpty(csv[i][0]) || csv[i][0].StartsWith("//")) continue;

                //パラメータチェック
                if (!isParameterOK(csv[i]))
                {
                    throw new Exception(string.Format("{0}の{1}行目にエラーがあります", filename, i + 1));
                }

                //各パラメータ取得
                string         name     = csv[i][0];
                DataType       dataType = (Lecip.Data.DataType)Util.Val2Enum(csv[i][1], typeof(Lecip.Data.DataType));
                bool           endian   = (csv[i][2].ToUpper() == "LITTLE") ? Endian.Little : Endian.Big;
                int            index    = Convert.ToInt32(csv[i][3]);
                int            length   = Convert.ToInt32(csv[i][4]);
                int            bitLen   = Convert.ToInt32(csv[i][5]);
                BIT            bit      = (Lecip.Data.BIT)Util.Val2Enum(csv[i][6], typeof(Lecip.Data.BIT));

                base.Rows.Add(name, dataType, endian, index, length, bitLen, bit);
            }
        }

        /// <summary>
        /// CSVパラメータ設定のパラメータチェック
        /// </summary>
        /// <param name="prm">パラメータ文字列リスト</param>
        /// <returns>true:OK false:NG</returns>
        private bool isParameterOK(List<string> prm)
        {
            if (prm.Count < 7) return false;

            //DataType (1)
            if (Util.Val2Enum(prm[1], typeof(Lecip.Data.DataType)) == null) return false;
            //Endian (2)
            if (prm[2].ToUpper() != "LITTLE" && prm[2].ToUpper() != "BIG") return false;
            //Index (3)
            if (!Lecip.Util.IsNumeric(prm[3])) return false;
            //DataLength (4)
            if (!Lecip.Util.IsNumeric(prm[4])) return false;
            //BitLength (5)
            if (!Lecip.Util.IsNumeric(prm[5])) return false;
            //Bit (6)
            if (Util.Val2Enum(prm[6], typeof(Lecip.Data.BIT)) == null) return false;

            return true;
        }
        #endregion
    }
}
