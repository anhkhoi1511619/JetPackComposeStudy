﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;

namespace Lecip.Data
{
    /// <summary>
    /// RowHeaderに行番号を表示するDataGridView
    /// </summary>
    public class DataGridViewExNumber : DataGridView
    {
        #region Field
        /// <summary>行番号を表示するかしないか</summary>
        public bool RowNumberVisible { get; set; } = false;

        /// <summary>開始番号</summary>
        public int  StartRowNumber { get; set; } = 1;
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public DataGridViewExNumber()
        {
            this.RowTemplate.HeaderCell = new DataGridViewRowHeaderCellEx();
            this.RowTemplate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
        }
        #endregion

        #region Event-Handler
        /// <summary>
        /// 行ヘッダに行番号を表示するためのオーバーライド
        /// </summary>
        /// <param name="e"></param>
        protected override void OnRowPostPaint(DataGridViewRowPostPaintEventArgs e)
        {
            base.OnRowPostPaint(e);

            if (!this.RowNumberVisible) return;

            int rowNumber = this.StartRowNumber + e.RowIndex;

            Rectangle rect = new Rectangle(
                e.RowBounds.Location.X,
                e.RowBounds.Location.Y,
                this.RowHeadersWidth - 4,
                e.RowBounds.Height);

            TextRenderer.DrawText(
                e.Graphics,
                rowNumber.ToString(),
                this.RowHeadersDefaultCellStyle.Font,
                rect,
                this.RowHeadersDefaultCellStyle.ForeColor,
                TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
        }
        #endregion
    }
}
