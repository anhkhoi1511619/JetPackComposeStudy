﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SimulatorApplication
{
    /// <summary>
    /// CSV設定編集画面
    /// </summary>
    public partial class FormCsvEditor : Form
    {
        #region Property
        /// <summary>設定可能行数</summary>
        public int  MaxRowCount    { get; set; }

        /// <summary>ユーザーによる行追加・削除を有効・無効にする</summary>
        public bool AllowUserToAddDelete
        {
            set
            {
                if (this.dgvEdit == null) return;

                this.dgvEdit.AllowUserToAddRows    = value;
                this.dgvEdit.AllowUserToDeleteRows = value;
            }
        }

        /// <summary>この画面で編集する対象のDataSource(DataTable)を設定・取得</summary>
        public object DataSource
        {
            set
            {
                if (this.dgvEdit == null) return;
                this.dgvEdit.DataSource = value;
                foreach (DataGridViewColumn col in this.dgvEdit.Columns)
                {
                    col.SortMode = DataGridViewColumnSortMode.NotSortable;
                }
            }
            get
            {
                if (this.dgvEdit == null) return null;
                return this.dgvEdit.DataSource;
            }
        }

        /// <summary>コメントラベルに表示するコメントテキストリスト</summary>
        public List<string> Comments { get; set; }
        #endregion

        #region Constructor
        public FormCsvEditor()
        {
            InitializeComponent();

            this.dgvEdit.RowTemplate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            this.dgvEdit.AutoGenerateColumns = true;
            this.dgvEdit.AllowUserToAddRows = false;
            this.dgvEdit.DefaultCellStyle.NullValue = string.Empty;
            this.dgvEdit.DefaultCellStyle.DataSourceNullValue = string.Empty;

            this.Load += (object sender, EventArgs e) => { initialize(); };

            this.tsmItemEditClear.Click += (object sender, EventArgs e) => { editCut(); };
            this.tsmItemEditCut.Click   += (object sender, EventArgs e) => { copyToClipboard(this.ActiveControl); editCut(); };
            this.tsmItemEditCopy.Click  += (object sender, EventArgs e) => { copyToClipboard(this.ActiveControl); };
            this.tsmItemEditPaste.Click += (object sender, EventArgs e) => { pasteFromClipboard(this.ActiveControl); };
            this.tsmItemEditSequential.Click += (object sender, EventArgs e) => { inputSequentialData(this.ActiveControl); };

            this.dgvEdit.UserAddedRow   += (object sender, DataGridViewRowEventArgs e) => { setAllowUserToAddRows(); };
            this.dgvEdit.UserDeletedRow += (object sender, DataGridViewRowEventArgs e) => { setAllowUserToAddRows(); };
            this.MaxRowCount = 100;
        }
        #endregion

        #region Private Method
        /// <summary>表示初期化</summary>
        private void initialize()
        {
            foreach (DataGridViewColumn c in this.dgvEdit.Columns)
            {
                c.Width = 70;
            }
            if (this.Comments != null) Lecip.Utility.Commenter.Add(this.lbComment, this.dgvEdit, this.Comments);

            setAllowUserToAddRows();
        }

        /// <summary>ユーザーによる行追加許可を有効・無効にする</summary>
        private void setAllowUserToAddRows()
        {
            if (this.dgvEdit.AllowUserToAddRows && this.dgvEdit.Rows.Count == this.MaxRowCount)
            {
                return;
            }
            if (this.dgvEdit.Rows.Count >= this.MaxRowCount)
            {
                this.dgvEdit.AllowUserToAddRows = false;
            }
            else
            {
                this.dgvEdit.AllowUserToAddRows = true;
            }
        }

        /// <summary>切り取り処理(選択範囲をクリアする)</summary>
        private void editCut()
        {
            foreach (DataGridViewCell cell in this.dgvEdit.SelectedCells)
            {
                cell.Value = string.Empty;
            }
        }

        /// <summary>
        /// 選択範囲のセルからタブ区切りのテキストを生成しクリップボードにコピーする
        /// </summary>
        /// <param name="control">コピー元のコントロール(DataGridView限定)を指定</param>
        private void copyToClipboard(Control control)
        {
            //ToolStrip p = cmnu.GetCurrentParent();
            //if (!(p is ContextMenuStrip)) return;

            //Control ctl = ((ContextMenuStrip)p).SourceControl;
            //if (!(ctl is DataGridView)) return;

            //DataGridView grid = (DataGridView)ctl;

            if (!(control is DataGridView)) return;
            DataGridView grid = (DataGridView)control;

            //選択セルを取得
            DataGridViewSelectedCellCollection selectedCells = grid.SelectedCells;

            //選択の仕方でコレクションの並びが違うので、総なめして開始位置、終了位置を求める
            string tsv = string.Empty;
            int topCol = int.MaxValue;
            int topRow = int.MaxValue;
            int endCol = -1;
            int endRow = -1;
            foreach (DataGridViewCell cell in selectedCells)
            {
                if (cell.ColumnIndex < topCol) topCol = cell.ColumnIndex;
                if (cell.RowIndex < topRow) topRow = cell.RowIndex;
                if (cell.ColumnIndex > endCol) endCol = cell.ColumnIndex;
                if (cell.RowIndex > endRow) endRow = cell.RowIndex;
            }

            //タブ区切りのテキストを生成してクリップボードに貼り付ける
            for (int row = topRow; row <= endRow; row++)
            {
                for (int col = topCol; col <= endCol; col++)
                {
                    if (!(grid[col, row].Value is DBNull)) tsv += (string)grid[col, row].Value;
                    if (col != endCol) tsv += "\t";
                }
                if (row != endRow) tsv += "\n";
            }
            if (!string.IsNullOrEmpty(tsv)) Clipboard.SetText(tsv, TextDataFormat.Text);
            grid.CurrentCell = grid[topCol, topRow];
        }

        /// <summary>
        /// タブ区切りのクリップボードテキストを選択セルを先頭に貼り付ける
        /// </summary>
        /// <param name="control">コピー先のコントロール(DataGridView限定)を指定</param>
        private void pasteFromClipboard(Control control)
        {
            //ToolStrip p = cmnu.GetCurrentParent();
            //if (!(p is ContextMenuStrip)) return;

            //Control ctl = ((ContextMenuStrip)p).SourceControl;
            //if (!(ctl is DataGridView)) return;

            //DataGridView grid = (DataGridView)ctl;
            if (!(control is DataGridView)) return;
            DataGridView grid = (DataGridView)control;

            int startRowIndex = grid.CurrentCell.RowIndex;
            int startColIndex = grid.CurrentCell.ColumnIndex;
            int gridRowCount = grid.RowCount;
            int gridColCount = grid.Columns.Count;

            //クリップボードにテキストデータが無いときは何もしない
            IDataObject data = Clipboard.GetDataObject();
            if (data == null) return;
            //DataFormats.Textに関連付けられたデータがあるか調べる
            if (!data.GetDataPresent(DataFormats.Text)) return;

            object getData = Clipboard.GetData(DataFormats.Text);
            if (getData == null)
            {
                MessageBox.Show("貼り付けるデータがありません", "貼り付け", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var pasteRows = ((string)getData).Replace("\r", "")
                .Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);

            var maxRowCount = Math.Min(pasteRows.Length, gridRowCount - startRowIndex);
            for (int rowCount = 0; rowCount < maxRowCount; rowCount++)
            {
                var rowIndex = startRowIndex + rowCount;

                // タブ区切りでセル値を取得
                var pasteCells = pasteRows[rowCount].Split('\t');

                // 選択位置から列数繰り返す
                var maxColCount = Math.Min(pasteCells.Length, gridColCount - startColIndex);
                for (int colCount = 0; colCount < maxColCount; colCount++)
                {
                    var colIndex = startColIndex + colCount;

                    grid[colIndex, rowIndex].Value = pasteCells[colCount];
                    grid[colIndex, rowIndex].Selected = true;
                }
            }
        }

        /// <summary>
        /// 連続データを入力する
        /// 直前の行のデータを確認し、10進データ以外ならそのデータをセット
        /// 10進のデータなら更にその直前の行との増分値をプラスしたものをセット
        /// </summary>
        /// <param name="control">データを入力するコントロール</param>
        private void inputSequentialData(Control control)
        {
            if (!(control is DataGridView)) return;
            DataGridView grid = (DataGridView)control;

            int RowIndex = grid.CurrentCell.RowIndex;
            int ColIndex = grid.CurrentCell.ColumnIndex;

            if (RowIndex <= 0) return;

            int prevRowIndex = RowIndex - 1;
            string prevStrValue = string.Empty;
            int prevIntValue = 0;

            if ((grid[ColIndex, prevRowIndex].Value is DBNull) || string.IsNullOrEmpty((string)grid[ColIndex, prevRowIndex].Value)) return;
            prevStrValue = (string)grid[ColIndex, prevRowIndex].Value;

            if (!Lecip.Util.IsNumeric(prevStrValue))
            {
                grid.CurrentCell.Value = prevStrValue;
            }
            else
            {
                prevIntValue = Convert.ToInt32(prevStrValue);
                int delta = 1;
                if (prevRowIndex >= 1)
                {
                    if ((grid[ColIndex, prevRowIndex - 1].Value is DBNull) || string.IsNullOrEmpty((string)grid[ColIndex, prevRowIndex - 1].Value) ||
                        (!Lecip.Util.IsNumeric((string)grid[ColIndex, prevRowIndex - 1].Value)))
                    {
                        delta = prevIntValue;
                    }
                    else
                    {
                        int prevPrvValue = Convert.ToInt32((string)grid[ColIndex, prevRowIndex - 1].Value);
                        delta = prevIntValue - prevPrvValue;
                    }
                }
                else
                {
                    delta = prevIntValue;
                }
                grid.CurrentCell.Value = (prevIntValue + delta).ToString("D" + prevStrValue.Length.ToString());
            }
        }
        #endregion
    }
}
