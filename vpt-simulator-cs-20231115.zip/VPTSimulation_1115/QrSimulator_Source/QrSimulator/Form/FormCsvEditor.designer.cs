﻿namespace SimulatorApplication
{
    partial class FormCsvEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCsvEditor));
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tlpMain = new System.Windows.Forms.TableLayoutPanel();
            this.dgvEdit = new Lecip.Windows.Forms.DataGridViewEx();
            this.cmnuUnchinEdit = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmItemEditClear = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemEditCut = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemEditCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemEditPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmItemEditSequential = new System.Windows.Forms.ToolStripMenuItem();
            this.tlpCmd = new System.Windows.Forms.TableLayoutPanel();
            this.lbComment = new System.Windows.Forms.Label();
            this.tlpMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEdit)).BeginInit();
            this.cmnuUnchinEdit.SuspendLayout();
            this.tlpCmd.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(3, 3);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(86, 35);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "適用";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(95, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 35);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "キャンセル";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // tlpMain
            // 
            this.tlpMain.ColumnCount = 2;
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.tlpMain.Controls.Add(this.dgvEdit, 0, 0);
            this.tlpMain.Controls.Add(this.tlpCmd, 1, 1);
            this.tlpMain.Controls.Add(this.lbComment, 0, 1);
            this.tlpMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpMain.Location = new System.Drawing.Point(0, 0);
            this.tlpMain.Name = "tlpMain";
            this.tlpMain.RowCount = 2;
            this.tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tlpMain.Size = new System.Drawing.Size(784, 462);
            this.tlpMain.TabIndex = 2;
            // 
            // dgvEdit
            // 
            this.dgvEdit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tlpMain.SetColumnSpan(this.dgvEdit, 2);
            this.dgvEdit.ContextMenuStrip = this.cmnuUnchinEdit;
            this.dgvEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEdit.Location = new System.Drawing.Point(3, 3);
            this.dgvEdit.Name = "dgvEdit";
            this.dgvEdit.RowHeadersWidth = 50;
            this.dgvEdit.RowNumberVisible = true;
            this.dgvEdit.RowNumberZeroStart = false;
            this.dgvEdit.RowTemplate.Height = 17;
            this.dgvEdit.Size = new System.Drawing.Size(778, 406);
            this.dgvEdit.TabIndex = 0;
            // 
            // cmnuUnchinEdit
            // 
            this.cmnuUnchinEdit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmItemEditClear,
            this.tsmItemEditCut,
            this.tsmItemEditCopy,
            this.tsmItemEditPaste,
            this.tsmItemEditSequential});
            this.cmnuUnchinEdit.Name = "cmnuUnchinEdit";
            this.cmnuUnchinEdit.Size = new System.Drawing.Size(190, 136);
            this.cmnuUnchinEdit.Text = "編集";
            // 
            // tsmItemEditClear
            // 
            this.tsmItemEditClear.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemEditClear.Image")));
            this.tsmItemEditClear.Name = "tsmItemEditClear";
            this.tsmItemEditClear.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Delete)));
            this.tsmItemEditClear.Size = new System.Drawing.Size(189, 22);
            this.tsmItemEditClear.Text = "クリア(&D)";
            // 
            // tsmItemEditCut
            // 
            this.tsmItemEditCut.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemEditCut.Image")));
            this.tsmItemEditCut.Name = "tsmItemEditCut";
            this.tsmItemEditCut.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.tsmItemEditCut.Size = new System.Drawing.Size(189, 22);
            this.tsmItemEditCut.Text = "切り取り(&T)";
            // 
            // tsmItemEditCopy
            // 
            this.tsmItemEditCopy.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemEditCopy.Image")));
            this.tsmItemEditCopy.Name = "tsmItemEditCopy";
            this.tsmItemEditCopy.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.tsmItemEditCopy.Size = new System.Drawing.Size(189, 22);
            this.tsmItemEditCopy.Text = "コピー(&C)";
            // 
            // tsmItemEditPaste
            // 
            this.tsmItemEditPaste.Image = ((System.Drawing.Image)(resources.GetObject("tsmItemEditPaste.Image")));
            this.tsmItemEditPaste.Name = "tsmItemEditPaste";
            this.tsmItemEditPaste.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.tsmItemEditPaste.Size = new System.Drawing.Size(189, 22);
            this.tsmItemEditPaste.Text = "貼り付け(&P)";
            // 
            // tsmItemEditSequential
            // 
            this.tsmItemEditSequential.Name = "tsmItemEditSequential";
            this.tsmItemEditSequential.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.tsmItemEditSequential.Size = new System.Drawing.Size(189, 22);
            this.tsmItemEditSequential.Text = "連続データ";
            // 
            // tlpCmd
            // 
            this.tlpCmd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tlpCmd.ColumnCount = 2;
            this.tlpCmd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpCmd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpCmd.Controls.Add(this.btnCancel, 1, 0);
            this.tlpCmd.Controls.Add(this.btnOK, 0, 0);
            this.tlpCmd.Location = new System.Drawing.Point(597, 418);
            this.tlpCmd.Name = "tlpCmd";
            this.tlpCmd.RowCount = 1;
            this.tlpCmd.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpCmd.Size = new System.Drawing.Size(184, 41);
            this.tlpCmd.TabIndex = 3;
            // 
            // lbComment
            // 
            this.lbComment.AutoSize = true;
            this.lbComment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbComment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbComment.Location = new System.Drawing.Point(3, 412);
            this.lbComment.Name = "lbComment";
            this.lbComment.Size = new System.Drawing.Size(588, 50);
            this.lbComment.TabIndex = 4;
            // 
            // FormCsvEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(784, 462);
            this.Controls.Add(this.tlpMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormCsvEditor";
            this.Text = "設定編集画面";
            this.tlpMain.ResumeLayout(false);
            this.tlpMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEdit)).EndInit();
            this.cmnuUnchinEdit.ResumeLayout(false);
            this.tlpCmd.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TableLayoutPanel tlpMain;
        private System.Windows.Forms.TableLayoutPanel tlpCmd;
        private Lecip.Windows.Forms.DataGridViewEx dgvEdit;
        private System.Windows.Forms.ContextMenuStrip cmnuUnchinEdit;
        private System.Windows.Forms.ToolStripMenuItem tsmItemEditCut;
        private System.Windows.Forms.ToolStripMenuItem tsmItemEditCopy;
        private System.Windows.Forms.ToolStripMenuItem tsmItemEditPaste;
        private System.Windows.Forms.Label lbComment;
        private System.Windows.Forms.ToolStripMenuItem tsmItemEditClear;
        private System.Windows.Forms.ToolStripMenuItem tsmItemEditSequential;
    }
}