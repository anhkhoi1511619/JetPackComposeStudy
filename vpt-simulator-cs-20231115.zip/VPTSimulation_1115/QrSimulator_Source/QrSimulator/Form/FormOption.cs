﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;
using Lecip;

namespace SimulatorApplication
{
    public partial class FormOption : Form
    {
        #region Property
        public XmlSettings Settings { get; set; }

        #endregion

        #region Field
        private bool closeCancel;
        #endregion

        #region Constructor
        public FormOption()
        {
            InitializeComponent();
            this.closeCancel     = false;
            this.Load            += (sender, e) => { loadSettings(); };
            this.FormClosing     += (sender, e) => { e.Cancel = this.closeCancel; };
            this.btnOK.Click     += (sender, e) => { if (this.checkSettings()) saveSettings(); };
            this.btnCancel.Click += (sender, e) => { this.closeCancel = false; }; 
        }
        #endregion

        #region Private Method
        #region load & save
        private void loadSettings()
        {
            //設定の読み出し
            setDgvOption("cbo", "ネットワーク名",         this.Settings.NetworkInterfaceName, Lecip.Utility.Utility.GetIpV4NetworkNameList());
            setDgvOption("txt", "制御部IPアドレス",       this.Settings.TcpSendIpAddr, null);
            setDgvOption("txt", "制御部主局ポート番号",   $"{this.Settings.TcpRecvPortNo}", null);
            setDgvOption("txt", "QR主局ポート番号",       $"{this.Settings.TcpSendPortNo}", null);
            setDgvOption("txt", "受信タイムアウト(msec)", $"{this.Settings.ReceiveTimeout}", null);
            setDgvOption("txt", "送信前ウェイト(msec)",   $"{this.Settings.SendWaitTime}", null);
        }

        private void saveSettings()
        {
            //設定の格納
            int i = 0;
            this.Settings.NetworkInterfaceName = getDgvOption(i++);
            this.Settings.TcpSendIpAddr   = getDgvOption(i++);
            this.Settings.TcpRecvPortNo   = Convert.ToInt32(getDgvOption(i++));
            this.Settings.TcpSendPortNo   = Convert.ToInt32(getDgvOption(i++));
            this.Settings.ReceiveTimeout  = Convert.ToInt32(getDgvOption(i++));
            this.Settings.SendWaitTime    = Convert.ToInt32(getDgvOption(i++));
        }
        #endregion

        private bool checkSettings()
        {
            int    idx = 0;
            bool   ret = true;
            string msg = string.Empty;
            this.closeCancel = false;

            ////設定値の確認
            idx = 2; if (ret && !Util.IsNumeric(getDgvOption(idx))) { ret = false; msg = (string)this.dgvOption.Rows[idx].HeaderCell.Value; }
            idx = 3; if (ret && !Util.IsNumeric(getDgvOption(idx))) { ret = false; msg = (string)this.dgvOption.Rows[idx].HeaderCell.Value; }
            idx = 4; if (ret && !Util.IsNumeric(getDgvOption(idx))) { ret = false; msg = (string)this.dgvOption.Rows[idx].HeaderCell.Value; }
            idx = 5; if (ret && !Util.IsNumeric(getDgvOption(idx))) { ret = false; msg = (string)this.dgvOption.Rows[idx].HeaderCell.Value; }
            if (!ret)
            {
                Util.MessageErr($"{msg}の入力内容に誤りがあります", "オプション画面");
                this.closeCancel = true;
            }

            return ret;
        }

        /// <summary>
        /// DataGridViewに設定値を表示する
        /// </summary>
        /// <param name="type">"txt":テキストボックス or "cbo":コンボボックス or "chk":チェックボックス</param>
        /// <param name="name">行ヘッダに表示する見出し</param>
        /// <param name="value">設定値</param>
        /// <param name="comboList">コンボのときの選択リスト</param>
        private void setDgvOption(string type, string name, string value, string[] comboList)
        {
            this.dgvOption.Rows.Add(value);

            int row = this.dgvOption.RowCount - 1;
            this.dgvOption.Rows[row].HeaderCell.Value = name;

            if (type == "txt")
            {
                var cell = new DataGridViewTextBoxCell();

                cell.Value = value;
                this.dgvOption[0, row] = cell;
            }
            else if (type == "cbo")
            {
                DataGridViewComboBoxCell cell = new DataGridViewComboBoxCell();

                if (comboList != null && comboList.Length > 0)
                {
                    cell.Items.AddRange(comboList);
                }
                if (!cell.Items.Contains(value)) cell.Items.Add(value);

                cell.Value = value;
                this.dgvOption[0, row] = cell;
            }
            else if (type == "chk")
            {
                var cell = new DataGridViewCheckBoxCell();

                cell.Value = (value == "0" ? false : true);
                this.dgvOption[0, row] = cell;
            }
        }

        /// <summary>
        /// DataGridViewに入力された値を文字列で取得する
        /// </summary>
        /// <param name="row">行番号</param>
        /// <returns></returns>
        private string getDgvOption(int row)
        {
            if (row >= this.dgvOption.RowCount) return string.Empty;
            if (this.dgvOption[0, row].Value == null) return string.Empty;

            return this.dgvOption[0, row].Value.ToString();
        }

        /// <summary>
        /// 現在有効なシリアルポート番号のリストを取得する
        /// </summary>
        /// <returns></returns>
        private string[] getSerialPortList()
        {
            string[] pn = SerialPort.GetPortNames().OrderBy(value => value).ToArray();

            return pn;
        }

        /// <summary>
        /// シリアルポートの文字列からint型のポート番号に変換
        /// 例 COM1 -> 1
        /// </summary>
        /// <param name="portName">シリアルポートの文字列</param>
        /// <returns>int型のポート番号</returns>
        private int convSerialPort(string portName)
        {
            int portNo = 0;

            if (!portName.StartsWith("COM")) return 1;

            if (!int.TryParse(portName.Substring(3), out portNo)) return 1;

            return portNo;
        }
        #endregion
    }
}
