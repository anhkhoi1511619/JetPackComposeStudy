﻿using System;
using Lecip;
using Lecip.Net;
using Lecip.Data;

namespace SimulatorApplication
{
    /// <summary>
    /// 従局
    /// </summary>
    class SimulatorSub : TcpIFQrControl
    {
        #region Event Handler
        /// <summary> 受信イベント </summary>
        public event EventHandler DataReceived;
        #endregion

        #region Property
        /// <summary> 結果ログ </summary>
        public string ResultLog { get; set; }
        #endregion

        #region Field
        /// <summary> シミュレータデータ </summary>
        private SimData simData;
        #endregion

        #region Constructor
        public SimulatorSub()
        {
            this.TcpDataReceived += (sender, e) => { receive(); };
            this.simData = SimData.Instance;
        }
        #endregion

        #region Private Method
        /// <summary>
        /// データ受信処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void receive()
        {
            receiveCmd();

            this.DataReceived?.Invoke(this, new EventArgs());

            sendRes();
        }

        #region Receive
        /// <summary>
        /// 受信結果表示処理
        /// </summary>
        private void receiveCmd()
        {
            string rxCmd = $"{this.Tcp.RxCmd:X2}";
            string rxData = Util.ToString(this.Tcp.RxData);

            string log = $"Cmd[{rxCmd}H {this.simData.CmdList[rxCmd]}]";
            switch (this.Tcp.RxCmd)
            {
                case 0x00:
                    this.simData.Cmd00.SetString(rxData);
                    if (!this.simData.EnableCmd00Log) log = string.Empty;
                    break;
                case 0x10:
                    this.simData.Cmd10.SetString(rxData);
                    break;
                default:
                    break;
            }

            this.ResultLog = log;
        }
        #endregion

        #region Send
        /// <summary>
        /// レスポンス送信処理
        /// </summary>
        private void sendRes()
        {
            if (this.simData.Settings.SendWaitTime > 0)
            {
                System.Threading.Thread.Sleep(this.simData.Settings.SendWaitTime);
            }

            switch (this.Tcp.RxCmd)
            {
                case 0x00:
                    //0x01 ステータスレスポンス送信
                    this.Tcp.Send(0x01, this.simData.Res01.GetByteArray(), -1);
                    break;
                case 0x10:
                    //0x11 接客表示要求レスポンス送信
                    this.Tcp.Send(0x11, this.simData.Res01.GetByteArray(), -1);
                    break;
                case 0x90:
                    //0x91 バージョン要求レスポンス送信
                    string strSnd = string.Empty;
                    foreach (var item in this.simData.Res01)
                    {
                        strSnd += item.GetString();
                    }
                    foreach (var item in this.simData.Res91)
                    {
                        strSnd += item.GetString();
                    }
                    this.Tcp.Send(0x91, Util.ToByteArray(strSnd), -1);
                    break;
                case 0x92:
                    //0x93 APL移行要求レスポンス送信
                    this.Tcp.Send(0x93, this.simData.Res01.GetByteArray(), -1);
                    break;
                case 0x94:
                    //0x95 プログラム更新要求レスポンス送信
                    this.Tcp.Send(0x95, this.simData.Res01.GetByteArray(), -1);
                    break;
                default:
                    break;
            }
        }
        #endregion
        #endregion
    }
}
