//
// Drive Boss 疑似サーバ
// Version:1.0.6
// Date :2021/04/02
//

var fs = require('fs');
var iconv = require('iconv-lite');
var url = require('url');
var http = require('http');
var https = require('https');
//var hostname = '127.0.0.1';
var hostname = '192.168.180.42';
//var hostname = '10.45.81.39';
//var hostname = '172.16.10.109';
var ssl_server_key = 'server_key.pem';
var ssl_server_crt = 'server_crt.pem';
var filename = "";

var http_port = 9000;
var https_port = 9001;

var flag = 0;    // 0: utf-8, 1:sjis

var options = {
        key: fs.readFileSync(ssl_server_key),
        cert: fs.readFileSync(ssl_server_crt)
};


var http_server = http.createServer();
var https_server = https.createServer(options);

http_server.on('request', function(req, res) {//httpリクエストがあった(=アクセスされた)時に呼ばれる
    console.log(`request`);
    
    flag = 0;
    filename = "";
    // エラー時のレスポンスデータ
    var responseData = "data/error.json";
    var resHeader = {'Content-Type': 'text/html; charset=UTF-8'};
    
    if( req.url.indexOf( 'loginInput' ) > -1 ) {
        console.log(`ユーザ認証`);
        if(req.method === 'POST') {
            console.log(`request[POST]`);
            var data = '';
    
            //POSTデータを受けとる
            req.on('data', function(chunk) {data += chunk})
              .on('end', function() {

              console.log(`request[body]:`,data);

            })
            responseData = "data/loginInput.json";

        }
    } else if( req.url.indexOf( 'carList' ) > -1 ) {
        console.log(`車両リスト取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            //var data = url.parse(req.url,true);
            //console.log(data);
            var str = '';
	        // パースする
	        var data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`str:`+str);
            
            console.log(`test`);
            
            
            responseData = "data/carList.json";
	    }
	} else if( req.url.indexOf( 'settingInfo' ) > -1 ) {
        console.log(`3G設定ファイル取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data/settingInfo.json";
	    }
    } else if( req.url.indexOf( 'dangerSpotList' ) > -1 ) {
        console.log(`3G危険箇所地点リスト取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            responseData = "data/dangerSpotList.json";
        } else if(req.method === 'POST') {
            console.log(`request[POST]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            responseData = "data/dangerSpotList.json";
	    }
    } else if( req.url.indexOf( 'runDataUpload' ) > -1 ) {
        console.log(`3G運行データ送信`);
        if(req.method === 'POST') {
           console.log(`request[POST]`);
           var data = '';
    
           //POSTデータを受けとる
           req.on('data', function(chunk) {data += chunk})
              .on('end', function() {

              console.log(`request[body]:`,data);

           })
           responseData = "data/runDataUpload.json";

        }
    } else if( req.url.indexOf( 'messageRequest' ) > -1 ) {
        console.log(`メッセージ要求`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data/messageRequest.json";
	    }
    } else if( req.url.indexOf( 'messageReply' ) > -1 ) {
        console.log(`メッセージ応答送信`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data/messageReply.json";
	    }
    } else if( req.url.indexOf( 'visitListSync' ) > -1 ) {
        console.log(`訪問先リスト同期通知`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data/visitListSync.json";
	    }
    } else if( req.url.indexOf( 'visitListDetail' ) > -1 ) {
        console.log(`訪問先詳細情報取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data/visitListDetail.json";
	    }
    } else if( req.url.indexOf( 'arrivalContact' ) > -1 ) {
        console.log(`訪問先到着情報送信`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data/arrivalContact.json";
	    }
    } else if( req.url.indexOf( 'getSpotList' ) > -1 ) {
        console.log(`地点情報取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data/getSpotList.json";
	    }
    } else if( req.url.indexOf( 'statusContact' ) > -1 ) {
        console.log(`送迎ステータス送信`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data/statusContact.json";
	    }
    } else if( req.url.indexOf( 'terms.html' ) > -1 ) {
        console.log(`Webアクセス許可`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
           responseData = "data-testing/smpapp/html/terms.html";
	    }
    } else if( req.url.indexOf( '1b1d6f27ecde9766289b9f3b780094f86ce321b7b200180b56fff4dd4833ad55156d454a6ee80fa7a5c5bd2b323e9e03' ) > -1 ) {
        console.log(`3G設定ファイル取得API`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            // responseData = "webapisp/download/fileDownload/202103291256555162487163446713010344.dat";
            filename = "webapisp/download/fileDownload/202103291256555162487163446713010344.dat";
            flag = 2;
	    }
    } else if( req.url.indexOf( 'e4f8ead7c03674247cb9c19f2b9a44a571d065d39156dc62d41553139387b18238c82e722dcfecb0c8abaec50fd6d03a' ) > -1 ) {
        console.log(`訪問先リスト同期取得API`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            //responseData = "webapisp/download/fileDownload/asysnk.dat";
            filename = "webapisp/download/fileDownload/asysnk.dat";
            resHeader = {'Content-Type' : 'application/octet-stream',        'Content-Disposition' : 'attachment; filename="asysnk.dat"'};
            responseData = "data/dummy.json";
            flag = 2;
	    }
    } else if( req.url.indexOf( '7ab0808ceec7b8f3bd9f8caee411a51126a2c8a0de2109865f901271c33b1a93ef76f7a70a04a1ef084f26a9cdb1607' ) > -1 ) {
        console.log(`3G危険箇所地点リスト取得API`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            filename = "webapisp/download/fileDownload/202103291527491607369689871140806142.zip";
            resHeader = {'Content-Type' : 'application/zip',        'Content-Disposition' : 'attachment; filename="202103291527491607369689871140806142.zip"'};
            responseData = "data/dummy.json";
            flag = 2;
	    }
    } else {
        console.log(`その他`);
    } 
 
 
 
 
 
    res.writeHead(200, resHeader);
 
//    const body = fs.readFileSync(responseData, { encoding: "utf-8" });
    const body = fs.readFileSync(responseData, { encoding: 'utf-8' });
    if( flag == 1 ){
        console.log(`Shift_JIS`);
        console.log(`Filename: ${filename}`);
        // body = "";
        // var reader = fs.createReadStream(filename).pipe(iconv.decodeStream("Shift_JIS"));
        // reader.on("data", (chunk) => {
  		// 	body += chunk;
		// });
        res.write(body);
        res.end();
    }else if( flag == 2 ){
        console.log(`Zip File`);
        var raw = fs.createReadStream( filename );
        raw.pipe(res);
    }else {
        console.log(`utf-8`);
        res.write(body);
        res.end();
    }
    console.log(`response[body]: ${body}`);
    console.log(`response[end]`);

});

https_server.on('request', function(req, res) {//httpリクエストがあった(=アクセスされた)時に呼ばれる
    console.log(`request`);
    
    flag = 0;
    filename = "";
    // エラー時のレスポンスデータ
    var responseData = "data/error.json";
    var resHeader = {'Content-Type': 'text/html; charset=UTF-8'};
    
    if( req.url.indexOf( 'loginInput' ) > -1 ) {
        console.log(`ユーザ認証`);
        if(req.method === 'POST') {
            console.log(`request[POST]`);
            var data = '';
    
            //POSTデータを受けとる
            req.on('data', function(chunk) {data += chunk})
              .on('end', function() {

              console.log(`request[body]:`,data);

            })
            responseData = "data/loginInput.json";

        }
    } else if( req.url.indexOf( 'postContent' ) > -1 ) {
        console.log(`車両リスト取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/postContent.json";
	    }
	} else if( req.url.indexOf( 'settingInfo' ) > -1 ) {
        console.log(`3G設定ファイル取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
             
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/settingInfo.json";
	    }
    } else if( req.url.indexOf( 'dangerSpotList' ) > -1 ) {
        console.log(`3G危険箇所地点リスト取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/dangerSpotList.json";
        } else if(req.method === 'POST') {
            console.log(`request[POST]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/dangerSpotList.json";
	    }
    } else if( req.url.indexOf( 'runDataUpload' ) > -1 ) {
        console.log(`3G運行データ送信`);
        if(req.method === 'POST') {
           console.log(`request[POST]`);
           var data = '';
    
           //POSTデータを受けとる
           req.on('data', function(chunk) {data += chunk})
              .on('end', function() {

              console.log(`request[body]:`,data);

           })
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/runDataUpload.json";

        }
    } else if( req.url.indexOf( 'messageRequest' ) > -1 ) {
        console.log(`メッセージ要求`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/messageRequest.json";
	    }
    } else if( req.url.indexOf( 'messageReply' ) > -1 ) {
        console.log(`メッセージ応答送信`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/messageReply.json";
	    }
    } else if( req.url.indexOf( 'visitListSync' ) > -1 ) {
        console.log(`訪問先リスト同期通知`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/visitListSync.json";
	    }
    } else if( req.url.indexOf( 'visitListDetail' ) > -1 ) {
        console.log(`訪問先詳細情報取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/visitListDetail.json";
	    }
    } else if( req.url.indexOf( 'arrivalContact' ) > -1 ) {
        console.log(`訪問先到着情報送信`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/arrivalContact.json";
	    }
    } else if( req.url.indexOf( 'getSpotList' ) > -1 ) {
        console.log(`地点情報取得`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/getSpotList.json";
	    }
    } else if( req.url.indexOf( 'statusContact' ) > -1 ) {
        console.log(`送迎ステータス送信`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data/statusContact.json";
	    }
    } else if( req.url.indexOf( 'terms.html' ) > -1 ) {
        console.log(`Webアクセス許可`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            responseData = "data-testing/smpapp/html/terms.html";
	    }
    } else if( req.url.indexOf( '1b1d6f27ecde9766289b9f3b780094f86ce321b7b200180b56fff4dd4833ad55156d454a6ee80fa7a5c5bd2b323e9e03' ) > -1 ) {
        console.log(`3G設定ファイル取得API`);
        if(req.method === 'GET') {
            console.log(`request[GET]:` + req.headers);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            //filename = "webapisp/download/fileDownload/202103291256555162487163446713010344.dat";
            responseData = "webapisp/download/fileDownload/202103291256555162487163446713010344.dat";

            //filename = "webapisp/download/fileDownload/test.dat";
            resHeader = {'Content-Type': 'application/octet-stream;'};
            //responseData = "data/dummy.json";
            flag = 1;
	    }
    } else if( req.url.indexOf( 'e4f8ead7c03674247cb9c19f2b9a44a571d065d39156dc62d41553139387b18238c82e722dcfecb0c8abaec50fd6d03a' ) > -1 ) {
        console.log(`訪問先リスト同期取得API`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            flag = 2;
            //responseData = "webapisp/download/fileDownload/asysnk.dat";
            filename = "webapisp/download/fileDownload/asysnk.dat";
            resHeader = {'Content-Type' : 'application/octet-stream',        'Content-Disposition' : 'attachment; filename="asysnk.dat"'};
            responseData = "data/dummy.json";
	    }
    } else if( req.url.indexOf( '7ab0808ceec7b8f3bd9f8caee411a51126a2c8a0de2109865f901271c33b1a93ef76f7a70a04a1ef084f26a9cdb1607' ) > -1 ) {
        console.log(`3G危険箇所地点リスト取得API`);
        if(req.method === 'GET') {
            console.log(`request[GET]`);
            //GETデータを受けとる
            var data = url.parse(req.url,true);
            console.log(data);
            
            var str = "";
            data = url.parse(req.url,true).query;
	        // 連想配列から取り出す
            for (var key in data) {
		        str += key + '=' + data[key] + '&';
	        }
            console.log(`Parameter:`+str);
            
            filename = "webapisp/download/fileDownload/202103291527491607369689871140806142.zip";
            resHeader = {'Content-Type' : 'application/zip',        'Content-Disposition' : 'attachment; filename="202103291527491607369689871140806142.zip"'};
            responseData = "data/dummy.json";
            flag = 3;
	    }
    } else {
        console.log(`その他`);
    } 
 
 
    res.writeHead(200, resHeader);
 
    const body = fs.readFileSync(responseData, { encoding: "utf-8" });
    if( flag == 1 ){
        console.log(`Shift_JIS`);
        console.log(`Filename: ${filename}`);

        // body = "";
        // var reader = fs.createReadStream(filename).pipe(iconv.decodeStream("Shift-JIS"));
        // reader.on("data", (chunk) => {
  		// 	body += chunk;
  		// 	//console.log(`chunk:${chunk}`);
  		// });
        // reader.on("end",() => {
        //     console.log(`reader[body]: ${body}`);
            //resHeader = {'Content-Type': 'application/csv; charset=UTF-8'};
            //res.writeHead(200, resHeader);
            res.write(body); 
            res.end();
        //     console.log(`response[body]: ${body}`);
        //     console.log(`response[end]:sjis`);
        // });
    }else if( flag == 2 ){
        console.log(`Zip File`);
        console.log(`Filename: ${filename}`);
        var raw = fs.createReadStream( filename );
        raw.pipe(res);
        console.log(`response[body]: ${body}`);
        console.log(`response[end]:ZipFile`);
    }else {
        console.log(`utf-8`);
        res.write(body);
        res.end();
        console.log(`response[body]: ${body}`);
        console.log(`response[end]:utf-8`);
    }

});

http_server.listen(http_port, hostname, function() {//サーバ起動時に呼ばれる
    console.log(`Server runnning at http://${hostname}:${http_port}/`);
});

https_server.listen(https_port, hostname, function() {//サーバ起動時に呼ばれる
    console.log(`Server runnning at https://${hostname}:${https_port}/`);
});
